
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('64','11','8','0','0','0','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('65','11','9','0','0','0','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('66','11','10','0','0','0','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('67','11','11','0','0','0','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('68','11','12','40','32','1455521133','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('69','11','13','0','0','0','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('70','11','14','35','28','1455517289','1455515885');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('71','12','1','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('72','12','2','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('73','12','3','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('74','12','4','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('75','12','5','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('76','12','6','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('77','12','7','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('78','12','8','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('79','12','9','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('80','12','10','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('81','12','11','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('82','12','12','47','43','1455606734','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('83','12','13','0','0','0','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('84','12','14','38','31','1455519865','1455518852');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('85','13','1','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('86','13','2','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('87','13','3','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('88','13','4','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('89','13','5','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('90','13','6','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('91','13','7','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('92','13','8','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('93','13','9','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('94','13','10','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('95','13','11','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('96','13','12','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('97','13','13','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('98','13','14','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('99','13','15','0','0','0','1455588435');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('100','14','1','0','0','0','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('101','14','2','0','0','0','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('102','14','3','0','0','0','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('103','14','4','0','0','0','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('104','14','6','0','0','0','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('105','14','12','52','45','1455676308','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('106','14','14','51','46','1455676734','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('107','14','15','0','0','0','1455588612');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('108','15','1','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('109','15','2','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('110','15','3','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('111','15','4','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('112','15','5','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('113','15','6','66','63','1457343001','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('114','15','7','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('115','15','8','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('116','15','9','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('117','15','10','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('118','15','11','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('119','15','12','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('120','15','13','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('121','15','14','60','57','1457337222','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('122','15','15','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('123','15','16','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('124','15','17','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('125','15','18','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('126','15','19','0','0','0','1457336793');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('127','16','1','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('128','16','2','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('129','16','3','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('130','16','4','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('131','16','5','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('132','16','6','61','58','1457337322','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('133','16','7','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('134','16','8','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('135','16','9','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('136','16','10','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('137','16','11','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('138','16','12','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('139','16','13','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('140','16','14','62','59','1457337455','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('141','16','15','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('142','16','16','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('143','16','17','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('144','16','18','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('145','16','19','0','0','0','1457337232');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('146','17','1','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('147','17','2','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('148','17','3','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('149','17','4','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('150','17','5','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('151','17','6','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('152','17','7','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('153','17','8','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('154','17','9','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('155','17','10','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('156','17','11','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('157','17','12','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('158','17','13','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('159','17','14','64','61','1457340113','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('160','17','15','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('161','17','16','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('162','17','17','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('163','17','18','0','0','0','1457340079');/* DBReback Separation */
 /* 插入数据 `shang_interestratecoupon_detail` */
 INSERT INTO `shang_interestratecoupon_detail` VALUES ('164','17','19','0','0','0','1457340079');/* DBReback Separation */ 
 /* 数据表结构 `shang_invest_credit`*/ 
 DROP TABLE IF EXISTS `shang_invest_credit`;/* DBReback Separation */ 
 CREATE TABLE `shang_invest_credit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `borrow_id` int(10) unsigned NOT NULL,
  `invest_money` decimal(15,2) unsigned NOT NULL,
  `invest_type` tinyint(3) unsigned NOT NULL,
  `duration` tinyint(3) unsigned NOT NULL,
  `get_credit` float(15,2) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_invest_detb`*/ 
 DROP TABLE IF EXISTS `shang_invest_detb`;/* DBReback Separation */ 
 CREATE TABLE `shang_invest_detb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invest_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '99',
  `sell_uid` int(10) unsigned NOT NULL,
  `transfer_price` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `money` decimal(15,2) unsigned NOT NULL DEFAULT '0.00',
  `period` tinyint(5) unsigned NOT NULL DEFAULT '0',
  `total_period` tinyint(5) unsigned NOT NULL DEFAULT '0',
  `valid` int(10) unsigned NOT NULL DEFAULT '0',
  `remark` text NOT NULL,
  `serialid` varchar(15) NOT NULL,
  `cancel_time` int(10) unsigned NOT NULL,
  `cancel_times` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `buy_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `buy_time` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(19) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_invest_detb` */
 INSERT INTO `shang_invest_detb` VALUES ('1','1','3','4','210000.00','210000.02','6','6','1454405048','转让超时','','1456898022','1','0','0','1453800248','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_invest_detb` */
 INSERT INTO `shang_invest_detb` VALUES ('2','12','3','9','507.00','507.51','2','2','1454467468','转让超时','','1456898022','1','0','0','1453862668','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_invest_detb` */
 INSERT INTO `shang_invest_detb` VALUES ('3','27','3','4','800.00','101666.67','1','1','1456120837','债权人撤销','','1455516059','1','0','0','1455516037','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_invest_detb` */
 INSERT INTO `shang_invest_detb` VALUES ('4','32','4','12','505.00','505.00','1','1','1456126251','债权人撤销','1','1455521388','1','1','1455521789','1455521451','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_invest_detb` */
 INSERT INTO `shang_invest_detb` VALUES ('5','7','1','6','1008.33','1008.33','1','1','1456711823','','1','0','0','14','1456107192','1456107023','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_invest_detb` */
 INSERT INTO `shang_invest_detb` VALUES ('6','40','3','14','62.77','62.77','3','10','1456712301','转让超时','','1456740336','1','0','0','1456107501','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_investor_detail`*/ 
 DROP TABLE IF EXISTS `shang_investor_detail`;/* DBReback Separation */ 
 CREATE TABLE `shang_investor_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repayment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `invest_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(10) unsigned NOT NULL,
  `capital` decimal(15,2) NOT NULL,
  `interest` decimal(15,2) NOT NULL,
  `interest_fee` decimal(15,2) NOT NULL,
  `interestratecoupon_money` decimal(15,2) DEFAULT '0.00',
  `status` tinyint(3) unsigned NOT NULL,
  `receive_interest` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL,
  `receive_interestratecoupon_money` decimal(15,2) DEFAULT '0.00',
  `sort_order` tinyint(3) unsigned NOT NULL,
  `total` tinyint(3) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `expired_money` decimal(15,2) NOT NULL,
  `expired_days` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `call_fee` decimal(5,2) NOT NULL,
  `substitute_money` decimal(15,2) NOT NULL,
  `substitute_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `invest_id` (`invest_id`,`status`,`deadline`),
  KEY `borrow_id` (`borrow_id`,`sort_order`,`investor_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('1','1455505800','4','1','4','2','0.00','1666.67','1133.33','0.00','2','533.34','0.00','0.00','1','6','1456502399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('2','1455505802','4','1','4','2','0.00','1666.67','1133.33','0.00','2','533.34','0.00','0.00','2','6','1459007999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('3','1455505806','4','1','4','2','0.00','1666.67','1133.33','0.00','2','533.34','0.00','0.00','3','6','1461686399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('4','1455505808','4','1','4','2','0.00','1666.67','1133.33','0.00','2','533.34','0.00','0.00','4','6','1464278399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('5','1455505811','4','1','4','2','0.00','1666.67','1133.33','0.00','2','533.34','0.00','0.00','5','6','1466956799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('6','1455505813','4','1','4','2','200000.00','1666.67','1133.33','0.00','2','533.34','200000.00','0.00','6','6','1469548799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('7','1453794890','3','2','6','1','11742.80','650.00','442.00','500.00','2','208.00','11742.80','0.00','1','5','1456502399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('8','1453794891','3','2','6','1','11870.02','522.79','355.49','401.65','2','167.30','11870.02','0.00','2','5','1459007999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('9','1453794892','3','2','6','1','11998.61','394.19','268.05','302.49','2','126.14','11998.61','0.00','3','5','1461686399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('10','1453795041','3','2','6','1','12128.59','264.21','179.66','202.49','2','84.55','12128.59','0.00','4','5','1464278399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('11','1453795042','3','2','6','1','12259.98','132.82','90.32','101.67','2','42.50','12259.98','0.00','5','5','1466956799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('12','1455505800','4','3','4','2','0.00','2500.00','1700.00','2500.00','2','800.00','0.00','0.00','1','6','1456502399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('13','1455505802','4','3','4','2','0.00','2500.00','1700.00','2500.00','2','800.00','0.00','0.00','2','6','1459007999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('14','1455505806','4','3','4','2','0.00','2500.00','1700.00','2500.00','2','800.00','0.00','0.00','3','6','1461686399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('15','1455505808','4','3','4','2','0.00','2500.00','1700.00','2500.00','2','800.00','0.00','0.00','4','6','1464278399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('16','1455505811','4','3','4','2','0.00','2500.00','1700.00','2500.00','2','800.00','0.00','0.00','5','6','1466956799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('17','1455505813','4','3','4','2','300000.00','2500.00','1700.00','2500.00','2','800.00','300000.00','0.00','6','6','1469548799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('18','0','5','4','1','6','1000.00','2.74','1.86','0.00','4','0.00','1000.00','0.00','1','1','1454687999','0.00','0','0.00','2005.48','1459386341');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('19','0','5','5','1','6','1000.00','2.74','1.86','0.00','4','0.00','1000.00','0.00','1','1','1454687999','0.00','0','0.00','2005.48','1459386341');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('20','0','8','6','1','6','100.00','0.10','0.07','0.00','7','0.00','0.00','0.00','1','1','1454083199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('21','0','6','7','14','1','1000.00','8.33','5.67','25.00','7','0.00','0.00','0.00','1','1','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('22','0','6','8','6','1','1000.00','8.33','5.67','8.33','7','0.00','0.00','0.00','1','1','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('23','1454141593','9','9','6','1','1000.00','8.33','5.67','0.00','2','2.66','1000.00','0.00','1','1','1456588799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('24','1453861536','11','10','1','6','100.00','0.10','0.07','0.08','2','0.03','100.00','0.00','1','1','1454169599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('25','1453862337','12','11','1','6','200.00','2.00','1.36','1.67','2','0.64','200.00','0.00','1','1','1456588799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('26','0','13','12','9','2','248.76','5.00','3.40','0.00','4','0.00','248.76','0.00','1','2','1456588799','0.00','0','0.00','1015.03','1459784511');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('27','0','13','12','9','2','251.24','2.51','1.71','0.00','7','0.00','0.00','0.00','2','2','1459094399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('28','0','13','13','9','2','746.27','15.00','10.20','0.00','4','0.00','746.27','0.00','1','2','1456588799','0.00','0','0.00','1015.03','1459784511');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('29','0','13','13','9','2','753.73','7.54','5.13','0.00','7','0.00','0.00','0.00','2','2','1459094399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('30','0','15','14','1','6','100.00','0.83','0.57','0.00','0','0.00','0.00','0.00','1','1','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('31','1454121603','16','15','12','6','1000.00','10.00','6.80','8.33','2','3.20','1000.00','0.00','1','1','1456847999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('32','1454124066','17','16','12','6','100.00','0.03','0.02','0.00','2','0.01','100.00','0.00','1','1','1454255999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('33','1454125607','18','17','12','6','49.75','1.00','0.68','0.00','2','0.32','49.75','0.00','1','2','1456847999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('34','1454125609','18','17','12','6','50.25','0.50','0.34','0.00','2','0.16','50.25','0.00','2','2','1459353599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('35','1456898022','19','18','4','12','200.00','2.00','1.36','0.00','1','0.64','200.00','0.00','1','1','1456847999','0.00','1','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('36','1456898022','19','19','6','12','800.00','8.00','5.44','6.67','1','2.56','800.00','0.00','1','1','1456847999','0.00','1','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('37','1462601570','20','20','6','1','661.14','16.67','11.33','0.00','5','5.34','661.14','0.00','1','3','1456847999','454.13','67','45.41','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('38','1462601571','20','20','6','1','666.65','11.16','7.59','0.00','5','3.57','666.65','0.00','2','3','1459353599','257.57','38','25.76','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('39','1462601572','20','20','6','1','672.21','5.60','3.81','0.00','5','1.79','672.21','0.00','3','3','1462031999','47.45','7','4.74','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('40','1457158800','21','21','6','12','100.00','1.00','0.68','0.00','3','0.32','100.00','0.00','1','1','1456847999','4.04','4','0.40','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('41','1455505769','28','22','4','2','1000.00','0.82','0.56','0.00','2','0.26','1000.00','0.00','1','1','1455811199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('42','1455505769','28','23','4','2','9000.00','7.40','5.03','0.00','2','2.37','9000.00','0.00','1','1','1455811199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('43','1455516048','30','24','2','12','98.76','3.75','2.55','0.00','2','1.20','98.76','0.00','1','3','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('44','1455516069','30','24','2','12','99.99','2.52','1.71','0.00','2','0.81','99.99','0.00','2','3','1460735999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('45','1455516075','30','24','2','12','101.24','1.27','0.86','0.00','2','0.41','101.24','0.00','3','3','1463327999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('46','1455516048','30','25','1','12','65.84','2.50','1.70','0.00','2','0.80','65.84','0.00','1','3','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('47','1455516069','30','25','1','12','66.66','1.68','1.14','0.00','2','0.54','66.66','0.00','2','3','1460735999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('48','1455516075','30','25','1','12','67.50','0.84','0.57','0.00','2','0.27','67.50','0.00','3','3','1463327999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('49','1455516038','33','26','14','12','248.76','5.00','3.40','0.00','2','1.60','248.76','0.00','1','2','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('50','1455516039','33','26','14','12','251.24','2.51','1.71','0.00','2','0.80','251.24','0.00','2','2','1460735999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('51','0','34','27','4','2','100000.00','1666.67','1133.33','','7','0.00','0.00','0.00','1','1','1460735999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('52','1455517370','35','28','14','12','200.00','2.00','1.36','1.67','2','0.64','200.00','0.00','1','1','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('54','1455519914','38','30','4','12','100.00','0.07','0.04','0.00','2','0.03','100.00','0.00','1','1','1455724799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('55','1455519914','38','31','14','12','400.00','0.26','0.18','0.33','2','0.08','400.00','0.00','1','1','1455724799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('56','1455522153','40','32','1','14','500.00','5.00','3.40','4.17','2','1.60','500.00','0.00','1','1','1458057599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('57','1455584618','42','33','14','1','600.00','6.00','4.08','0.00','2','1.92','600.00','0.00','1','1','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('58','1455586394','43','34','14','1','200.00','0.00','0.00','0.00','2','0.00','200.00','0.00','1','2','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('59','1455586395','43','34','14','1','200.00','0.00','0.00','0.00','2','0.00','200.00','0.00','2','2','1460822399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('60','1455587139','44','35','14','1','200.00','4.17','2.83','0.00','2','1.34','200.00','0.00','1','1','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('64','1455603765','49','39','4','6','48.15','4.17','2.83','0.00','2','1.34','48.15','0.00','1','10','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('65','1455603766','49','39','4','6','48.55','3.77','2.56','0.00','2','1.21','48.55','0.00','2','10','1460822399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('66','1455603767','49','39','4','6','48.96','3.36','2.29','0.00','2','1.07','48.96','0.00','3','10','1463414399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('67','1455603773','49','39','4','6','49.37','2.95','2.01','0.00','2','0.94','49.37','0.00','4','10','1466092799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('68','1455603775','49','39','4','6','49.78','2.54','1.73','0.00','2','0.81','49.78','0.00','5','10','1468684799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('69','0','49','39','4','6','50.19','2.13','1.45','0.00','4','0.00','50.19','0.00','6','10','1471363199','0.00','0','0.00','313.92','1483338270');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('70','0','49','39','4','6','50.61','1.71','1.16','0.00','4','0.00','50.61','0.00','7','10','1474041599','0.00','0','0.00','313.90','1483338277');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('71','0','49','39','4','6','51.03','1.29','0.87','0.00','7','0.00','0.00','0.00','8','10','1476633599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('72','0','49','39','4','6','51.46','0.86','0.59','0.00','7','0.00','0.00','0.00','9','10','1479311999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('73','0','49','39','4','6','51.89','0.43','0.29','0.00','7','0.00','0.00','0.00','10','10','1481903999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('74','1455603765','49','40','14','6','19.26','1.67','1.13','0.00','2','0.54','19.26','0.00','1','10','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('75','1455603766','49','40','14','6','19.42','1.51','1.02','0.00','2','0.49','19.42','0.00','2','10','1460822399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('76','1455603767','49','40','14','6','19.58','1.34','0.91','0.00','2','0.43','19.58','0.00','3','10','1463414399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('77','1455603773','49','40','14','6','19.75','1.18','0.80','0.00','2','0.38','19.75','0.00','4','10','1466092799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('78','1455603775','49','40','14','6','19.91','1.02','0.69','0.00','2','0.33','19.91','0.00','5','10','1468684799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('79','0','49','40','14','6','20.08','0.85','0.58','0.00','4','0.00','20.08','0.00','6','10','1471363199','0.00','0','0.00','313.92','1483338270');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('80','0','49','40','14','6','20.24','0.68','0.46','0.00','4','0.00','20.24','0.00','7','10','1474041599','0.00','0','0.00','313.90','1483338277');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('81','0','49','40','14','6','20.41','0.51','0.35','0.00','7','0.00','0.00','0.00','8','10','1476633599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('82','0','49','40','14','6','20.58','0.34','0.23','0.00','7','0.00','0.00','0.00','9','10','1479311999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('83','0','49','40','14','6','20.76','0.17','0.12','0.00','7','0.00','0.00','0.00','10','10','1481903999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('84','1455603765','49','41','12','6','19.26','1.67','1.13','0.00','2','0.54','19.26','0.00','1','10','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('85','1455603766','49','41','12','6','19.42','1.51','1.02','0.00','2','0.49','19.42','0.00','2','10','1460822399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('86','1455603767','49','41','12','6','19.58','1.34','0.91','0.00','2','0.43','19.58','0.00','3','10','1463414399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('87','1455603773','49','41','12','6','19.75','1.18','0.80','0.00','2','0.38','19.75','0.00','4','10','1466092799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('88','1455603775','49','41','12','6','19.91','1.02','0.69','0.00','2','0.33','19.91','0.00','5','10','1468684799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('89','0','49','41','12','6','20.08','0.85','0.58','0.00','4','0.00','20.08','0.00','6','10','1471363199','0.00','0','0.00','313.92','1483338270');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('90','0','49','41','12','6','20.24','0.68','0.46','0.00','4','0.00','20.24','0.00','7','10','1474041599','0.00','0','0.00','313.90','1483338277');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('91','0','49','41','12','6','20.41','0.51','0.35','0.00','7','0.00','0.00','0.00','8','10','1476633599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('92','0','49','41','12','6','20.58','0.34','0.23','0.00','7','0.00','0.00','0.00','9','10','1479311999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('93','0','49','41','12','6','20.76','0.17','0.12','0.00','7','0.00','0.00','0.00','10','10','1481903999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('94','1455603765','49','42','1','6','202.24','17.50','11.90','0.00','2','5.60','202.24','0.00','1','10','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('95','1455603766','49','42','1','6','203.93','15.81','10.75','0.00','2','5.06','203.93','0.00','2','10','1460822399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('96','1455603767','49','42','1','6','205.63','14.12','9.60','0.00','2','4.52','205.63','0.00','3','10','1463414399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('97','1455603773','49','42','1','6','207.34','12.40','8.43','0.00','2','3.97','207.34','0.00','4','10','1466092799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('98','1455603775','49','42','1','6','209.07','10.67','7.26','0.00','2','3.41','209.07','0.00','5','10','1468684799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('99','0','49','42','1','6','210.81','8.93','6.07','0.00','4','0.00','210.81','0.00','6','10','1471363199','0.00','0','0.00','313.92','1483338270');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('100','0','49','42','1','6','212.57','7.17','4.88','0.00','4','0.00','212.57','0.00','7','10','1474041599','0.00','0','0.00','313.90','1483338277');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('101','0','49','42','1','6','214.34','5.40','3.67','0.00','7','0.00','0.00','0.00','8','10','1476633599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('102','0','49','42','1','6','216.13','3.62','2.46','0.00','7','0.00','0.00','0.00','9','10','1479311999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('103','0','49','42','1','6','217.93','1.82','1.23','0.00','7','0.00','0.00','0.00','10','10','1481903999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('104','1455610314','47','43','12','14','200.00','2.00','1.36','2.50','2','0.64','200.00','0.00','1','1','1458143999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('105','0','50','44','4','15','100.00','2.17','1.47','','0','0.00','0.00','0.00','1','1','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('106','1455676367','52','45','12','14','200.00','4.00','2.72','3.33','2','1.28','200.00','0.00','1','1','1458230399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('107','1455676912','51','46','14','12','300.00','3.00','2.04','5.00','2','0.96','300.00','0.00','1','1','1458230399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('108','1455677392','53','47','14','12','200.00','2.00','1.36','0.00','2','0.64','200.00','0.00','1','1','1458230399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('109','1455677654','54','48','14','12','300.00','3.00','2.04','0.00','2','0.96','300.00','0.00','1','1','1458230399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('110','1455678050','55','49','14','12','98.51','4.00','2.72','0.00','2','1.28','98.51','0.00','1','4','1458230399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('111','1455678060','55','49','14','12','99.50','3.01','2.05','0.00','2','0.96','99.50','0.00','2','4','1460908799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('112','1455678065','55','49','14','12','100.49','2.02','1.37','0.00','2','0.65','100.49','0.00','3','4','1463500799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('113','1455678072','55','49','14','12','101.50','1.02','0.69','0.00','2','0.33','101.50','0.00','4','4','1466179199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('114','0','56','50','14','12','100.00','0.83','0.57','0.00','7','0.00','0.00','0.00','1','1','1458489599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('115','0','50','51','14','15','300.00','6.50','4.42','','0','0.00','0.00','0.00','1','1','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('116','0','58','55','4','6','199.17','3.33','2.27','0.00','0','0.00','0.00','0.00','1','2','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('117','0','58','55','4','6','200.83','1.67','1.14','0.00','0','0.00','0.00','0.00','2','2','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('118','0','26','56','4','11','65.89','2.33','1.59','0.00','0','0.00','0.00','0.00','1','3','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('119','0','26','56','4','11','66.66','1.56','1.06','0.00','0','0.00','0.00','0.00','2','3','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('120','0','26','56','4','11','67.44','0.79','0.54','0.00','0','0.00','0.00','0.00','3','3','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('121','1457337259','60','57','14','12','800.00','6.67','4.53','6.67','2','2.14','800.00','0.00','1','1','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('122','1457337491','61','58','6','1','495.86','12.50','8.50','6.25','2','4.00','495.86','0.00','1','3','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('123','1457337492','61','58','6','1','499.99','8.37','5.69','4.18','2','2.68','499.99','0.00','2','3','1462636799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('124','1457337494','61','58','6','1','504.16','4.20','2.86','2.09','2','1.34','504.16','0.00','3','3','1465315199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('125','1457337547','62','59','14','12','297.51','7.50','5.10','3.75','2','2.40','297.51','0.00','1','3','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('126','1457337551','62','59','14','12','299.99','5.02','3.41','2.51','2','1.61','299.99','0.00','2','3','1462636799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('127','1457337556','62','59','14','12','302.49','2.52','1.71','1.26','2','0.81','302.49','0.00','3','3','1465315199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('128','1457339853','63','60','14','12','300.00','3.00','2.04','0.00','2','0.96','300.00','0.00','1','1','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('129','1457340169','64','61','14','12','99.50','2.00','1.36','1.00','2','0.64','99.50','0.00','1','2','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('130','1457340170','64','61','14','12','100.50','1.01','0.68','0.50','2','0.33','100.50','0.00','2','2','1462636799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('131','0','65','62','14','12','200.00','1.67','1.13','0.00','7','0.00','0.00','0.00','1','1','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('132','0','66','63','6','1','330.57','8.33','5.67','8.33','0','0.00','0.00','0.00','1','3','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('133','0','66','63','6','1','333.33','5.58','3.79','5.58','0','0.00','0.00','0.00','2','3','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('134','0','66','63','6','1','336.10','2.80','1.90','2.80','0','0.00','0.00','0.00','3','3','0','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('135','0','67','64','14','12','200.00','1.67','1.13','0.00','7','0.00','0.00','0.00','1','1','1460044799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('136','1458723807','69','65','4','6','98.35','4.17','2.83','0.00','2','1.34','98.35','0.00','1','5','1461427199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('137','1458723813','69','65','4','6','99.17','3.35','2.28','0.00','2','1.07','99.17','0.00','2','5','1464019199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('138','1458723815','69','65','4','6','99.99','2.52','1.71','0.00','2','0.81','99.99','0.00','3','5','1466697599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('139','1458723816','69','65','4','6','100.83','1.69','1.15','0.00','2','0.54','100.83','0.00','4','5','1469289599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('140','1458723818','69','65','4','6','101.67','0.85','0.58','0.00','2','0.27','101.67','0.00','5','5','1471967999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('141','1458723807','69','66','4','6','491.74','20.83','14.17','0.00','2','6.66','491.74','0.00','1','5','1461427199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('142','1458723813','69','66','4','6','495.83','16.74','11.38','0.00','2','5.36','495.83','0.00','2','5','1464019199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('143','1458723815','69','66','4','6','499.97','12.60','8.57','0.00','2','4.03','499.97','0.00','3','5','1466697599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('144','1458723816','69','66','4','6','504.13','8.44','5.74','0.00','2','2.70','504.13','0.00','4','5','1469289599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('145','1458723818','69','66','4','6','508.33','4.24','2.88','0.00','2','1.36','508.33','0.00','5','5','1471967999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('146','1464832973','70','67','4','6','38.52','3.33','2.27','0.00','2','1.06','38.52','0.00','1','10','1467475199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('147','1464832974','70','67','4','6','38.84','3.01','2.05','0.00','2','0.96','38.84','0.00','2','10','1470153599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('148','1464832975','70','67','4','6','39.17','2.69','1.83','0.00','2','0.86','39.17','0.00','3','10','1472831999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('149','1464832978','70','67','4','6','39.49','2.36','1.61','0.00','2','0.75','39.49','0.00','4','10','1475423999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('150','1464832979','70','67','4','6','39.82','2.03','1.38','0.00','2','0.65','39.82','0.00','5','10','1478102399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('151','1464832980','70','67','4','6','40.16','1.70','1.16','0.00','2','0.54','40.16','0.00','6','10','1480694399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('152','1464832983','70','67','4','6','40.49','1.37','0.93','0.00','2','0.44','40.49','0.00','7','10','1483372799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('153','1464832985','70','67','4','6','40.83','1.03','0.70','0.00','2','0.33','40.83','0.00','8','10','1486051199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('154','1464832987','70','67','4','6','41.17','0.69','0.47','0.00','2','0.22','41.17','0.00','9','10','1488470399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('155','1464833003','70','67','4','6','41.51','0.35','0.24','0.00','2','0.11','41.51','0.00','10','10','1491148799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('156','1464832973','70','68','4','6','154.09','13.33','9.07','0.00','2','4.26','154.09','0.00','1','10','1467475199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('157','1464832974','70','68','4','6','155.38','12.05','8.19','0.00','2','3.86','155.38','0.00','2','10','1470153599','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('158','1464832975','70','68','4','6','156.67','10.75','7.31','0.00','2','3.44','156.67','0.00','3','10','1472831999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('159','1464832978','70','68','4','6','157.98','9.45','6.43','0.00','2','3.02','157.98','0.00','4','10','1475423999','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('160','1464832979','70','68','4','6','159.29','8.13','5.53','0.00','2','2.60','159.29','0.00','5','10','1478102399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('161','1464832980','70','68','4','6','160.62','6.81','4.63','0.00','2','2.18','160.62','0.00','6','10','1480694399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('162','1464832983','70','68','4','6','161.96','5.47','3.72','0.00','2','1.75','161.96','0.00','7','10','1483372799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('163','1464832985','70','68','4','6','163.31','4.12','2.80','0.00','2','1.32','163.31','0.00','8','10','1486051199','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('164','1464832987','70','68','4','6','164.67','2.76','1.87','0.00','2','0.89','164.67','0.00','9','10','1488470399','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('165','1464833003','70','68','4','6','166.04','1.38','0.94','0.00','2','0.44','166.04','0.00','10','10','1491148799','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_investor_detail` */
 INSERT INTO `shang_investor_detail` VALUES ('166','1459926803','71','69','25','26','10000.00','31.25','21.25','0.00','2','10.00','10000.00','0.00','1','1','1462463999','0.00','0','0.00','0.00','0');/* DBReback Separation */ 
 /* 数据表结构 `shang_jifen_choujiang`*/ 
 DROP TABLE IF EXISTS `shang_jifen_choujiang`;/* DBReback Separation */ 
 CREATE TABLE `shang_jifen_choujiang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `jp_id` int(11) DEFAULT '0' COMMENT '奖品ID',
  `jp_title` varchar(100) DEFAULT '' COMMENT '奖品名称',
  `process` int(10) DEFAULT '0' COMMENT '0未处理1已处理2测试不用处理',
  `userip` varchar(100) DEFAULT NULL COMMENT '用户IP',
  `addtime` int(11) DEFAULT '0' COMMENT '抽奖时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_jubao`*/ 
 DROP TABLE IF EXISTS `shang_jubao`;/* DBReback Separation */ 
 CREATE TABLE `shang_jubao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `uemail` varchar(60) NOT NULL,
  `b_uid` int(11) NOT NULL,
  `b_uname` varchar(50) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `text` varchar(500) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_kvtable`*/ 
 DROP TABLE IF EXISTS `shang_kvtable`;/* DBReback Separation */ 
 CREATE TABLE `shang_kvtable` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `value` varchar(50) NOT NULL,
  `nid` varchar(10) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `son_count` int(10) unsigned NOT NULL,
  `field_1` int(10) unsigned NOT NULL,
  `field_2` int(10) unsigned NOT NULL,
  `field_3` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nid` (`nid`,`value`,`sort_order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_market_address`*/ 
 DROP TABLE IF EXISTS `shang_market_address`;/* DBReback Separation */ 
 CREATE TABLE `shang_market_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '收货人ID',
  `proid` int(11) NOT NULL COMMENT '产品ID',
  `province` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '省',
  `city` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '市',
  `area` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '区/街道',
  `address` varchar(300) CHARACTER SET utf8 NOT NULL COMMENT '收货详细地址',
  `remark` text CHARACTER SET utf8 NOT NULL COMMENT '备注',
  `add_ip` varchar(16) CHARACTER SET utf8 NOT NULL COMMENT '添加者IP',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;/* DBReback Separation */ 
 /* 数据表结构 `shang_market_goods`*/ 
 DROP TABLE IF EXISTS `shang_market_goods`;/* DBReback Separation */ 
 CREATE TABLE `shang_market_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `style` varchar(200) NOT NULL,
  `img` varchar(50) CHARACTER SET latin1 COLLATE latin1_danish_ci NOT NULL,
  `small_img` varchar(100) NOT NULL COMMENT '小缩略图地址',
  `middle_img` varchar(100) NOT NULL COMMENT '中图',
  `big_img` varchar(100) CHARACTER SET latin1 COLLATE latin1_danish_ci NOT NULL COMMENT '商品大图',
  `price` int(10) NOT NULL,
  `cost` int(8) NOT NULL,
  `order_sn` int(8) NOT NULL DEFAULT '0',
  `add_time` int(12) unsigned NOT NULL,
  `is_sys` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `jianjie` text NOT NULL,
  `canshu` text NOT NULL,
  `number` int(10) NOT NULL COMMENT '物品数量',
  `category` tinyint(4) NOT NULL DEFAULT '1' COMMENT '物品类别 1：实物；2：虚拟物品',
  `amount` int(10) NOT NULL COMMENT '限购数量',
  `convert` int(10) NOT NULL COMMENT '已兑换数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_market_goods` */
 INSERT INTO `shang_market_goods` VALUES ('1','精品手办','000','彩色','','','','','2000','10','1','1453799235','1','<p>0000</p>','<p>0</p>','10','1','10','0');/* DBReback Separation */ 
 /* 数据表结构 `shang_market_jifenlist`*/ 
 DROP TABLE IF EXISTS `shang_market_jifenlist`;/* DBReback Separation */ 
 CREATE TABLE `shang_market_jifenlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(10) NOT NULL DEFAULT '2' COMMENT '物品类别 1：金钱；2：积分',
  `title` varchar(100) DEFAULT NULL COMMENT '奖品名称',
  `num` int(10) DEFAULT '0' COMMENT '奖品数量',
  `last_num` int(10) NOT NULL COMMENT '剩余数量',
  `hits` int(10) DEFAULT '0' COMMENT '已中奖次',
  `rate` int(10) DEFAULT '0' COMMENT '中奖机率',
  `value` int(10) NOT NULL COMMENT '可兑换价值',
  `order_sn` int(10) NOT NULL COMMENT '排序',
  `is_sys` tinyint(3) NOT NULL DEFAULT '1' COMMENT '是否上线 0：下线；1：上线',
  `add_ip` varchar(16) NOT NULL COMMENT '添加者IP',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `b_img` varchar(200) NOT NULL COMMENT '奖品图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_market_jifenlist` */
 INSERT INTO `shang_market_jifenlist` VALUES ('1','2','000','10','10','0','100','10','1','1','61.156.219.212','1453799287','Static/Uploads/Product/20160126170807165.jpg');/* DBReback Separation */ 
 /* 数据表结构 `shang_market_log`*/ 
 DROP TABLE IF EXISTS `shang_market_log`;/* DBReback Separation */ 
 CREATE TABLE `shang_market_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `way` int(11) NOT NULL COMMENT '领取方式',
  `gid` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `cost` int(10) unsigned NOT NULL,
  `num` tinyint(4) NOT NULL,
  `style` varchar(50) NOT NULL,
  `info` varchar(200) NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_member_address`*/ 
 DROP TABLE IF EXISTS `shang_member_address`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_address` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `name` varchar(10) NOT NULL,
  `main_phone` varchar(20) NOT NULL,
  `secondary_phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `post_code` varchar(10) NOT NULL,
  `address_type` tinyint(4) NOT NULL DEFAULT '0',
  `province` smallint(5) unsigned NOT NULL,
  `city` smallint(5) unsigned NOT NULL,
  `district` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`address_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_member_apply`*/ 
 DROP TABLE IF EXISTS `shang_member_apply`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_apply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `credit_money` decimal(15,2) NOT NULL,
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(50) NOT NULL,
  `apply_type` tinyint(3) unsigned NOT NULL,
  `apply_money` decimal(15,2) NOT NULL,
  `apply_info` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('1','1','1453795308','61.156.219.212','1','1000.00','0','0','0','1','1000.00','00');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('2','6','1453797190','61.156.219.212','1','20000.00','0','0','111','1','1000.00','啊啊啊啊');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('3','4','1453799443','61.156.219.212','1','0.00','0','0','0','1','50000000.00','0');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('4','12','1454131840','61.156.219.212','1','10000.00','0','0','0','1','1000.00','0');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('5','14','1455515098','61.156.219.212','1','10000.00','0','0','0','1','1000.00','0');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('6','2','1455516778','61.156.219.212','1','100000.00','0','0','0','1','100000.00','0');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('7','23','1459396590','124.236.30.191','1','1000.00','0','0','人','1','1000.00','123123123');/* DBReback Separation */
 /* 插入数据 `shang_member_apply` */
 INSERT INTO `shang_member_apply` VALUES ('8','30','1460519312','61.156.219.212','0','0.00','0','0','','1','1000.00','123');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_banks`*/ 
 DROP TABLE IF EXISTS `shang_member_banks`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_banks` (
  `uid` int(10) unsigned NOT NULL,
  `bank_num` varchar(50) NOT NULL,
  `bank_province` varchar(20) NOT NULL,
  `bank_city` varchar(20) NOT NULL,
  `bank_address` varchar(100) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('1','','','','','','1455603612','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('6','6217002220001585973','北京','北京','北京一','中国银行','1459160015','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('2','','','','','','1460011136','61.156.219.211');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('4','6214835365278907','北京','北京','姚家园支行','招商银行','1458723627','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('9','12312312312313123','北京','北京','13','中国银行','1455785175','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('11','','','','','','1455937514','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('10','','','','','','1454118422','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('3','','','','','','1454292726','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('12','6217002220001585974','北京','北京','建设银行','中国建设银行','1455514880','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('13','6214835320408907','北京','北京','00','招商银行','1455507102','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('5','6228480147889654788','内蒙古','兴安盟','是盛大盛大是的撒打撒的','中国农业银行','1454317778','111.127.41.236');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('14','6284002220001585972','北京','北京','建设银行','中国建设银行','1457668898','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('15','6214835320408907','山东','青岛','市南支行','招商银行','1458888429','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('19','','','','','','1456810832','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('17','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('20','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('23','','','','','','1459481585','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('18','','','','','','1459481812','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('8','11111111111','北京','北京','11111111111','招商银行','1459475956','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('25','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('7','','','','','','1459907711','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('28','','','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('29','','','','','','1460529770','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_banks` */
 INSERT INTO `shang_member_banks` VALUES ('30','','','','','','1460519661','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_borrow_show`*/ 
 DROP TABLE IF EXISTS `shang_member_borrow_show`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_borrow_show` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `data_url` varchar(100) NOT NULL,
  `data_name` varchar(50) NOT NULL,
  `sort` int(8) unsigned NOT NULL,
  `deal_user` varchar(50) NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_borrow_show` */
 INSERT INTO `shang_member_borrow_show` VALUES ('1','1','Static/Uploads/MemberData/1/20160201105749831.jpg','','0','tuanshang','1454295485');/* DBReback Separation */
 /* 插入数据 `shang_member_borrow_show` */
 INSERT INTO `shang_member_borrow_show` VALUES ('2','1','Static/Uploads/MemberData/1/20160201105752398.jpg','','0','tuanshang','1454295485');/* DBReback Separation */
 /* 插入数据 `shang_member_borrow_show` */
 INSERT INTO `shang_member_borrow_show` VALUES ('3','1','Static/Uploads/MemberData/1/20160201105757905.jpg','','0','tuanshang','1454295485');/* DBReback Separation */
 /* 插入数据 `shang_member_borrow_show` */
 INSERT INTO `shang_member_borrow_show` VALUES ('4','1','Static/Uploads/MemberData/1/20160201105759361.jpg','','0','tuanshang','1454295485');/* DBReback Separation */
 /* 插入数据 `shang_member_borrow_show` */
 INSERT INTO `shang_member_borrow_show` VALUES ('5','1','Static/Uploads/MemberData/1/20160201105801635.jpg','','0','tuanshang','1454295485');/* DBReback Separation */
 /* 插入数据 `shang_member_borrow_show` */
 INSERT INTO `shang_member_borrow_show` VALUES ('6','1','Static/Uploads/MemberData/1/2016020110580351.jpg','','0','tuanshang','1454295485');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_contact_info`*/ 
 DROP TABLE IF EXISTS `shang_member_contact_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_contact_info` (
  `uid` int(10) unsigned NOT NULL,
  `address` varchar(200) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `contact1` varchar(50) NOT NULL,
  `contact1_re` varchar(20) NOT NULL,
  `contact1_tel` varchar(50) NOT NULL,
  `contact2` varchar(50) NOT NULL,
  `contact2_re` varchar(20) NOT NULL,
  `contact2_tel` varchar(20) NOT NULL,
  `contact1_other` varchar(100) NOT NULL,
  `contact2_other` varchar(100) NOT NULL,
  `contact3` varchar(40) DEFAULT NULL,
  `contact3_re` varchar(20) DEFAULT NULL,
  `contact3_tel` varchar(100) DEFAULT NULL,
  `contact3_other` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('2','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('4','0','0','0','家庭成员','0','0','家庭成员','0','0','0','0','家庭成员','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('3','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('5','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('12','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('1','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('11','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('14','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('15','新疆吐鲁番','85552869','盖伦','朋友','111111111111','拉克丝','朋友','222222222222','0','0','泰达米尔','商业伙伴','333333333333','0');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('23','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('20','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('26','','','','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('30','123','123','123','朋友','123','11','朋友','001','11','002','003','朋友','004','005');/* DBReback Separation */
 /* 插入数据 `shang_member_contact_info` */
 INSERT INTO `shang_member_contact_info` VALUES ('29','123','123','123','家庭成员','123','123','家庭成员','123','123','123','123','家庭成员','123','123');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_creditslog`*/ 
 DROP TABLE IF EXISTS `shang_member_creditslog`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_creditslog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `affect_credits` mediumint(9) NOT NULL,
  `account_credits` mediumint(9) NOT NULL,
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('1','2','13','10','10','vip认证通过,奖励积分10','1453769711','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('2','2','2','10','20','实名认证通过,奖励积分10','1453769785','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('3','4','2','10','10','实名认证通过,奖励积分10','1453769791','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('4','4','13','10','20','vip认证通过,奖励积分10','1453776255','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('5','6','9','10','10','邮箱认证通过,奖励积分10','1453795760','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('6','6','2','10','20','实名认证通过,奖励积分10','1453795842','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('7','4','6','10','30','安全问题认证通过,奖励积分10','1453883992','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('8','12','2','10','10','实名认证通过,奖励积分10','1454122567','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('9','12','13','10','20','vip认证通过,奖励积分10','1454125423','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('10','3','13','10','10','vip认证通过,奖励积分10','1454292932','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('11','3','2','10','20','实名认证通过,奖励积分10','1454293036','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('12','1','1','10','10','审核3号资料(身份证),信用积分增加10','1454295433','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('13','3','1','10','30','审核6号资料(机构代码),信用积分增加10','1454296761','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('14','8','2','10','10','实名认证通过,奖励积分10','1454298921','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('15','5','1','10','10','审核2号资料(dsad),信用积分增加10','1454313058','111.127.41.55');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('16','5','1','10','20','审核1号资料(hello word),信用积分增加10','1454313064','111.127.41.55');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('17','5','2','10','30','实名认证通过,奖励积分10','1454313083','111.127.41.55');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('18','1','13','10','20','vip认证通过,奖励积分10','1455503115','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('19','6','13','10','30','vip认证通过,奖励积分10','1455503125','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('20','13','2','10','10','实名认证通过,奖励积分10','1455507039','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('21','14','2','10','10','实名认证通过,奖励积分10','1455514935','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('22','14','13','10','20','vip认证通过,奖励积分10','1455514972','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('23','12','9','10','30','邮箱认证通过,奖励积分10','1455523628','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('24','4','9','10','40','邮箱认证通过,奖励积分10','1455524075','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('25','15','2','10','10','实名认证通过,奖励积分10','1455526350','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('26','15','13','10','20','vip认证通过,奖励积分10','1455527557','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('27','15','9','10','30','邮箱认证通过,奖励积分10','1455583282','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('28','15','6','10','40','安全问题认证通过,奖励积分10','1455583700','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('29','1','2','10','30','实名认证通过,奖励积分10','1455584115','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('30','15','1','10','50','审核11号资料(4),信用积分增加10','1455585128','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('31','15','1','10','60','审核10号资料(2),信用积分增加10','1455585137','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('32','9','2','10','10','实名认证通过,奖励积分10','1455784816','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('33','9','13','10','20','vip认证通过,奖励积分10','1455845744','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('34','23','13','10','10','vip认证通过,奖励积分10','1458634972','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('35','20','14','5000','5000','0','1459822693','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('36','20','13','10','5010','vip认证通过,奖励积分10','1459823951','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('37','20','2','10','5020','实名认证通过,奖励积分10','1459824151','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('38','26','13','10','10','vip认证通过,奖励积分10','1459837271','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('39','26','2','10','20','实名认证通过,奖励积分10','1459837484','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('40','29','13','10','10','vip认证通过,奖励积分10','1460517605','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('41','30','13','10','10','vip认证通过,奖励积分10','1460519793','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('42','30','2','10','20','实名认证通过,奖励积分10','1460519974','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_creditslog` */
 INSERT INTO `shang_member_creditslog` VALUES ('43','29','2','10','20','实名认证通过,奖励积分10','1460530386','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_data_info`*/ 
 DROP TABLE IF EXISTS `shang_member_data_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_data_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `data_url` varchar(100) NOT NULL,
  `type` smallint(5) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `data_name` varchar(50) NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `ext` varchar(10) NOT NULL,
  `deal_info` varchar(40) NOT NULL,
  `deal_credits` smallint(5) unsigned NOT NULL,
  `deal_user` int(11) NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('1','5','','2','1','1453946249','hello word','0','','','10','124','1454313064');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('2','5','','10','1','1453946315','dsad','0','','','10','124','1454313058');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('3','1','Static/Uploads/MemberData/1/20160201105034879.jpg','31','1','1454295034','身份证','108996','jpg','22','10','113','1454295433');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('4','1','Static/Uploads/MemberData/1/20160201105103879.jpg','18','0','1454295063','户口本','160076','jpg','','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('5','3','Static/Uploads/MemberData/3/20160201105958438.jpg','1','0','1454295599','身份证正面','606856','jpg','','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('6','3','Static/Uploads/MemberData/3/20160201110015821.jpg','13','1','1454295615','机构代码','382912','jpg','','10','113','1454296761');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('7','4','Static/Uploads/MemberData/4/20160215112814800.docx','2','0','1455506894','00','30218','docx','','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('8','4','Static/Uploads/MemberData/4/20160215144639348.png','31','0','1455518799','身份证','32116','png','','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('9','15','Static/Uploads/MemberData/15/20160216085209759.png','1','0','1455583929','0','52190','png','','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('10','15','Static/Uploads/MemberData/15/20160216085219847.png','2','1','1455583939','2','250495','png','0','10','113','1455585137');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('11','15','Static/Uploads/MemberData/15/20160216091002240.png','5','1','1455585002','4','65713','png','0','10','113','1455585128');/* DBReback Separation */
 /* 插入数据 `shang_member_data_info` */
 INSERT INTO `shang_member_data_info` VALUES ('12','1','Static/Uploads/MemberData/1/20160220132920914.jpg','0','1','1455946162','','0','jpg','11','0','113','1455946283');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_department_info`*/ 
 DROP TABLE IF EXISTS `shang_member_department_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_department_info` (
  `uid` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `department_tel` varchar(20) NOT NULL,
  `department_address` varchar(200) NOT NULL,
  `department_year` varchar(20) NOT NULL,
  `voucher_name` varchar(20) NOT NULL,
  `voucher_tel` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('3','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('4','0','0','0','1年以下','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('5','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('12','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('1','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('11','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('2','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('14','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('15','中南航空','88888888','新疆吐鲁番','1-3年','娜美','444444444444');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('30','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_department_info` */
 INSERT INTO `shang_member_department_info` VALUES ('29','123','123','123','10年以上','123','123');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_ensure_info`*/ 
 DROP TABLE IF EXISTS `shang_member_ensure_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_ensure_info` (
  `uid` int(11) NOT NULL,
  `ensuer1_name` varchar(20) NOT NULL,
  `ensuer1_re` varchar(20) NOT NULL,
  `ensuer1_tel` varchar(20) NOT NULL,
  `ensuer2_name` varchar(20) NOT NULL,
  `ensuer2_re` varchar(20) NOT NULL,
  `ensuer2_tel` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('4','0','家庭成员','0','0','家庭成员','0');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('5','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('11','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('2','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('12','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('15','0','家庭成员','00','0','家庭成员','00');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('14','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('30','1','家庭成员','1','1','家庭成员','1');/* DBReback Separation */
 /* 插入数据 `shang_member_ensure_info` */
 INSERT INTO `shang_member_ensure_info` VALUES ('29','123','家庭成员','123','123','家庭成员','123');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_financial_info`*/ 
 DROP TABLE IF EXISTS `shang_member_financial_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_financial_info` (
  `uid` int(10) unsigned NOT NULL,
  `fin_monthin` varchar(20) NOT NULL,
  `fin_incomedes` varchar(2000) NOT NULL,
  `fin_monthout` varchar(20) NOT NULL,
  `fin_outdes` varchar(2000) NOT NULL,
  `fin_house` varchar(50) NOT NULL,
  `fin_housevalue` varchar(20) NOT NULL,
  `fin_car` varchar(20) NOT NULL,
  `fin_carvalue` varchar(20) NOT NULL,
  `fin_stockcompany` varchar(50) NOT NULL,
  `fin_stockcompanyvalue` varchar(50) NOT NULL,
  `fin_otheremark` varchar(2000) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('4','0','0','0','0','有商品房','0','是','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('5','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('1','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('11','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('2','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('14','5000','技术和股份','2000','住房和购物','无房','0','否','0','团尚','10000','无');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('12','','','','','','','','','','','');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('15','600000','工资','5000','吃喝','有商品房','3000000','是','500000','软银','500000000','无');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('29','222222','123','123','123','有商品房','123312312','是','123','123','123','123');/* DBReback Separation */
 /* 插入数据 `shang_member_financial_info` */
 INSERT INTO `shang_member_financial_info` VALUES ('30','1','1','1','1','有其他（非商品房）','1','否','1','1','1','1');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_friend`*/ 
 DROP TABLE IF EXISTS `shang_member_friend`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_friend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `friend_id` int(10) unsigned NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_member_house_info`*/ 
 DROP TABLE IF EXISTS `shang_member_house_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_house_info` (
  `uid` int(11) NOT NULL,
  `house_dizhi` varchar(200) NOT NULL,
  `house_mianji` float(10,2) NOT NULL,
  `house_nian` varchar(10) NOT NULL,
  `house_gong` varchar(20) NOT NULL,
  `house_suo1` varchar(20) NOT NULL,
  `house_suo2` varchar(20) NOT NULL,
  `house_feng1` float(10,2) NOT NULL,
  `house_feng2` float(10,2) NOT NULL,
  `house_dai` int(11) NOT NULL,
  `house_yuegong` float(10,2) NOT NULL,
  `house_shangxian` float(10,2) NOT NULL,
  `house_anjiebank` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('4','0','0.00','0','按揭中','0','0','0.00','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('5','','0.00','','','','','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('1','','0.00','','','','','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('11','','0.00','','','','','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('2','','0.00','','','','','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('14','','0.00','','','','','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('12','','0.00','','','','','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('15','新疆吐鲁番','300.00','2010','已供完房款','斯巴达','','60.00','0.00','0','0.00','0.00','无');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('30','1','1.00','1','按揭中','1','1','1.00','1.00','1','1.00','1.00','1');/* DBReback Separation */
 /* 插入数据 `shang_member_house_info` */
 INSERT INTO `shang_member_house_info` VALUES ('29','2222','4444.00','2016','已供完房款','123','123','0.00','0.00','0','0.00','0.00','');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_info`*/ 
 DROP TABLE IF EXISTS `shang_member_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_info` (
  `uid` int(10) unsigned NOT NULL,
  `sex` varchar(20) NOT NULL,
  `zy` varchar(40) NOT NULL,
  `cell_phone` varchar(11) NOT NULL,
  `info` varchar(500) NOT NULL,
  `marry` varchar(20) NOT NULL,
  `education` varchar(50) NOT NULL,
  `income` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `idcard` varchar(20) NOT NULL,
  `card_img` varchar(200) NOT NULL,
  `real_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `province` int(11) NOT NULL,
  `province_now` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `city_now` int(11) NOT NULL,
  `area` int(11) NOT NULL,
  `area_now` int(11) NOT NULL,
  `up_time` int(10) unsigned NOT NULL,
  `card_back_img` varchar(200) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('1','男','12','18661395415','12','已婚','大专或本科','5000-10000','0','140212199102120010','','雷霄','','34','32','396','394','0','3359','1453730729','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('2','男','0','17777777777','0','未婚','高中以下','5000以下','0','370481198406144259','','橙子','','32','25','394','321','3360','2717','1453768774','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('3','男','清洁工','15849168711','马路天使','已婚','硕士或硕士以上','50000以上','0','152124199504273010','','武建','','32','26','394','338','3358','2882','1453768887','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('4','男','0','18888888888','0','未婚','高中以下','5000以下','0','370502199008206017','','杨超','0','30','31','376','390','3173','3301','1453769165','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('5','','','15024999392','','','','','0','150106555644871644','','dsad','','0','0','0','0','0','0','1453789641','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('6','','','15553833036','','','','','0','370323199110233020','','杨洪举','','0','0','0','0','0','0','1453794371','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('7','','','15754920602','','','','','0','150124198707165251','','张文斌','','0','0','0','0','0','0','1453856305','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('8','','','15254618081','','','','','0','372922199012104434','','李振立','','0','0','0','0','0','0','1453858294','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('9','','','15666472280','','','','','0','370523198601243019','','刘兵','','0','0','0','0','0','0','1453862593','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('10','','','17853738964','','','','','0','152122199103190928','Static/Uploads/Idcard/56c3e2fb909ec.jpg','刘亚丹','','0','0','0','0','0','0','0','Static/Uploads/Idcard/56c3e2fbba94e.jpg');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('11','','','15166272750','','','','','0','370302199103232933','','刘克涛','','0','0','0','0','0','0','1453897707','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('12','女','测试人员','17853738946','性格开朗','未婚','大专或本科','5000以下','0','370523199209251642','','拉拉','','32','33','394','395','3360','3379','1454118864','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('13','','','13333333333','','','','','0','370502199008206018','','李世民','','0','0','0','0','0','0','1455501984','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('14','女','12','18266479979','12','已婚','大专或本科','5000-10000','0','370523199209251642','','韩贤','','34','31','396','389','3383','3293','1455514593','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('15','男','飞行员','13706360071','我是一名飞行员,每天在天空翱翔0','未婚','硕士或硕士以上','50000以上','26','342622198302076455','','斯巴达','新疆吐鲁番','28','29','347','364','2960','3072','1455525458','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('16','','','18510287427','','','','','0','141122199108160193','','王佳冬','','0','0','0','0','0','0','1455613122','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('17','','','15155448989','','','','','0','370302199103232965','','刘二','','0','0','0','0','0','0','1455942352','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('18','','','13148437042','','','','','0','24543132546465112','Static/Uploads/Idcard/56e242b994c32.jpg','akjdshfzzz','','0','0','0','0','0','0','0','Static/Uploads/Idcard/56e242b9b15fa.jpg');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('19','','','15048363585','','','','','0','332521196902060091','','呵呵','','0','0','0','0','0','0','1456810908','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('20','男','大牛','15822623833','牛牛牛','未婚','硕士或硕士以上','50000以上','26','372325199711153637','','张超群','','34','33','396','395','3383','3382','1457486846','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('21','','','15865463700','','','','','0','370522198911260221','','土豆','','0','0','0','0','0','0','1457580517','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('22','','','13864760507','','','','','0','37052119940612442X','','木木木','','0','0','0','0','0','0','1458182576','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('23','女','33','18654658738','33','已婚','大专或本科','5000-10000','23','152122199103190927','','刘亚丹','','35','33','397','395','3399','3381','1458523609','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('24','','','18366965783','','','','','0','371525199209031714','','赵银建','','0','0','0','0','0','0','1459473215','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('25','','','15554686781','','','','','0','370784199202021310','','郑文辉','','0','0','0','0','0','0','1459836450','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('26','男','支援','18264843589','啊圣诞节啦是','未婚','大专或本科','5000以下','18','51170219740419175X','','朱泽洋','','34','35','396','397','3383','3400','1459836792','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('27','','','18206386604','','','','','0','372325199101220011','','谭福凯','','0','0','0','0','0','0','1460099178','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('28','','','18222901119','','','','','0','130983199204054132','','张建胜','','0','0','0','0','0','0','1460390107','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('29','男','123','13599260916','31','未婚','硕士或硕士以上','50000以上','33','350583199503204312','','王宁烽','123','4','17','58','241','569','2046','1460530021','');/* DBReback Separation */
 /* 插入数据 `shang_member_info` */
 INSERT INTO `shang_member_info` VALUES ('30','男','php','13835715949','123','未婚','大专或本科','5000以下','18','142602199803142512','','行飞','123','23','22','305','287','2528','2372','1460518973','');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_integrallog`*/ 
 DROP TABLE IF EXISTS `shang_member_integrallog`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_integrallog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `affect_integral` mediumint(9) NOT NULL,
  `active_integral` mediumint(9) NOT NULL,
  `account_integral` mediumint(9) NOT NULL,
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('1','6','2','9120','9120','9120','第3号标复审通过，应获积分：9120分,投资金额：60000.00元,投资天数：152天','1453794711','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('2','1','1','375','375','375','对第3号标进行了提前还款操作,获取投资积分','1453794890','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('3','1','1','724','1099','1099','对第3号标进行了提前还款操作,获取投资积分','1453794891','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('4','1','1','1103','2202','2202','对第3号标进行了提前还款操作,获取投资积分','1453794892','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('5','1','1','1479','3681','3681','对第3号标进行了提前还款操作,获取投资积分','1453795041','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('6','1','1','1875','5556','5556','对第3号标进行了提前还款操作,获取投资积分','1453795042','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('7','4','2','36400','36400','36400','第4号标复审通过，应获积分：36400分,投资金额：200000.00元,投资天数：182天','1453796192','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('8','4','2','54600','91000','91000','第4号标复审通过，应获积分：54600分,投资金额：300000.00元,投资天数：182天','1453796192','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('9','1','2','10','5566','5566','第5号标复审通过，应获积分：10分,投资金额：1000.00元,投资天数：10天','1453796210','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('10','1','2','10','5576','5576','第5号标复审通过，应获积分：10分,投资金额：1000.00元,投资天数：10天','1453796210','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('11','6','2','9','9129','9129','对2号优计划进行投标，应获积分：9分,投资金额：100元,投资天数：91天','1453796549','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('12','6','2','18','9147','9147','对3号优计划进行投标，应获积分：18分,投资金额：200元,投资天数：91天','1453796807','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('13','1','2','27','5603','5603','对4号优计划进行投标，应获积分：27分,投资金额：300元,投资天数：91天','1453797629','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('14','6','2','31','9178','9178','第9号标复审通过，应获积分：31分,投资金额：1000.00元,投资天数：31天','1453858877','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('15','6','1','6','9184','9184','对第12号标进行了提前还款操作,获取投资积分','1453862337','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('16','9','2','30','30','30','第13号标复审通过，应获积分：30分,投资金额：500.00元,投资天数：60天','1453862648','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('17','9','2','90','120','120','第13号标复审通过，应获积分：90分,投资金额：1500.00元,投资天数：60天','1453862648','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('18','4','2','310','91310','91310','对5号优计划进行投标，应获积分：310分,投资金额：10000元,投资天数：31天','1453864198','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('19','1','2','91','5694','5694','对6号优计划进行投标，应获积分：91分,投资金额：1000元,投资天数：91天','1453864718','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('20','12','2','31','31','31','第16号标复审通过，应获积分：31分,投资金额：1000.00元,投资天数：31天','1454120506','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('21','6','1','32','9216','9216','对第16号标进行了提前还款操作,获取投资积分','1454121603','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('22','12','2','6','37','37','第18号标复审通过，应获积分：6分,投资金额：100.00元,投资天数：60天','1454125568','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('23','6','1','1','9217','9217','对第18号标进行了提前还款操作,获取投资积分','1454125607','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('24','6','1','3','9220','9220','对第18号标进行了提前还款操作,获取投资积分','1454125609','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('25','4','2','6','91316','91316','第19号标复审通过，应获积分：6分,投资金额：200.00元,投资天数：31天','1454132032','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('26','6','2','24','9244','9244','第19号标复审通过，应获积分：24分,投资金额：800.00元,投资天数：31天','1454132032','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('27','12','1','1','38','38','对第19号标进行了正常的还款操作,获取投资积分','1456898022','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('28','6','2','182','9426','9426','第20号标复审通过，应获积分：182分,投资金额：2000.00元,投资天数：91天','1454134187','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('29','6','2','3','9429','9429','第21号标复审通过，应获积分：3分,投资金额：100.00元,投资天数：31天','1454134658','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('30','1','1','29','5723','5723','对第9号标进行了提前还款操作,获取投资积分','1454141593','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('31','4','2','9','91325','91325','对4号优计划进行投标，应获积分：9分,投资金额：100元,投资天数：90天','1455500673','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('32','4','2','9','91334','91334','对4号优计划进行投标，应获积分：9分,投资金额：100元,投资天数：90天','1455500701','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('33','6','2','29','9458','9458','第6号标复审通过，应获积分：29分,投资金额：1000.00元,投资天数：29天','1455503042','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('34','6','2','29','9487','9487','第6号标复审通过，应获积分：29分,投资金额：1000.00元,投资天数：29天','1455503042','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('35','4','2','3','91337','91337','第28号标复审通过，应获积分：3分,投资金额：1000.00元,投资天数：3天','1455503974','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('36','4','2','27','91364','91364','第28号标复审通过，应获积分：27分,投资金额：9000.00元,投资天数：3天','1455503974','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('37','2','1','40','40','40','对第28号标进行了提前还款操作,获取投资积分','1455505769','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('38','2','1','81500','81540','81540','对第4号标进行了提前还款操作,获取投资积分','1455505813','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('39','4','2','450','91814','91814','对8号优计划进行投标，应获积分：450分,投资金额：5000元,投资天数：90天','1455515021','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('40','2','2','450','81990','81990','对8号优计划进行投标，应获积分：450分,投资金额：5000元,投资天数：90天','1455515231','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('41','1','2','18','5741','5741','第30号标复审通过，应获积分：18分,投资金额：200.00元,投资天数：90天','1455515487','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('42','2','2','27','82017','82017','第30号标复审通过，应获积分：27分,投资金额：300.00元,投资天数：90天','1455515487','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('43','4','2','6000','97814','97814','第34号标复审通过，应获积分：6000分,投资金额：100000.00元,投资天数：60天','1455515940','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('44','14','2','30','30','30','第33号标复审通过，应获积分：30分,投资金额：500.00元,投资天数：60天','1455516012','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('45','12','1','7','45','45','对第33号标进行了提前还款操作,获取投资积分','1455516038','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('46','12','1','15','60','60','对第33号标进行了提前还款操作,获取投资积分','1455516039','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('47','12','1','4','64','64','对第30号标进行了提前还款操作,获取投资积分','1455516048','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('48','12','1','10','74','74','对第30号标进行了提前还款操作,获取投资积分','1455516069','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('49','12','1','15','89','89','对第30号标进行了提前还款操作,获取投资积分','1455516075','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('50','14','2','5','35','35','第35号标复审通过，应获积分：5分,投资金额：200.00元,投资天数：29天','1455517315','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('51','12','1','6','95','95','对第35号标进行了提前还款操作,获取投资积分','1455517369','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('52','12','1','1','96','96','对第38号标进行了提前还款操作,获取投资积分','1455519914','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('53','12','2','14','110','110','第40号标复审通过，应获积分：14分,投资金额：500.00元,投资天数：29天','1455521146','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('54','14','1','15','50','50','对第40号标进行了提前还款操作,获取投资积分','1455522153','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('55','4','2','90','97904','97904','对4号优计划进行投标，应获积分：90分,投资金额：1000元,投资天数：90天','1455524342','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('56','15','2','45','45','45','对4号优计划进行投标，应获积分：45分,投资金额：500元,投资天数：90天','1455527119','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('57','14','2','17','67','67','第42号标复审通过，应获积分：17分,投资金额：600.00元,投资天数：29天','1455584603','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('58','1','1','18','5759','5759','对第42号标进行了提前还款操作,获取投资积分','1455584618','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('59','14','2','24','91','91','第43号标复审通过，应获积分：24分,投资金额：400.00元,投资天数：60天','1455586364','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('60','1','1','6','5765','5765','对第43号标进行了提前还款操作,获取投资积分','1455586394','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('61','1','1','12','5777','5777','对第43号标进行了提前还款操作,获取投资积分','1455586395','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('62','14','2','5','96','96','第44号标复审通过，应获积分：5分,投资金额：200.00元,投资天数：29天','1455587123','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('63','1','1','6','5783','5783','对第44号标进行了提前还款操作,获取投资积分','1455587139','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('64','12','2','5','115','115','对9号优计划进行投标，应获积分：5分,投资金额：200元,投资天数：29天','1455590854','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('65','14','2','11','107','107','对9号优计划进行投标，应获积分：11分,投资金额：400元,投资天数：29天','1455590951','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('66','12','2','18','133','133','对10号优计划进行投标，应获积分：18分,投资金额：200元,投资天数：90天','1455591342','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('67','14','2','18','125','125','对10号优计划进行投标，应获积分：18分,投资金额：200元,投资天数：90天','1455591342','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('68','1','2','638','6421','6421','第49号标复审通过，应获积分：638分,投资金额：2100.00元,投资天数：304天','1455603651','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('69','4','2','152','98056','98056','第49号标复审通过，应获积分：152分,投资金额：500.00元,投资天数：304天','1455603651','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('70','12','2','60','193','193','第49号标复审通过，应获积分：60分,投资金额：200.00元,投资天数：304天','1455603651','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('71','14','2','60','185','185','第49号标复审通过，应获积分：60分,投资金额：200.00元,投资天数：304天','1455603651','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('72','6','1','8','9495','9495','对第49号标进行了提前还款操作,获取投资积分','1455603765','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('73','6','1','17','9512','9512','对第49号标进行了提前还款操作,获取投资积分','1455603766','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('74','6','1','26','9538','9538','对第49号标进行了提前还款操作,获取投资积分','1455603767','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('75','6','1','36','9574','9574','对第49号标进行了提前还款操作,获取投资积分','1455603773','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('76','6','1','45','9619','9619','对第49号标进行了提前还款操作,获取投资积分','1455603775','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('77','14','2','72','257','257','对11号优计划进行投标，应获积分：72分,投资金额：400元,投资天数：182天','1455606156','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('78','12','2','36','229','229','对11号优计划进行投标，应获积分：36分,投资金额：200元,投资天数：182天','1455606156','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('79','12','2','5','234','234','第47号标复审通过，应获积分：5分,投资金额：200.00元,投资天数：29天','1455606765','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('80','14','1','6','263','263','对第47号标进行了提前还款操作,获取投资积分','1455610314','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('81','12','2','5','239','239','第52号标复审通过，应获积分：5分,投资金额：200.00元,投资天数：29天','1455676327','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('82','14','1','6','269','269','对第52号标进行了提前还款操作,获取投资积分','1455676367','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('83','14','2','8','277','277','第51号标复审通过，应获积分：8分,投资金额：300.00元,投资天数：29天','1455676893','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('84','12','1','9','248','248','对第51号标进行了提前还款操作,获取投资积分','1455676912','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('85','14','2','5','282','282','第53号标复审通过，应获积分：5分,投资金额：200.00元,投资天数：29天','1455677336','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('86','12','1','6','254','254','对第53号标进行了提前还款操作,获取投资积分','1455677392','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('87','14','2','8','290','290','第54号标复审通过，应获积分：8分,投资金额：300.00元,投资天数：29天','1455677610','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('88','12','1','9','263','263','对第54号标进行了提前还款操作,获取投资积分','1455677654','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('89','14','2','48','338','338','第55号标复审通过，应获积分：48分,投资金额：400.00元,投资天数：121天','1455678017','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('90','12','1','2','265','265','对第55号标进行了提前还款操作,获取投资积分','1455678050','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('91','12','1','6','271','271','对第55号标进行了提前还款操作,获取投资积分','1455678060','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('92','12','1','9','280','280','对第55号标进行了提前还款操作,获取投资积分','1455678065','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('93','12','1','12','292','292','对第55号标进行了提前还款操作,获取投资积分','1455678072','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('94','6','2','36','9655','9655','对11号优计划进行投标，应获积分：36分,投资金额：200元,投资天数：182天','1455698097','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('95','6','2','36','9691','9691','对11号优计划进行投标，应获积分：36分,投资金额：200元,投资天数：182天','1455698188','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('96','12','2','18','310','310','对12号优计划进行投标，应获积分：18分,投资金额：200元,投资天数：90天','1455760346','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('97','14','2','2','340','340','第56号标复审通过，应获积分：2分,投资金额：100.00元,投资天数：29天','1455934092','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('98','14','2','24','364','364','第60号标复审通过，应获积分：24分,投资金额：800.00元,投资天数：31天','1457337247','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('99','12','1','25','335','335','对第60号标进行了提前还款操作,获取投资积分','1457337259','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('100','6','2','138','9829','9829','第61号标复审通过，应获积分：138分,投资金额：1500.00元,投资天数：92天','1457337411','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('101','14','2','82','446','446','第62号标复审通过，应获积分：82分,投资金额：900.00元,投资天数：92天','1457337471','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('102','1','1','15','6436','6436','对第61号标进行了提前还款操作,获取投资积分','1457337491','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('103','1','1','30','6466','6466','对第61号标进行了提前还款操作,获取投资积分','1457337492','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('104','1','1','46','6512','6512','对第61号标进行了提前还款操作,获取投资积分','1457337494','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('105','12','1','9','344','344','对第62号标进行了提前还款操作,获取投资积分','1457337547','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('106','12','1','18','362','362','对第62号标进行了提前还款操作,获取投资积分','1457337551','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('107','12','1','28','390','390','对第62号标进行了提前还款操作,获取投资积分','1457337555','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('108','14','2','9','455','455','第63号标复审通过，应获积分：9分,投资金额：300.00元,投资天数：31天','1457339833','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('109','12','1','9','399','399','对第63号标进行了提前还款操作,获取投资积分','1457339853','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('110','14','2','12','467','467','第64号标复审通过，应获积分：12分,投资金额：200.00元,投资天数：61天','1457340150','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('111','12','1','3','402','402','对第64号标进行了提前还款操作,获取投资积分','1457340169','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('112','12','1','6','408','408','对第64号标进行了提前还款操作,获取投资积分','1457340170','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('113','14','2','6','473','473','第65号标复审通过，应获积分：6分,投资金额：200.00元,投资天数：31天','1457343050','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('114','14','2','6','479','479','第67号标复审通过，应获积分：6分,投资金额：200.00元,投资天数：31天','1457343153','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('115','4','2','76','98132','98132','第69号标复审通过，应获积分：76分,投资金额：500.00元,投资天数：153天','1458723787','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('116','4','2','382','98514','98514','第69号标复审通过，应获积分：382分,投资金额：2500.00元,投资天数：153天','1458723787','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('117','6','1','18','9847','9847','对第69号标进行了提前还款操作,获取投资积分','1458723807','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('118','6','1','36','9883','9883','对第69号标进行了提前还款操作,获取投资积分','1458723813','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('119','6','1','55','9938','9938','对第69号标进行了提前还款操作,获取投资积分','1458723815','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('120','6','1','74','10012','10012','对第69号标进行了提前还款操作,获取投资积分','1458723816','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('121','6','1','93','10105','10105','对第69号标进行了提前还款操作,获取投资积分','1458723818','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('122','4','2','121','98635','98635','第70号标复审通过，应获积分：121分,投资金额：400.00元,投资天数：304天','1464832954','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('123','4','2','486','99121','99121','第70号标复审通过，应获积分：486分,投资金额：1600.00元,投资天数：304天','1464832955','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('124','6','1','5','10110','10110','对第70号标进行了提前还款操作,获取投资积分','1464832973','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('125','6','1','12','10122','10122','对第70号标进行了提前还款操作,获取投资积分','1464832974','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('126','6','1','18','10140','10140','对第70号标进行了提前还款操作,获取投资积分','1464832975','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('127','6','1','24','10164','10164','对第70号标进行了提前还款操作,获取投资积分','1464832978','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('128','6','1','30','10194','10194','对第70号标进行了提前还款操作,获取投资积分','1464832979','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('129','6','1','36','10230','10230','对第70号标进行了提前还款操作,获取投资积分','1464832980','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('130','6','1','43','10273','10273','对第70号标进行了提前还款操作,获取投资积分','1464832983','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('131','6','1','50','10323','10323','对第70号标进行了提前还款操作,获取投资积分','1464832985','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('132','6','1','56','10379','10379','对第70号标进行了提前还款操作,获取投资积分','1464832987','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('133','6','1','63','10442','10442','对第70号标进行了提前还款操作,获取投资积分','1464833003','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('134','18','2','146','146','146','对14号优计划进行投标，应获积分：146分,投资金额：200元,投资天数：730天','1459481927','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('135','20','2','5000','5000','5000','0','1459822693','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('136','20','2','6','5006','5006','对9号优计划进行投标，应获积分：6分,投资金额：200元,投资天数：30天','1459822724','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('137','25','2','300','300','300','第71号标复审通过，应获积分：300分,投资金额：10000.00元,投资天数：30天','1459839756','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('138','26','1','300','300','300','对第71号标进行了提前还款操作,获取投资积分','1459926803','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('139','27','2','60','60','60','对15号优计划进行投标，应获积分：60分,投资金额：2000元,投资天数：30天','1460099337','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('140','29','2','6','6','6','对9号优计划进行投标，应获积分：6分,投资金额：200元,投资天数：30天','1460517751','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('141','29','2','9','15','15','对12号优计划进行投标，应获积分：9分,投资金额：100元,投资天数：91天','1460519267','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('142','30','2','30','30','30','对9号优计划进行投标，应获积分：30分,投资金额：1000元,投资天数：30天','1460528950','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_integrallog` */
 INSERT INTO `shang_member_integrallog` VALUES ('143','29','2','45','60','60','对6号优计划进行投标，应获积分：45分,投资金额：500元,投资天数：91天','1460530506','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_limitlog`*/ 
 DROP TABLE IF EXISTS `shang_member_limitlog`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_limitlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `credit_limit` float(15,2) NOT NULL,
  `borrow_vouch_limit` float(15,2) NOT NULL,
  `invest_vouch_limit` float(15,2) NOT NULL,
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('1','1','7','60000.00','0.00','0.00','3号标还款完成','1453795042','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('2','6','7','100.00','0.00','0.00','11号标还款完成','1453861536','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('3','1','8','0.00','2000.00','0.00','20号标还款完成','1462601572','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('4','12','7','100.00','0.00','0.00','21号标还款完成','1457158800','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('5','2','8','0.00','500000.00','0.00','4号标还款完成','1455505813','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('6','12','7','500.00','0.00','0.00','33号标还款完成','1455516039','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('7','2','12','100000.00','0.00','0.00','36号标流标,返还借款信用额度','1455522993','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_member_limitlog` */
 INSERT INTO `shang_member_limitlog` VALUES ('8','6','8','0.00','2000.00','0.00','70号标还款完成','1464833003','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_login`*/ 
 DROP TABLE IF EXISTS `shang_member_login`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=269 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('1','1','61.156.219.212','1453772355');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('2','4','61.156.219.212','1453776114');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('3','2','61.156.219.212','1453776882');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('4','3','111.127.41.236','1453777018');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('5','3','111.127.41.236','1453778210');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('6','3','111.127.41.236','1453779024');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('7','1','61.156.219.212','1461727883');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('8','2','61.156.219.212','1453779300');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('9','2','61.156.219.212','1453786879');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('10','2','61.156.219.212','1453791847');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('11','1','61.156.219.212','1453793969');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('12','5','111.127.41.236','1453794669');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('13','4','61.156.219.212','1453796102');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('14','4','61.156.219.212','1453796792');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('15','2','61.156.219.212','1453800381');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('16','4','61.156.219.212','1453854896');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('17','2','61.156.219.212','1453855207');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('18','6','61.156.219.212','1453855766');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('19','1','61.156.219.212','1453858528');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('20','8','61.156.219.212','1453861437');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('21','6','61.156.219.212','1453861489');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('22','2','61.156.219.212','1453862387');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('23','4','61.156.219.212','1453863100');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('24','6','61.156.219.212','1453872574');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('25','4','61.156.219.212','1453872847');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('26','1','61.156.219.212','1453874922');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('27','5','111.127.41.236','1453876541');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('28','9','61.156.219.212','1453877680');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('29','5','111.127.41.236','1453878653');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('30','5','111.127.41.236','1453880272');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('31','4','61.156.219.212','1453882584');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('32','8','61.156.219.212','1453884779');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('33','5','111.127.41.236','1453884789');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('34','1','61.156.219.212','1453885884');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('35','4','61.156.219.212','1453941278');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('36','5','111.127.41.236','1453941409');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('37','9','61.156.219.212','1453944290');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('38','5','111.127.41.236','1453944368');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('39','5','111.127.41.236','1453944670');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('40','5','111.127.41.236','1453949639');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('41','4','61.156.219.212','1453951513');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('42','8','61.156.219.212','1453959503');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('43','5','111.127.41.236','1453962643');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('44','5','111.127.41.236','1453970637');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('45','5','111.127.41.236','1453973555');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('46','5','111.127.41.236','1454030389');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('47','5','111.127.41.236','1454031661');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('48','8','61.156.219.212','1454032494');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('49','5','111.127.41.236','1454034635');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('50','7','111.127.41.236','1454034698');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('51','8','61.156.219.212','1454035979');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('52','5','111.127.41.236','1454049237');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('53','4','61.156.219.212','1454055778');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('54','7','111.127.41.236','1454058381');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('55','5','111.127.41.236','1454058793');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('56','6','61.156.219.212','1454117235');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('57','4','61.156.219.212','1454117834');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('58','1','61.156.219.212','1454120340');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('59','1','61.156.219.212','1456898800');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('60','6','61.156.219.212','1454134104');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('61','1','222.173.174.202','1454141502');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('62','7','111.127.41.236','1454289056');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('63','5','111.127.41.236','1454289793');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('64','7','111.127.41.236','1454291613');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('65','3','222.173.174.202','1454292619');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('66','5','111.127.41.236','1454292697');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('67','5','111.127.41.236','1454293654');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('68','4','61.156.219.212','1454294411');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('69','1','222.173.174.202','1454294564');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('70','5','111.127.41.236','1454296234');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('71','7','111.127.41.236','1454296611');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('72','4','61.156.219.212','1454298079');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('73','4','61.156.219.212','1454305014');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('74','12','61.156.219.212','1454305304');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('75','7','111.127.41.236','1454309292');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('76','5','111.127.41.236','1454310847');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('77','4','61.156.219.212','1454314934');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('78','8','61.156.219.212','1454317017');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('79','7','111.127.41.236','1454317600');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('80','4','61.156.219.212','1454318066');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('81','7','36.102.9.121','1454376724');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('82','5','36.102.9.121','1454376855');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('83','4','61.156.219.212','1454378093');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('84','7','36.102.9.121','1454380649');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('85','5','36.102.9.121','1454381136');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('86','7','36.102.9.121','1454381656');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('87','4','61.156.219.212','1454393245');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('88','7','36.102.9.121','1454396985');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('89','5','36.102.9.121','1454398221');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('90','12','61.156.219.212','1454398880');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('91','5','36.102.9.121','1454398933');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('92','4','61.156.219.212','1454400004');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('93','7','36.102.9.121','1454401121');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('94','11','222.173.174.202','1454401535');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('95','5','36.102.9.121','1454404251');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('96','7','36.102.9.121','1454460877');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('97','5','36.102.9.121','1454461912');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('98','4','61.156.219.212','1454462050');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('99','6','61.156.219.212','1454462305');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('100','7','36.102.9.121','1454469464');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('101','4','61.156.219.212','1454469615');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('102','2','61.156.219.212','1454469857');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('103','5','36.102.9.121','1454482201');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('104','12','61.156.219.212','1454482762');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('105','5','36.102.9.121','1454551779');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('106','5','36.102.9.121','1454557281');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('107','5','36.102.9.121','1454567696');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('108','5','36.102.9.121','1454577078');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('109','4','61.156.219.212','1455498383');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('110','12','61.156.219.212','1455498565');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('111','6','61.156.219.212','1455498834');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('112','2','61.156.219.212','1455499081');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('113','1','61.156.219.212','1455499229');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('114','6','61.156.219.212','1455499741');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('115','2','61.156.219.212','1455503637');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('116','4','61.156.219.212','1455503862');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('117','11','61.156.219.212','1455503960');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('118','6','61.156.219.212','1455504000');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('119','4','61.156.219.212','1455505407');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('120','4','61.156.219.212','1455505543');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('121','13','61.156.219.212','1455506549');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('122','12','61.156.219.212','1455506769');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('123','6','61.156.219.212','1455506983');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('124','12','61.156.219.212','1455507612');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('125','2','61.156.219.212','1455514848');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('126','1','61.156.219.212','1455515426');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('127','6','61.156.219.212','1455515517');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('128','14','61.156.219.212','1455515780');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('129','1','61.156.219.212','1455519389');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('130','14','61.156.219.212','1455519834');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('131','6','61.156.219.212','1455521359');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('132','1','61.156.219.212','1455521763');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('133','14','61.156.219.212','1455522135');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('134','2','61.156.219.212','1455522964');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('135','4','61.156.219.212','1455524013');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('136','4','61.156.219.212','1455524106');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('137','14','61.156.219.212','1455524229');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('138','4','61.156.219.212','1455525098');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('139','6','61.156.219.212','1455582542');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('140','15','61.156.219.212','1455582829');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('141','12','61.156.219.212','1455583551');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('142','14','61.156.219.212','1455583903');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('143','1','61.156.219.212','1455584026');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('144','4','61.156.219.212','1455585284');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('145','2','61.156.219.212','1455585519');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('146','14','61.156.219.212','1455588606');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('147','15','61.156.219.212','1455600802');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('148','14','61.156.219.212','1455601105');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('149','12','61.156.219.212','1455601254');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('150','4','61.156.219.212','1455601274');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('151','6','61.156.219.212','1455602564');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('152','1','61.156.219.212','1455603355');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('153','4','61.156.219.212','1455608341');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('154','4','61.156.219.212','1455608379');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('155','8','61.156.219.212','1455609395');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('156','15','61.156.219.212','1455668843');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('157','14','61.156.219.212','1455670081');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('158','6','61.156.219.212','1455670294');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('159','12','61.156.219.212','1455671530');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('160','14','61.156.219.212','1455671802');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('161','11','61.156.219.212','1455672305');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('162','6','61.156.219.212','1455673978');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('163','6','61.156.219.212','1455675579');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('164','12','61.156.219.212','1455675865');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('165','15','61.156.219.212','1455691405');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('166','4','61.156.219.212','1455691432');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('167','12','61.156.219.212','1455696307');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('168','14','61.156.219.212','1455698554');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('169','12','61.156.219.212','1455698783');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('170','15','61.156.219.212','1455698813');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('171','6','61.156.219.212','1455760374');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('172','14','61.156.219.212','1455761529');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('173','14','61.156.219.212','1455767250');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('174','8','61.156.219.212','1455774997');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('175','6','61.156.219.212','1455775052');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('176','9','61.156.219.212','1455784764');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('177','9','61.156.219.212','1455844890');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('178','9','61.156.219.212','1455845484');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('179','6','61.156.219.212','1455848284');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('180','1','61.156.219.212','1455848642');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('181','9','61.156.219.212','1455850742');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('182','12','61.156.219.212','1455930751');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('183','14','61.156.219.212','1455933463');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('184','14','61.156.219.212','1455936376');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('185','11','61.156.219.212','1455937532');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('186','12','61.156.219.212','1456101951');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('187','9','61.156.219.212','1456103727');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('188','6','61.156.219.212','1456107002');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('189','14','61.156.219.212','1456107137');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('190','6','61.156.219.212','1456380729');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('191','15','61.156.219.212','1456447592');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('192','12','61.156.219.212','1456466177');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('193','9','61.156.219.212','1456797619');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('194','5','111.127.234.108','1456798622');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('195','19','61.156.219.212','1456810849');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('196','9','61.156.219.212','1456811303');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('197','8','61.156.219.212','1457165219');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('198','9','61.156.219.212','1457314097');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('199','8','61.156.219.212','1457333739');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('200','6','61.156.219.212','1457336354');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('201','12','61.156.219.212','1457336597');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('202','1','61.156.219.212','1457336713');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('203','6','61.156.219.212','1457336751');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('204','15','61.156.219.212','1457340316');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('205','2','61.156.219.212','1457340926');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('206','14','61.156.219.212','1457341111');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('207','6','61.156.219.212','1457342075');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('208','12','61.156.219.212','1457342114');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('209','6','61.156.219.212','1457342139');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('210','1','61.156.219.212','1457342165');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('211','6','61.156.219.212','1457343331');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('212','20','61.156.219.212','1457502953');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('213','8','61.156.219.212','1457509199');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('214','20','61.156.219.212','1457510060');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('215','20','61.156.219.212','1457512053');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('216','21','61.156.219.212','1457590016');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('217','6','61.156.219.212','1457592219');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('218','14','61.156.219.212','1457668901');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('219','6','61.156.219.212','1458002919');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('220','20','61.156.219.212','1458033023');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('221','22','61.156.219.212','1458186886');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('222','9','61.156.219.212','1458280831');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('223','9','61.156.219.212','1458285955');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('224','9','61.156.219.212','1458296384');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('225','23','61.156.219.212','1458634900');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('226','9','61.156.219.212','1458636831');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('227','8','61.156.219.212','1458697084');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('228','6','61.156.219.212','1458723404');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('229','4','61.156.219.212','1458723601');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('230','6','61.156.219.212','1464778621');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('231','6','61.156.219.212','1464832234');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('232','4','61.156.219.212','1464832323');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('233','21','61.156.219.212','1458884920');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('234','15','61.156.219.212','1458888444');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('235','9','61.156.219.212','1458891402');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('236','14','61.156.219.212','1458891481');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('237','23','61.156.219.212','1459164004');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('238','6','61.156.219.212','1459160022');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('239','23','124.236.30.191','1459396560');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('240','8','61.156.219.212','1459475937');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('241','23','61.156.219.212','1459481543');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('242','18','61.156.219.212','1459481847');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('243','17','114.255.40.24','1459817571');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('244','9','61.156.219.212','1459821315');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('245','20','61.156.219.212','1459822616');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('246','20','61.156.219.212','1459826885');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('247','15','61.156.219.211','1459828888');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('248','25','61.156.219.212','1459836863');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('249','26','61.156.219.212','1459836901');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('250','25','61.156.219.212','1459838211');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('251','7','61.156.219.212','1459907731');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('252','6','61.156.219.212','1459990420');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('253','23','61.156.219.212','1459990421');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('254','2','61.156.219.211','1460011165');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('255','2','115.84.116.252','1460357109');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('256','2','221.10.175.151','1460357319');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('257','6','61.156.219.212','1460012588');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('258','6','61.156.219.212','1460084851');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('259','6','61.156.219.212','1460095354');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('260','6','61.156.219.212','1460509031');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('261','6','61.156.219.212','1460517896');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('262','29','61.156.219.212','1460519238');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('263','30','61.156.219.212','1460528443');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('264','29','61.156.219.212','1460529925');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('265','25','61.156.219.212','1460620211');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('266','25','61.156.219.212','1460634108');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('267','14','61.156.219.212','1460701961');/* DBReback Separation */
 /* 插入数据 `shang_member_login` */
 INSERT INTO `shang_member_login` VALUES ('268','25','61.156.219.212','1460702095');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_money`*/ 
 DROP TABLE IF EXISTS `shang_member_money`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_money` (
  `uid` int(10) unsigned NOT NULL,
  `money_freeze` decimal(15,2) NOT NULL COMMENT '冻结金额',
  `money_collect` decimal(15,2) NOT NULL COMMENT '待收金额',
  `account_money` decimal(15,2) NOT NULL COMMENT '充值资金存放池_可用余额',
  `back_money` decimal(15,2) NOT NULL COMMENT '回款资金存放池_可用余额',
  `credit_limit` decimal(15,2) NOT NULL,
  `credit_cuse` decimal(15,2) NOT NULL,
  `borrow_vouch_limit` decimal(15,2) NOT NULL,
  `borrow_vouch_cuse` decimal(15,2) NOT NULL,
  `invest_vouch_limit` decimal(15,2) NOT NULL,
  `invest_vouch_cuse` decimal(15,2) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('1','300.00','2075.35','18503.06','2005.48','2101000.00','2161000.00','0.00','2000.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('2','10200.00','5040.03','10161547.89','302.41','100000.00','200000.00','0.00','500000.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('3','0.00','0.00','9990.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('4','10701.15','108073.18','481424.96','425728.03','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('5','0.00','0.00','0.40','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('6','1812.00','1717.64','25321.20','50229.03','30000.00','30100.00','0.00','2000.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('8','0.00','0.00','8990.01','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('9','0.00','1015.02','7990.00','1015.03','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('11','0.00','0.00','20000.00','0.00','1000000.00','1000000.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('12','150.00','870.46','9175.96','0.00','10000.00','10600.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('13','69850.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('14','300.45','2585.53','6768.50','515.76','10000.00','10000.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('15','10000.00','504.03','89480.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('18','0.00','212.96','99800.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('20','0.00','200.64','4790.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('23','0.00','0.00','10002190.00','0.00','1000.00','1000.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('25','0.00','0.00','9990000.00','10010.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('26','0.00','0.00','99858.75','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('27','0.00','2005.34','8000.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('29','0.00','808.20','200.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_money` */
 INSERT INTO `shang_member_money` VALUES ('30','0.00','1003.20','999998990.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_moneylog`*/ 
 DROP TABLE IF EXISTS `shang_member_moneylog`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_moneylog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `affect_money` decimal(15,2) NOT NULL COMMENT '影响金额',
  `account_money` decimal(15,2) NOT NULL COMMENT '充值资金存放池_可用余额',
  `back_money` decimal(15,2) NOT NULL COMMENT '回款资金存放池_可用余额',
  `collect_money` decimal(15,2) NOT NULL COMMENT '待收金额',
  `freeze_money` decimal(15,2) NOT NULL COMMENT '冻结金额',
  `info` varchar(50) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `target_uid` int(11) NOT NULL DEFAULT '0',
  `target_uname` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1071 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1','2','27','100000.00','100000.00','0.00','0.00','0.00','管理员手动审核充值','1453769655','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('2','4','27','1000000.00','1000000.00','0.00','0.00','0.00','管理员手动审核充值','1453769659','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('3','2','27','10000000.00','10100000.00','0.00','0.00','0.00','管理员手动审核充值','1453769665','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('4','2','14','-10.00','10099990.00','0.00','0.00','0.00','升级VIP成功','1453769711','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('5','4','14','-10.00','999990.00','0.00','0.00','0.00','升级VIP成功','1453776255','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('6','4','6','-200000.00','799990.00','0.00','0.00','200000.00','对4号标进行投标','1453776404','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('7','1','3','10000.00','10000.00','0.00','0.00','0.00','管理员手动审核充值','1453794094','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('8','6','7','10000.00','10000.00','0.00','0.00','0.00','0','1453794458','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('9','6','7','60000.00','70000.00','0.00','0.00','0.00','0','1453794541','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('10','6','6','-60000.00','10000.00','0.00','0.00','60000.00','对3号标进行投标','1453794641','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('11','1','17','60000.00','70000.00','0.00','0.00','0.00','第3号标复审通过，借款金额入帐','1453794711','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('12','1','19','-6000.00','64000.00','0.00','0.00','6000.00','第3号标借款成功，冻结10%的保证金','1453794711','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('13','6','15','60000.00','10000.00','0.00','60000.00','0.00','第3号标复审通过，冻结本金成为待收金额','1453794711','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('14','6','28','1964.01','10000.00','0.00','61964.01','0.00','第3号标复审通过，应收利息成为待收利息','1453794711','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('15','1','13','1.96','64001.96','0.00','0.00','6000.00','15553833036对3号标投资成功，你获得推广奖励1.96元。','1453794711','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('16','1','11','-12392.80','51609.16','0.00','0.00','6000.00','对3号标第1期还款','1453794890','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('17','6','9','12392.80','10000.00','12392.80','49571.21','0.00','收到会员对3号标第1期的还款','1453794890','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('18','6','23','-442.00','10000.00','11950.80','49571.21','0.00','网站已将第3号标第1期还款的利息管理费扣除','1453794890','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('19','6','99','500.00','10000.00','12450.80','49571.21','0.00','收到3号标2号投资11号加息券第1期还款的加息券收益','1453794890','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('20','1','11','-12392.81','39216.35','0.00','0.00','6000.00','对3号标第2期还款','1453794891','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('21','6','9','12392.81','10000.00','24843.61','37178.40','0.00','收到会员对3号标第2期的还款','1453794891','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('22','6','23','-355.49','10000.00','24488.12','37178.40','0.00','网站已将第3号标第2期还款的利息管理费扣除','1453794891','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('23','6','99','401.65','10000.00','24889.77','37178.40','0.00','收到3号标2号投资11号加息券第2期还款的加息券收益','1453794891','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('24','1','11','-12392.80','26823.55','0.00','0.00','6000.00','对3号标第3期还款','1453794892','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('25','6','9','12392.80','10000.00','37282.57','24785.60','0.00','收到会员对3号标第3期的还款','1453794892','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('26','6','23','-268.05','10000.00','37014.52','24785.60','0.00','网站已将第3号标第3期还款的利息管理费扣除','1453794892','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('27','6','99','302.49','10000.00','37317.01','24785.60','0.00','收到3号标2号投资11号加息券第3期还款的加息券收益','1453794892','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('28','1','11','-12392.80','14430.75','0.00','0.00','6000.00','对3号标第4期还款','1453795041','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('29','6','9','12392.80','10000.00','49709.81','12392.80','0.00','收到会员对3号标第4期的还款','1453795041','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('30','6','23','-179.66','10000.00','49530.15','12392.80','0.00','网站已将第3号标第4期还款的利息管理费扣除','1453795041','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('31','6','99','202.49','10000.00','49732.64','12392.80','0.00','收到3号标2号投资11号加息券第4期还款的加息券收益','1453795041','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('32','1','11','-12392.80','2037.95','0.00','0.00','6000.00','对3号标第5期还款','1453795042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('33','6','9','12392.80','10000.00','62125.44','0.00','0.00','收到会员对3号标第5期的还款','1453795042','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('34','6','23','-90.32','10000.00','62035.12','0.00','0.00','网站已将第3号标第5期还款的利息管理费扣除','1453795042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('35','6','99','101.67','10000.00','62136.79','0.00','0.00','收到3号标2号投资11号加息券第5期还款的加息券收益','1453795042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('36','1','24','6000.00','8037.95','0.00','0.00','0.00','网站对3号标还款完成的解冻保证金','1453795042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('37','4','6','-300000.00','499990.00','0.00','0.00','500000.00','对4号标进行投标','1453796137','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('38','1','6','-1000.00','7037.95','0.00','0.00','1000.00','对5号标进行投标','1453796188','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('39','2','17','500000.00','10599990.00','0.00','0.00','0.00','第4号标复审通过，借款金额入帐','1453796192','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('40','2','19','-50000.00','10549990.00','0.00','0.00','50000.00','第4号标借款成功，冻结10%的保证金','1453796192','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('41','4','15','200000.00','499990.00','0.00','200000.00','300000.00','第4号标复审通过，冻结本金成为待收金额','1453796192','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('42','4','28','10000.02','499990.00','0.00','210000.02','300000.00','第4号标复审通过，应收利息成为待收利息','1453796192','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('43','2','13','10.00','10550000.00','0.00','0.00','50000.00','13706360071对4号标投资成功，你获得推广奖励10.00元。','1453796192','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('44','4','15','300000.00','499990.00','0.00','510000.02','0.00','第4号标复审通过，冻结本金成为待收金额','1453796192','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('45','4','28','15000.00','499990.00','0.00','525000.02','0.00','第4号标复审通过，应收利息成为待收利息','1453796192','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('46','2','13','15.00','10550015.00','0.00','0.00','50000.00','13706360071对4号标投资成功，你获得推广奖励15.00元。','1453796192','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('47','1','6','-1000.00','6037.95','0.00','0.00','2000.00','对5号标进行投标','1453796199','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('48','6','17','2000.00','12000.00','62136.79','0.00','0.00','第5号标复审通过，借款金额入帐','1453796210','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('49','6','19','-200.00','11800.00','62136.79','0.00','200.00','第5号标借款成功，冻结10%的保证金','1453796210','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('50','1','20','50.00','6087.95','0.00','0.00','2000.00','第5号标复审通过，获取投标奖励','1453796210','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('51','6','21','-50.00','11750.00','62136.79','0.00','200.00','第5号标复审通过，支付投标奖励','1453796210','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('52','1','15','1000.00','6087.95','0.00','1000.00','1000.00','第5号标复审通过，冻结本金成为待收金额','1453796210','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('53','1','28','2.74','6087.95','0.00','1002.74','1000.00','第5号标复审通过，应收利息成为待收利息','1453796210','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('54','1','20','50.00','6137.95','0.00','1002.74','1000.00','第5号标复审通过，获取投标奖励','1453796210','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('55','6','21','-50.00','11700.00','62136.79','0.00','200.00','第5号标复审通过，支付投标奖励','1453796210','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('56','1','15','1000.00','6137.95','0.00','2002.74','0.00','第5号标复审通过，冻结本金成为待收金额','1453796210','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('57','1','28','2.74','6137.95','0.00','2005.48','0.00','第5号标复审通过，应收利息成为待收利息','1453796210','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('58','6','37','-100.00','11700.00','62036.79','0.00','300.00','对2号优计划进行了投标','1453796549','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('59','1','17','100.00','6237.95','0.00','2005.48','0.00','第2号优计划已被认购100元，100元已入帐','1453796549','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('60','6','39','100.00','11700.00','62036.79','100.00','200.00','您对第2号优计划投标成功，冻结本金成为待收金额','1453796549','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('61','6','38','0.78','11700.00','62036.79','100.78','200.00','第2号优计划应收利息成为待收利息','1453796549','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('62','1','13','0.10','6238.05','0.00','2005.48','0.00','15553833036对2号标投资成功，你获得推广奖励0.10元。','1453796549','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('63','6','37','-200.00','11700.00','61836.79','100.78','400.00','对3号优计划进行了投标','1453796807','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('64','1','17','200.00','6438.05','0.00','2005.48','0.00','第3号优计划已被认购200元，200元已入帐','1453796807','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('65','6','39','200.00','11700.00','61836.79','300.78','200.00','您对第3号优计划投标成功，冻结本金成为待收金额','1453796807','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('66','6','38','1.60','11700.00','61836.79','302.38','200.00','第3号优计划应收利息成为待收利息','1453796807','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('67','1','13','0.20','6438.25','0.00','2005.48','0.00','15553833036对3号标投资成功，你获得推广奖励0.20元。','1453796807','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('68','6','40','0.40','11700.40','61836.79','302.38','200.00','优计划续投有效金额(200)的奖励(3号优计划)奖励','1453796807','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('69','1','37','-300.00','6138.25','0.00','2005.48','300.00','对4号优计划进行了投标','1453797629','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('70','6','17','300.00','12000.40','61836.79','302.38','200.00','第4号优计划已被认购300元，300元已入帐','1453797629','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('71','1','39','300.00','6138.25','0.00','2305.48','0.00','您对第4号优计划投标成功，冻结本金成为待收金额','1453797629','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('72','1','38','2.40','6138.25','0.00','2307.88','0.00','第4号优计划应收利息成为待收利息','1453797629','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('73','1','6','-100.00','6038.25','0.00','2307.88','100.00','对8号标进行投标','1453798834','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('74','6','17','100.00','12100.40','61836.79','302.38','200.00','第8号标复审通过，借款金额入帐','1453799042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('75','6','19','-10.00','12090.40','61836.79','302.38','210.00','第8号标借款成功，冻结10%的保证金','1453799042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('76','1','20','2.00','6040.25','0.00','2307.88','100.00','第8号标复审通过，获取投标奖励','1453799042','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('77','6','21','-2.00','12088.40','61836.79','302.38','210.00','第8号标复审通过，支付投标奖励','1453799042','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('78','1','15','100.00','6040.25','0.00','2407.88','0.00','第8号标复审通过，冻结本金成为待收金额','1453799042','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('79','1','28','0.10','6040.25','0.00','2407.98','0.00','第8号标复审通过，应收利息成为待收利息','1453799042','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('80','6','6','-1000.00','12088.40','60836.79','302.38','1210.00','对6号标进行投标','1453800460','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('81','6','33','1.00','12088.40','60836.79','302.38','1211.00','续投有效金额(1000)的奖励(6号标)预奖励','1453800460','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('82','6','6','-1000.00','12088.40','59836.79','302.38','2211.00','对6号标进行投标','1453801319','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('83','6','33','1.00','12088.40','59836.79','302.38','2212.00','续投有效金额(1000)的奖励(6号标)预奖励','1453801319','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('84','6','6','-1000.00','12088.40','58836.79','302.38','3212.00','对9号标进行投标','1453858848','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('85','6','33','1.00','12088.40','58836.79','302.38','3213.00','续投有效金额(1000)的奖励(9号标)预奖励','1453858848','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('86','1','17','1000.00','7040.25','0.00','2407.98','0.00','第9号标复审通过，借款金额入帐','1453858877','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('87','1','19','-100.00','6940.25','0.00','2407.98','100.00','第9号标借款成功，冻结10%的保证金','1453858877','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('88','6','15','1000.00','12088.40','58836.79','1302.38','2213.00','第9号标复审通过，冻结本金成为待收金额','1453858877','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('89','6','28','8.33','12088.40','58836.79','1310.71','2213.00','第9号标复审通过，应收利息成为待收利息','1453858877','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('90','1','13','0.01','6940.26','0.00','2407.98','100.00','15553833036对9号标投资成功，你获得推广奖励0.01元。','1453858877','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('91','6','34','1.00','12089.40','58836.79','1310.71','2212.00','续投奖励(9号标)预奖励到账','1453858877','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('92','1','6','-100.00','6840.26','0.00','2407.98','200.00','对11号标进行投标','1453861214','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('93','6','17','100.00','12189.40','58836.79','1310.71','2212.00','第11号标复审通过，借款金额入帐','1453861246','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('94','6','19','-10.00','12179.40','58836.79','1310.71','2222.00','第11号标借款成功，冻结10%的保证金','1453861246','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('95','1','20','2.00','6842.26','0.00','2407.98','200.00','第11号标复审通过，获取投标奖励','1453861246','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('96','6','21','-2.00','12177.40','58836.79','1310.71','2222.00','第11号标复审通过，支付投标奖励','1453861246','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('97','1','15','100.00','6842.26','0.00','2507.98','100.00','第11号标复审通过，冻结本金成为待收金额','1453861246','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('98','1','28','0.10','6842.26','0.00','2508.08','100.00','第11号标复审通过，应收利息成为待收利息','1453861246','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('99','6','11','-100.10','12177.40','58736.69','1310.71','2222.00','对11号标第1期还款','1453861536','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('100','1','9','100.10','6842.26','100.10','2407.98','100.00','收到会员对11号标第1期的还款','1453861536','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('101','1','23','-0.07','6842.26','100.03','2407.98','100.00','网站已将第11号标第1期还款的利息管理费扣除','1453861536','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('102','1','99','0.08','6842.26','100.11','2407.98','100.00','收到11号标10号投资24号加息券第1期还款的加息券收益','1453861536','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('103','6','24','10.00','12187.40','58736.69','1310.71','2212.00','网站对11号标还款完成的解冻保证金','1453861536','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('104','1','6','-200.00','6742.37','0.00','2407.98','300.00','对12号标进行投标','1453862333','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('105','6','17','200.00','12387.40','58736.69','1310.71','2212.00','第12号标复审通过，借款金额入帐','1453862333','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('106','6','19','-20.00','12367.40','58736.69','1310.71','2232.00','第12号标借款成功，冻结10%的保证金','1453862333','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('107','1','20','10.00','6752.37','0.00','2407.98','300.00','第12号标复审通过，获取投标奖励','1453862333','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('108','6','21','-10.00','12357.40','58736.69','1310.71','2232.00','第12号标复审通过，支付投标奖励','1453862333','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('109','1','15','200.00','6752.37','0.00','2607.98','100.00','第12号标复审通过，冻结本金成为待收金额','1453862333','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('110','1','28','2.00','6752.37','0.00','2609.98','100.00','第12号标复审通过，应收利息成为待收利息','1453862334','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('111','6','11','-202.00','12357.40','58534.69','1310.71','2232.00','对12号标第1期还款','1453862337','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('112','1','9','202.00','6954.37','0.00','2407.98','100.00','收到会员对12号标第1期的还款','1453862337','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('113','1','23','-1.36','6953.01','0.00','2407.98','100.00','网站已将第12号标第1期还款的利息管理费扣除','1453862337','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('114','1','99','1.67','6953.01','1.67','2407.98','100.00','收到12号标11号投资30号加息券第1期还款的加息券收益','1453862337','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('115','6','24','20.00','12377.40','58534.69','1310.71','2212.00','网站对12号标还款完成的解冻保证金','1453862337','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('116','9','7','10000.00','10000.00','0.00','0.00','0.00','1','1453862617','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('117','9','6','-500.00','9500.00','0.00','0.00','500.00','对13号标进行投标','1453862628','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('118','9','6','-1500.00','8000.00','0.00','0.00','2000.00','对13号标进行投标','1453862635','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('119','2','17','2000.00','10552015.00','0.00','0.00','50000.00','第13号标复审通过，借款金额入帐','1453862648','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('120','2','19','-200.00','10551815.00','0.00','0.00','50200.00','第13号标借款成功，冻结10%的保证金','1453862648','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('121','9','15','500.00','8000.00','0.00','500.00','1500.00','第13号标复审通过，冻结本金成为待收金额','1453862648','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('122','9','28','7.51','8000.00','0.00','507.51','1500.00','第13号标复审通过，应收利息成为待收利息','1453862648','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('123','9','15','1500.00','8000.00','0.00','2007.51','0.00','第13号标复审通过，冻结本金成为待收金额','1453862648','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('124','9','28','22.54','8000.00','0.00','2030.05','0.00','第13号标复审通过，应收利息成为待收利息','1453862648','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('125','4','37','-10000.00','489990.00','0.00','525000.02','10000.00','对5号优计划进行了投标','1453864198','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('126','1','17','10000.00','16953.01','1.67','2407.98','100.00','第5号优计划已被认购10000元，10000元已入帐','1453864198','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('127','4','39','10000.00','489990.00','0.00','535000.02','0.00','您对第5号优计划投标成功，冻结本金成为待收金额','1453864198','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('128','4','38','26.67','489990.00','0.00','535026.69','0.00','第5号优计划应收利息成为待收利息','1453864198','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('129','2','13','10.00','10551825.00','0.00','0.00','50200.00','13706360071对5号标投资成功，你获得推广奖励10.00元。','1453864198','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('130','1','37','-1000.00','15954.68','0.00','2407.98','1100.00','对6号优计划进行了投标','1453864718','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('131','6','17','1000.00','13377.40','58534.69','1310.71','2212.00','第6号优计划已被认购1000元，1000元已入帐','1453864718','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('132','1','39','1000.00','15954.68','0.00','3407.98','100.00','您对第6号优计划投标成功，冻结本金成为待收金额','1453864718','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('133','1','38','13.60','15954.68','0.00','3421.58','100.00','第6号优计划应收利息成为待收利息','1453864718','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('134','6','13','1.00','13378.40','58534.69','1310.71','2212.00','18661395415对6号标投资成功，你获得推广奖励1.00元。','1453864718','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('136','4','3','10000.00','499990.00','0.00','535026.69','0.00','管理员手动审核充值','1453865117','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('137','4','4','-10000.00','489990.00','0.00','535026.69','10000.00','提现,默认自动扣减手续费50元','1453865656','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('138','4','36','-10000.00','489940.00','0.00','535026.69','10000.00','提现申请已通过，扣除实际手续费50元，到帐金额10000.00元','1453865685','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('139','1','6','-100.00','15854.68','0.00','3421.58','200.00','对15号标进行投标','1453875275','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('140','8','3','0.01','0.01','0.00','0.00','0.00','充值订单号:20160129114410911663','1454039132','211.152.0.134','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('141','12','3','10000.00','10000.00','0.00','0.00','0.00','管理员手动审核充值','1454119462','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('142','12','6','-1000.00','9000.00','0.00','0.00','1000.00','对16号标进行投标','1454120475','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('143','6','17','1000.00','14378.40','58534.69','1310.71','2212.00','第16号标复审通过，借款金额入帐','1454120506','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('144','6','19','-100.00','14278.40','58534.69','1310.71','2312.00','第16号标借款成功，冻结10%的保证金','1454120506','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('145','12','20','10.00','9010.00','0.00','0.00','1000.00','第16号标复审通过，获取投标奖励','1454120506','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('146','6','21','-10.00','14268.40','58534.69','1310.71','2312.00','第16号标复审通过，支付投标奖励','1454120506','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('147','12','15','1000.00','9010.00','0.00','1000.00','0.00','第16号标复审通过，冻结本金成为待收金额','1454120506','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('148','12','28','10.00','9010.00','0.00','1010.00','0.00','第16号标复审通过，应收利息成为待收利息','1454120506','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('149','6','13','0.02','14268.42','58534.69','1310.71','2312.00','17853738946对16号标投资成功，你获得推广奖励0.02元。','1454120506','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('150','6','11','-1010.00','14268.42','57524.69','1310.71','2312.00','对16号标第1期还款','1454121603','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('151','12','9','1010.00','9010.00','1010.00','0.00','0.00','收到会员对16号标第1期的还款','1454121603','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('152','12','23','-6.80','9010.00','1003.20','0.00','0.00','网站已将第16号标第1期还款的利息管理费扣除','1454121603','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('153','12','99','8.33','9010.00','1011.53','0.00','0.00','收到16号标15号投资49号加息券第1期还款的加息券收益','1454121603','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('154','6','24','100.00','14368.42','57524.69','1310.71','2212.00','网站对16号标还款完成的解冻保证金','1454121603','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('155','12','6','-100.00','9010.00','911.53','0.00','100.00','对17号标进行投标','1454123863','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('156','12','33','0.10','9010.00','911.53','0.00','100.10','续投有效金额(100)的奖励(17号标)预奖励','1454123863','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('157','6','17','100.00','14468.42','57524.69','1310.71','2212.00','第17号标复审通过，借款金额入帐','1454123888','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('158','6','19','-10.00','14458.42','57524.69','1310.71','2222.00','第17号标借款成功，冻结10%的保证金','1454123888','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('159','12','15','100.00','9010.00','911.53','100.00','0.10','第17号标复审通过，冻结本金成为待收金额','1454123888','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('160','12','28','0.03','9010.00','911.53','100.03','0.10','第17号标复审通过，应收利息成为待收利息','1454123888','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('161','12','34','0.10','9010.10','911.53','100.03','0.00','续投奖励(17号标)预奖励到账','1454123888','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('162','6','11','-100.03','14458.42','57424.66','1310.71','2222.00','对17号标第1期还款','1454124066','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('163','12','9','100.03','9010.10','1011.56','0.00','0.00','收到会员对17号标第1期的还款','1454124066','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('164','12','23','-0.02','9010.10','1011.54','0.00','0.00','网站已将第17号标第1期还款的利息管理费扣除','1454124066','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('165','6','24','10.00','14468.42','57424.66','1310.71','2212.00','网站对17号标还款完成的解冻保证金','1454124066','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('166','12','14','-10.00','9000.10','1011.54','0.00','0.00','升级VIP成功','1454125423','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('167','12','6','-100.00','9000.10','911.54','0.00','100.00','对18号标进行投标','1454125550','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('168','12','33','0.15','9000.10','911.54','0.00','100.15','续投有效金额(100)的奖励(18号标)预奖励','1454125550','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('169','6','17','100.00','14568.42','57424.66','1310.71','2212.00','第18号标复审通过，借款金额入帐','1454125568','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('170','6','19','-10.00','14558.42','57424.66','1310.71','2222.00','第18号标借款成功，冻结10%的保证金','1454125568','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('171','12','15','100.00','9000.10','911.54','100.00','0.15','第18号标复审通过，冻结本金成为待收金额','1454125568','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('172','12','28','1.50','9000.10','911.54','101.50','0.15','第18号标复审通过，应收利息成为待收利息','1454125568','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('173','12','34','0.15','9000.25','911.54','101.50','0.00','续投奖励(18号标)预奖励到账','1454125568','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('174','6','11','-50.75','14558.42','57373.91','1310.71','2222.00','对18号标第1期还款','1454125607','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('175','12','9','50.75','9000.25','962.29','50.75','0.00','收到会员对18号标第1期的还款','1454125607','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('176','12','23','-0.68','9000.25','961.61','50.75','0.00','网站已将第18号标第1期还款的利息管理费扣除','1454125607','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('177','6','11','-50.75','14558.42','57323.16','1310.71','2222.00','对18号标第2期还款','1454125609','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('178','12','9','50.75','9000.25','1012.36','0.00','0.00','收到会员对18号标第2期的还款','1454125609','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('179','12','23','-0.34','9000.25','1012.02','0.00','0.00','网站已将第18号标第2期还款的利息管理费扣除','1454125609','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('180','6','24','10.00','14568.42','57323.16','1310.71','2212.00','网站对18号标还款完成的解冻保证金','1454125609','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('181','4','6','-200.00','489740.00','0.00','535026.69','10200.00','对19号标进行投标','1454125962','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('182','6','6','-800.00','14568.42','56523.16','1310.71','3012.00','对19号标进行投标','1454126059','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('183','6','33','0.80','14568.42','56523.16','1310.71','3012.80','续投有效金额(800)的奖励(19号标)预奖励','1454126059','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('184','12','17','1000.00','10000.25','1012.02','0.00','0.00','第19号标复审通过，借款金额入帐','1454132032','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('185','12','19','-100.00','9900.25','1012.02','0.00','100.00','第19号标借款成功，冻结10%的保证金','1454132032','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('186','4','15','200.00','489740.00','0.00','535226.69','10000.00','第19号标复审通过，冻结本金成为待收金额','1454132032','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('187','4','28','2.00','489740.00','0.00','535228.69','10000.00','第19号标复审通过，应收利息成为待收利息','1454132032','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('188','6','15','800.00','14568.42','56523.16','2110.71','2212.80','第19号标复审通过，冻结本金成为待收金额','1454132032','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('189','6','28','8.00','14568.42','56523.16','2118.71','2212.80','第19号标复审通过，应收利息成为待收利息','1454132032','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('190','1','13','0.02','15854.70','0.00','3421.58','200.00','15553833036对19号标投资成功，你获得推广奖励0.02元。','1454132032','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('191','6','34','0.80','14569.22','56523.16','2118.71','2212.00','续投奖励(19号标)预奖励到账','1454132032','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('192','12','11','-1010.00','9900.25','2.02','0.00','100.00','对19号标第1期还款','1456898022','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('193','4','9','202.00','489740.00','202.00','535026.69','10000.00','收到会员对19号标第1期的还款','1456898022','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('194','4','23','-1.36','489740.00','200.64','535026.69','10000.00','网站已将第19号标第1期还款的利息管理费扣除','1456898022','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('195','6','9','808.00','14569.22','57331.16','1310.71','2212.00','收到会员对19号标第1期的还款','1456898022','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('196','6','23','-5.44','14569.22','57325.72','1310.71','2212.00','网站已将第19号标第1期还款的利息管理费扣除','1456898022','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('197','6','99','6.67','14569.22','57332.39','1310.71','2212.00','收到19号标19号投资43号加息券第1期还款的加息券收益','1456898022','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('198','12','24','100.00','10000.25','2.02','0.00','0.00','网站对19号标还款完成的解冻保证金','1456898022','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('199','6','6','-2000.00','14569.22','55332.39','1310.71','4212.00','对20号标进行投标','1454134166','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('200','6','33','4.00','14569.22','55332.39','1310.71','4216.00','续投有效金额(2000)的奖励(20号标)预奖励','1454134166','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('201','1','17','2000.00','17854.70','0.00','3421.58','200.00','第20号标复审通过，借款金额入帐','1454134187','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('202','1','19','-200.00','17654.70','0.00','3421.58','400.00','第20号标借款成功，冻结10%的保证金','1454134187','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('203','6','15','2000.00','14569.22','55332.39','3310.71','2216.00','第20号标复审通过，冻结本金成为待收金额','1454134187','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('204','6','28','33.43','14569.22','55332.39','3344.14','2216.00','第20号标复审通过，应收利息成为待收利息','1454134187','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('205','1','13','0.07','17654.77','0.00','3421.58','400.00','15553833036对20号标投资成功，你获得推广奖励0.07元。','1454134187','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('206','6','34','4.00','14573.22','55332.39','3344.14','2212.00','续投奖励(20号标)预奖励到账','1454134187','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('207','1','11','-677.81','16976.96','0.00','3421.58','400.00','对20号标第1期还款','1462601570','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('208','1','30','-454.13','16522.83','0.00','3421.58','400.00','20号标第1期的逾期罚息','1462601570','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('209','1','31','-45.41','16477.42','0.00','3421.58','400.00','网站对借款人收取的第20号标第1期的逾期催收费','1462601570','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('210','6','9','677.81','14573.22','56010.20','2666.33','2212.00','收到会员对20号标第1期的还款','1462601570','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('211','6','23','-11.33','14573.22','55998.87','2666.33','2212.00','网站已将第20号标第1期还款的利息管理费扣除','1462601570','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('212','1','11','-677.81','15799.61','0.00','3421.58','400.00','对20号标第2期还款','1462601571','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('213','1','30','-257.57','15542.04','0.00','3421.58','400.00','20号标第2期的逾期罚息','1462601571','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('214','1','31','-25.76','15516.28','0.00','3421.58','400.00','网站对借款人收取的第20号标第2期的逾期催收费','1462601571','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('215','6','9','677.81','14573.22','56676.68','1988.52','2212.00','收到会员对20号标第2期的还款','1462601571','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('216','6','23','-7.59','14573.22','56669.09','1988.52','2212.00','网站已将第20号标第2期还款的利息管理费扣除','1462601571','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('217','1','11','-677.81','14838.47','0.00','3421.58','400.00','对20号标第3期还款','1462601572','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('218','1','30','-47.45','14791.02','0.00','3421.58','400.00','20号标第3期的逾期罚息','1462601572','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('219','1','31','-4.74','14786.28','0.00','3421.58','400.00','网站对借款人收取的第20号标第3期的逾期催收费','1462601572','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('220','6','9','677.81','14573.22','57346.90','1310.71','2212.00','收到会员对20号标第3期的还款','1462601572','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('221','6','23','-3.81','14573.22','57343.09','1310.71','2212.00','网站已将第20号标第3期还款的利息管理费扣除','1462601572','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('222','1','24','200.00','14986.28','0.00','3421.58','200.00','网站对20号标还款完成的解冻保证金','1462601572','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('223','6','6','-100.00','14573.22','57243.09','1310.71','2312.00','对21号标进行投标','1454134605','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('224','6','33','0.10','14573.22','57243.09','1310.71','2312.10','续投有效金额(100)的奖励(21号标)预奖励','1454134605','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('225','12','17','100.00','10100.25','2.02','0.00','0.00','第21号标复审通过，借款金额入帐','1454134658','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('226','12','19','-10.00','10090.25','2.02','0.00','10.00','第21号标借款成功，冻结10%的保证金','1454134658','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('227','6','15','100.00','14573.22','57243.09','1410.71','2212.10','第21号标复审通过，冻结本金成为待收金额','1454134658','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('228','6','28','1.00','14573.22','57243.09','1411.71','2212.10','第21号标复审通过，应收利息成为待收利息','1454134658','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('229','6','34','0.10','14573.32','57243.09','1411.71','2212.00','续投奖励(21号标)预奖励到账','1454134658','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('230','12','11','-101.00','9991.27','0.00','0.00','10.00','对21号标第1期还款','1457158800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('231','12','30','-4.04','9987.23','0.00','0.00','10.00','21号标第1期的逾期罚息','1457158800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('232','12','31','-0.40','9986.83','0.00','0.00','10.00','网站对借款人收取的第21号标第1期的逾期催收费','1457158800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('233','6','9','101.00','14573.32','57344.09','1310.71','2212.00','收到会员对21号标第1期的还款','1457158800','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('234','6','23','-0.68','14573.32','57343.41','1310.71','2212.00','网站已将第21号标第1期还款的利息管理费扣除','1457158800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('235','12','24','10.00','9996.83','0.00','0.00','0.00','网站对21号标还款完成的解冻保证金','1457158800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('236','1','11','-1008.33','13977.95','0.00','3421.58','200.00','对9号标第1期还款','1454141593','222.173.174.202','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('237','6','9','1008.33','14573.32','58351.74','302.38','2212.00','收到会员对9号标第1期的还款','1454141593','222.173.174.202','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('238','6','23','-5.67','14573.32','58346.07','302.38','2212.00','网站已将第9号标第1期还款的利息管理费扣除','1454141593','222.173.174.202','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('239','1','24','100.00','14077.95','0.00','3421.58','100.00','网站对9号标还款完成的解冻保证金','1454141593','222.173.174.202','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('240','3','27','10000.00','10000.00','0.00','0.00','0.00','管理员手动审核充值','1454292879','222.173.174.202','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('241','3','14','-10.00','9990.00','0.00','0.00','0.00','升级VIP成功','1454292931','222.173.174.202','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('242','4','6','-1000.00','488940.64','0.00','535026.69','11000.00','对28号标进行投标','1455500636','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('243','4','33','0.20','488940.64','0.00','535026.69','11000.20','续投有效金额(200.64)的奖励(28号标)预奖励','1455500636','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('244','4','37','-100.00','488840.64','0.00','535026.69','11100.20','对4号优计划进行了投标','1455500673','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('245','6','17','100.00','14673.32','58346.07','302.38','2212.00','第4号优计划已被认购100元，100元已入帐','1455500673','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('246','4','39','100.00','488840.64','0.00','535126.69','11000.20','您对第4号优计划投标成功，冻结本金成为待收金额','1455500673','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('247','4','38','0.78','488840.64','0.00','535127.47','11000.20','第4号优计划应收利息成为待收利息','1455500673','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('248','2','13','0.20','10551825.20','0.00','0.00','50200.00','13706360071对4号标投资成功，你获得推广奖励0.20元。','1455500673','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('249','4','37','-100.00','488740.64','0.00','535127.47','11100.20','对4号优计划进行了投标','1455500701','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('250','6','17','100.00','14773.32','58346.07','302.38','2212.00','第4号优计划已被认购100元，100元已入帐','1455500701','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('251','4','39','100.00','488740.64','0.00','535227.47','11000.20','您对第4号优计划投标成功，冻结本金成为待收金额','1455500701','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('252','4','38','0.78','488740.64','0.00','535228.25','11000.20','第4号优计划应收利息成为待收利息','1455500701','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('253','2','13','0.20','10551825.40','0.00','0.00','50200.00','13706360071对4号标投资成功，你获得推广奖励0.20元。','1455500701','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('254','1','17','2000.00','16077.95','0.00','3421.58','100.00','第6号标复审通过，借款金额入帐','1455503042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('255','1','19','-200.00','15877.95','0.00','3421.58','300.00','第6号标借款成功，冻结10%的保证金','1455503042','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('256','6','15','1000.00','14773.32','58346.07','1302.38','1212.00','第6号标复审通过，冻结本金成为待收金额','1455503042','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('257','6','28','8.33','14773.32','58346.07','1310.71','1212.00','第6号标复审通过，应收利息成为待收利息','1455503042','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('258','1','13','0.02','15877.97','0.00','3421.58','300.00','15553833036对6号标投资成功，你获得推广奖励0.02元。','1455503042','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('259','6','15','1000.00','14773.32','58346.07','2310.71','212.00','第6号标复审通过，冻结本金成为待收金额','1455503042','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('260','6','28','8.33','14773.32','58346.07','2319.04','212.00','第6号标复审通过，应收利息成为待收利息','1455503042','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('261','1','13','0.02','15877.99','0.00','3421.58','300.00','15553833036对6号标投资成功，你获得推广奖励0.02元。','1455503042','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('262','6','34','1.00','14774.32','58346.07','2319.04','211.00','续投奖励(6号标)预奖励到账','1455503043','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('263','6','34','1.00','14775.32','58346.07','2319.04','210.00','续投奖励(6号标)预奖励到账','1455503043','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('264','1','14','-10.00','15867.99','0.00','3421.58','300.00','升级VIP成功','1455503115','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('265','6','14','-10.00','14765.32','58346.07','2319.04','210.00','升级VIP成功','1455503125','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('266','4','6','-9000.00','479740.64','0.00','535228.25','20000.20','对28号标进行投标','1455503950','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('267','2','17','10000.00','10561825.40','0.00','0.00','50200.00','第28号标复审通过，借款金额入帐','1455503974','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('268','2','19','-1000.00','10560825.40','0.00','0.00','51200.00','第28号标借款成功，冻结10%的保证金','1455503974','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('269','4','15','1000.00','479740.64','0.00','536228.25','19000.20','第28号标复审通过，冻结本金成为待收金额','1455503974','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('270','4','28','0.82','479740.64','0.00','536229.07','19000.20','第28号标复审通过，应收利息成为待收利息','1455503974','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('271','4','15','9000.00','479740.64','0.00','545229.07','10000.20','第28号标复审通过，冻结本金成为待收金额','1455503974','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('272','4','28','7.40','479740.64','0.00','545236.47','10000.20','第28号标复审通过，应收利息成为待收利息','1455503974','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('273','4','34','0.20','479740.84','0.00','545236.47','10000.00','续投奖励(28号标)预奖励到账','1455503974','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('274','2','11','-10008.22','10550817.18','0.00','0.00','51200.00','对28号标第1期还款','1455505769','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('275','4','9','1000.82','479740.84','1000.82','544235.65','10000.00','收到会员对28号标第1期的还款','1455505769','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('276','4','23','-0.56','479740.84','1000.26','544235.65','10000.00','网站已将第28号标第1期还款的利息管理费扣除','1455505769','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('277','4','9','9007.40','479740.84','10007.66','535228.25','10000.00','收到会员对28号标第1期的还款','1455505769','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('278','4','23','-5.03','479740.84','10002.63','535228.25','10000.00','网站已将第28号标第1期还款的利息管理费扣除','1455505769','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('279','2','24','1000.00','10551817.18','0.00','0.00','50200.00','网站对28号标还款完成的解冻保证金','1455505769','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('280','2','11','-4166.67','10547650.51','0.00','0.00','50200.00','对4号标第1期还款','1455505800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('281','4','9','1666.67','479740.84','11669.30','533561.58','10000.00','收到会员对4号标第1期的还款','1455505800','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('282','4','23','-1133.33','479740.84','10535.97','533561.58','10000.00','网站已将第4号标第1期还款的利息管理费扣除','1455505800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('283','4','9','2500.00','479740.84','13035.97','531061.58','10000.00','收到会员对4号标第1期的还款','1455505800','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('284','4','23','-1700.00','479740.84','11335.97','531061.58','10000.00','网站已将第4号标第1期还款的利息管理费扣除','1455505800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('285','4','99','2500.00','479740.84','13835.97','531061.58','10000.00','收到4号标3号投资4号加息券第1期还款的加息券收益','1455505800','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('286','2','11','-4166.67','10543483.84','0.00','0.00','50200.00','对4号标第2期还款','1455505802','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('287','4','9','1666.67','479740.84','15502.64','529394.91','10000.00','收到会员对4号标第2期的还款','1455505802','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('288','4','23','-1133.33','479740.84','14369.31','529394.91','10000.00','网站已将第4号标第2期还款的利息管理费扣除','1455505802','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('289','4','9','2500.00','479740.84','16869.31','526894.91','10000.00','收到会员对4号标第2期的还款','1455505802','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('290','4','23','-1700.00','479740.84','15169.31','526894.91','10000.00','网站已将第4号标第2期还款的利息管理费扣除','1455505802','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('291','4','99','2500.00','479740.84','17669.31','526894.91','10000.00','收到4号标3号投资4号加息券第2期还款的加息券收益','1455505802','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('292','2','11','-4166.67','10539317.17','0.00','0.00','50200.00','对4号标第3期还款','1455505806','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('293','4','9','1666.67','479740.84','19335.98','525228.24','10000.00','收到会员对4号标第3期的还款','1455505806','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('294','4','23','-1133.33','479740.84','18202.65','525228.24','10000.00','网站已将第4号标第3期还款的利息管理费扣除','1455505806','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('295','4','9','2500.00','479740.84','20702.65','522728.24','10000.00','收到会员对4号标第3期的还款','1455505806','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('296','4','23','-1700.00','479740.84','19002.65','522728.24','10000.00','网站已将第4号标第3期还款的利息管理费扣除','1455505806','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('297','4','99','2500.00','479740.84','21502.65','522728.24','10000.00','收到4号标3号投资4号加息券第3期还款的加息券收益','1455505806','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('298','2','11','-4166.67','10535150.50','0.00','0.00','50200.00','对4号标第4期还款','1455505808','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('299','4','9','1666.67','479740.84','23169.32','521061.57','10000.00','收到会员对4号标第4期的还款','1455505808','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('300','4','23','-1133.33','479740.84','22035.99','521061.57','10000.00','网站已将第4号标第4期还款的利息管理费扣除','1455505808','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('301','4','9','2500.00','479740.84','24535.99','518561.57','10000.00','收到会员对4号标第4期的还款','1455505808','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('302','4','23','-1700.00','479740.84','22835.99','518561.57','10000.00','网站已将第4号标第4期还款的利息管理费扣除','1455505808','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('303','4','99','2500.00','479740.84','25335.99','518561.57','10000.00','收到4号标3号投资4号加息券第4期还款的加息券收益','1455505808','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('304','2','11','-4166.67','10530983.83','0.00','0.00','50200.00','对4号标第5期还款','1455505811','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('305','4','9','1666.67','479740.84','27002.66','516894.90','10000.00','收到会员对4号标第5期的还款','1455505811','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('306','4','23','-1133.33','479740.84','25869.33','516894.90','10000.00','网站已将第4号标第5期还款的利息管理费扣除','1455505811','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('307','4','9','2500.00','479740.84','28369.33','514394.90','10000.00','收到会员对4号标第5期的还款','1455505811','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('308','4','23','-1700.00','479740.84','26669.33','514394.90','10000.00','网站已将第4号标第5期还款的利息管理费扣除','1455505811','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('309','4','99','2500.00','479740.84','29169.33','514394.90','10000.00','收到4号标3号投资4号加息券第5期还款的加息券收益','1455505811','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('310','2','11','-504166.67','10026817.16','0.00','0.00','50200.00','对4号标第6期还款','1455505813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('311','4','9','201666.67','479740.84','230836.00','312728.23','10000.00','收到会员对4号标第6期的还款','1455505813','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('312','4','23','-1133.33','479740.84','229702.67','312728.23','10000.00','网站已将第4号标第6期还款的利息管理费扣除','1455505813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('313','4','9','302500.00','479740.84','532202.67','10228.23','10000.00','收到会员对4号标第6期的还款','1455505813','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('314','4','23','-1700.00','479740.84','530502.67','10228.23','10000.00','网站已将第4号标第6期还款的利息管理费扣除','1455505813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('315','4','99','2500.00','479740.84','533002.67','10228.23','10000.00','收到4号标3号投资4号加息券第6期还款的加息券收益','1455505813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('316','2','24','50000.00','10076817.16','0.00','0.00','200.00','网站对4号标还款完成的解冻保证金','1455505813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('317','13','27','100000.00','100000.00','0.00','0.00','0.00','管理员手动审核充值','1455507267','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('318','13','4','-100.00','99900.00','0.00','0.00','100.00','提现,默认自动扣减手续费1元','1455507296','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('319','13','5','100.00','100000.00','0.00','0.00','0.00','撤消提现','1455507315','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('320','13','4','-10000.00','90000.00','0.00','0.00','10000.00','提现,默认自动扣减手续费50元','1455507376','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('321','13','36','-10000.00','89950.00','0.00','0.00','10000.00','提现申请已通过，扣除实际手续费50元，到帐金额10000.00元','1455507398','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('322','13','4','-29950.00','60000.00','0.00','0.00','39950.00','提现,默认自动扣减手续费50元','1455507492','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('323','13','4','-30000.00','30000.00','0.00','0.00','69950.00','提现,默认自动扣减手续费50元','1455507509','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('324','13','4','-30000.00','0.00','0.00','0.00','99950.00','提现,默认自动扣减手续费50元','1455507519','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('325','13','36','-29950.00','0.00','0.00','0.00','99900.00','提现申请已通过，扣除实际手续费50元，到帐金额29900元','1455507540','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('326','13','36','-30000.00','0.00','0.00','0.00','99850.00','提现申请已通过，扣除实际手续费50元，到帐金额29950元','1455507548','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('327','13','36','-30000.00','0.00','0.00','0.00','99800.00','提现申请已通过，扣除实际手续费50元，到帐金额29950元','1455507557','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('328','13','29','-29950.00','0.00','0.00','0.00','69850.00','提现成功,扣除实际手续费50.00元，减去冻结资金，到帐金额29950元','1455507643','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('329','12','4','-100.00','9896.83','0.00','0.00','100.00','提现,默认自动扣减手续费1元','1455507981','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('330','12','5','100.00','9996.83','0.00','0.00','0.00','撤消提现','1455508663','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('331','12','4','-100.00','9896.83','0.00','0.00','100.00','提现,默认自动扣减手续费10元','1455508693','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('332','12','36','-100.00','9886.83','0.00','0.00','100.00','提现申请已通过，扣除实际手续费10元，到帐金额100.00元','1455508712','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('333','12','29','-100.00','9886.83','0.00','0.00','0.00','提现成功,扣除实际手续费10.00元，减去冻结资金，到帐金额100.00元','1455508740','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('334','12','4','-100.00','9786.83','0.00','0.00','100.00','提现,默认自动扣减手续费10元','1455508767','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('335','12','5','100.00','9886.83','0.00','0.00','0.00','撤消提现','1455508854','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('336','14','3','10000.00','10000.00','0.00','0.00','0.00','管理员手动审核充值','1455514808','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('337','14','14','-10.00','9990.00','0.00','0.00','0.00','升级VIP成功','1455514972','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('338','4','37','-5000.00','479740.84','528002.67','10228.23','15000.00','对8号优计划进行了投标','1455515021','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('339','1','17','5000.00','20867.99','0.00','3421.58','300.00','第8号优计划已被认购5000元，5000元已入帐','1455515021','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('340','4','39','5000.00','479740.84','528002.67','15228.23','10000.00','您对第8号优计划投标成功，冻结本金成为待收金额','1455515021','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('341','4','38','40.02','479740.84','528002.67','15268.25','10000.00','第8号优计划应收利息成为待收利息','1455515021','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('342','2','13','10.00','10076827.16','0.00','0.00','200.00','13706360071对8号标投资成功，你获得推广奖励10.00元。','1455515021','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('343','4','40','10.00','479750.84','528002.67','15268.25','10000.00','优计划续投有效金额(5000)的奖励(8号优计划)奖励','1455515021','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('344','2','37','-5000.00','10071827.16','0.00','0.00','5200.00','对8号优计划进行了投标','1455515231','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('345','1','17','5000.00','25867.99','0.00','3421.58','300.00','第8号优计划已被认购5000元，5000元已入帐','1455515231','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('346','2','39','5000.00','10071827.16','0.00','5000.00','200.00','您对第8号优计划投标成功，冻结本金成为待收金额','1455515231','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('347','2','38','40.02','10071827.16','0.00','5040.02','200.00','第8号优计划应收利息成为待收利息','1455515231','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('348','4','13','10.00','479760.84','528002.67','15268.25','10000.00','17777777777对8号标投资成功，你获得推广奖励10.00元。','1455515232','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('349','2','6','-300.00','10071527.16','0.00','5040.02','500.00','对30号标进行投标','1455515288','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('350','1','6','-200.00','25667.99','0.00','3421.58','500.00','对30号标进行投标','1455515468','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('351','12','17','500.00','10386.83','0.00','0.00','0.00','第30号标复审通过，借款金额入帐','1455515487','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('352','12','19','-50.00','10336.83','0.00','0.00','50.00','第30号标借款成功，冻结10%的保证金','1455515487','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('353','1','20','10.00','25677.99','0.00','3421.58','500.00','第30号标复审通过，获取投标奖励','1455515487','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('354','12','21','-10.00','10326.83','0.00','0.00','50.00','第30号标复审通过，支付投标奖励','1455515487','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('355','1','15','200.00','25677.99','0.00','3621.58','300.00','第30号标复审通过，冻结本金成为待收金额','1455515487','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('356','1','28','5.02','25677.99','0.00','3626.60','300.00','第30号标复审通过，应收利息成为待收利息','1455515487','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('357','6','13','0.01','14765.33','58346.07','2319.04','210.00','18661395415对30号标投资成功，你获得推广奖励0.01元。','1455515487','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('358','2','20','15.00','10071542.16','0.00','5040.02','500.00','第30号标复审通过，获取投标奖励','1455515487','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('359','12','21','-15.00','10311.83','0.00','0.00','50.00','第30号标复审通过，支付投标奖励','1455515487','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('360','2','15','300.00','10071542.16','0.00','5340.02','200.00','第30号标复审通过，冻结本金成为待收金额','1455515487','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('361','2','28','7.54','10071542.16','0.00','5347.56','200.00','第30号标复审通过，应收利息成为待收利息','1455515487','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('362','4','13','0.02','479760.86','528002.67','15268.25','10000.00','17777777777对30号标投资成功，你获得推广奖励0.02元。','1455515487','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('363','14','6','-500.00','9490.00','0.00','0.00','500.00','对33号标进行投标','1455515801','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('364','4','6','-100000.00','479760.86','428002.67','15268.25','110000.00','对34号标进行投标','1455515924','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('365','4','33','150.00','479760.86','428002.67','15268.25','110150.00','续投有效金额(100000)的奖励(34号标)预奖励','1455515924','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('366','2','17','100000.00','10171542.16','0.00','5347.56','200.00','第34号标复审通过，借款金额入帐','1455515940','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('367','2','19','-10000.00','10161542.16','0.00','5347.56','10200.00','第34号标借款成功，冻结10%的保证金','1455515940','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('368','4','15','100000.00','479760.86','428002.67','115268.25','10150.00','第34号标复审通过，冻结本金成为待收金额','1455515940','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('369','4','28','1666.67','479760.86','428002.67','116934.92','10150.00','第34号标复审通过，应收利息成为待收利息','1455515940','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('370','2','13','3.33','10161545.49','0.00','5347.56','10200.00','13706360071对34号标投资成功，你获得推广奖励3.33元。','1455515940','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('371','4','34','150.00','479910.86','428002.67','116934.92','10000.00','续投奖励(34号标)预奖励到账','1455515940','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('372','12','17','500.00','10811.83','0.00','0.00','50.00','第33号标复审通过，借款金额入帐','1455516012','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('373','12','19','-50.00','10761.83','0.00','0.00','100.00','第33号标借款成功，冻结10%的保证金','1455516012','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('374','14','20','10.00','9500.00','0.00','0.00','500.00','第33号标复审通过，获取投标奖励','1455516012','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('375','12','21','-10.00','10751.83','0.00','0.00','100.00','第33号标复审通过，支付投标奖励','1455516012','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('376','14','15','500.00','9500.00','0.00','500.00','0.00','第33号标复审通过，冻结本金成为待收金额','1455516012','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('377','14','28','7.51','9500.00','0.00','507.51','0.00','第33号标复审通过，应收利息成为待收利息','1455516012','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('378','12','13','0.02','10751.85','0.00','0.00','100.00','18266479979对33号标投资成功，你获得推广奖励0.02元。','1455516012','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('379','12','11','-253.76','10498.09','0.00','0.00','100.00','对33号标第1期还款','1455516038','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('380','14','9','253.76','9500.00','253.76','253.75','0.00','收到会员对33号标第1期的还款','1455516038','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('381','14','23','-3.40','9500.00','250.36','253.75','0.00','网站已将第33号标第1期还款的利息管理费扣除','1455516038','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('382','12','11','-253.75','10244.34','0.00','0.00','100.00','对33号标第2期还款','1455516039','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('383','14','9','253.75','9500.00','504.11','0.00','0.00','收到会员对33号标第2期的还款','1455516039','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('384','14','23','-1.71','9500.00','502.40','0.00','0.00','网站已将第33号标第2期还款的利息管理费扣除','1455516039','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('385','12','24','50.00','10294.34','0.00','0.00','50.00','网站对33号标还款完成的解冻保证金','1455516039','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('386','12','11','-170.85','10123.49','0.00','0.00','50.00','对30号标第1期还款','1455516048','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('387','1','9','68.34','25677.99','68.34','3558.26','300.00','收到会员对30号标第1期的还款','1455516048','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('388','1','23','-1.70','25677.99','66.64','3558.26','300.00','网站已将第30号标第1期还款的利息管理费扣除','1455516048','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('389','2','9','102.51','10161545.49','102.51','5245.05','10200.00','收到会员对30号标第1期的还款','1455516048','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('390','2','23','-2.55','10161545.49','99.96','5245.05','10200.00','网站已将第30号标第1期还款的利息管理费扣除','1455516048','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('391','12','11','-170.85','9952.64','0.00','0.00','50.00','对30号标第2期还款','1455516069','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('392','1','9','68.34','25677.99','134.98','3489.92','300.00','收到会员对30号标第2期的还款','1455516069','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('393','1','23','-1.14','25677.99','133.84','3489.92','300.00','网站已将第30号标第2期还款的利息管理费扣除','1455516069','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('394','2','9','102.51','10161545.49','202.47','5142.54','10200.00','收到会员对30号标第2期的还款','1455516069','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('395','2','23','-1.71','10161545.49','200.76','5142.54','10200.00','网站已将第30号标第2期还款的利息管理费扣除','1455516069','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('396','12','11','-170.85','9781.79','0.00','0.00','50.00','对30号标第3期还款','1455516075','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('397','1','9','68.34','25677.99','202.18','3421.58','300.00','收到会员对30号标第3期的还款','1455516075','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('398','1','23','-0.57','25677.99','201.61','3421.58','300.00','网站已将第30号标第3期还款的利息管理费扣除','1455516075','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('399','2','9','102.51','10161545.49','303.27','5040.03','10200.00','收到会员对30号标第3期的还款','1455516075','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('400','2','23','-0.86','10161545.49','302.41','5040.03','10200.00','网站已将第30号标第3期还款的利息管理费扣除','1455516075','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('401','12','24','50.00','9831.79','0.00','0.00','0.00','网站对30号标还款完成的解冻保证金','1455516075','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('402','14','6','-200.00','9500.00','302.40','0.00','200.00','对35号标进行投标','1455517289','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('403','14','33','0.20','9500.00','302.40','0.00','200.20','续投有效金额(200)的奖励(35号标)预奖励','1455517289','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('404','12','17','200.00','10031.79','0.00','0.00','0.00','第35号标复审通过，借款金额入帐','1455517315','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('405','12','19','-20.00','10011.79','0.00','0.00','20.00','第35号标借款成功，冻结10%的保证金','1455517315','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('406','14','20','2.00','9502.00','302.40','0.00','200.20','第35号标复审通过，获取投标奖励','1455517315','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('407','12','21','-2.00','10009.79','0.00','0.00','20.00','第35号标复审通过，支付投标奖励','1455517315','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('408','14','15','200.00','9502.00','302.40','200.00','0.20','第35号标复审通过，冻结本金成为待收金额','1455517315','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('409','14','28','2.00','9502.00','302.40','202.00','0.20','第35号标复审通过，应收利息成为待收利息','1455517315','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('410','14','34','0.20','9502.20','302.40','202.00','0.00','续投奖励(35号标)预奖励到账','1455517315','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('411','12','11','-202.00','9807.79','0.00','0.00','20.00','对35号标第1期还款','1455517369','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('412','14','9','202.00','9502.20','504.40','0.00','0.00','收到会员对35号标第1期的还款','1455517370','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('413','14','23','-1.36','9502.20','503.04','0.00','0.00','网站已将第35号标第1期还款的利息管理费扣除','1455517370','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('414','14','99','1.67','9502.20','504.71','0.00','0.00','收到35号标28号投资70号加息券第1期还款的加息券收益','1455517370','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('415','12','24','20.00','9827.79','0.00','0.00','0.00','网站对35号标还款完成的解冻保证金','1455517370','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('416','4','6','-500.00','479910.86','427502.67','116934.92','10500.00','对36号标进行投标','1455518107','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('417','4','33','1.00','479910.86','427502.67','116934.92','10501.00','续投有效金额(500.00)的奖励(36号标)预奖励','1455518107','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('418','4','6','-100.00','479910.86','427402.67','116934.92','10601.00','对38号标进行投标','1455519795','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('419','4','33','0.10','479910.86','427402.67','116934.92','10601.10','续投有效金额(100)的奖励(38号标)预奖励','1455519795','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('420','14','6','-400.00','9502.20','104.71','0.00','400.00','对38号标进行投标','1455519865','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('421','14','33','0.40','9502.20','104.71','0.00','400.40','续投有效金额(400)的奖励(38号标)预奖励','1455519865','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('422','12','17','500.00','10327.79','0.00','0.00','0.00','第38号标复审通过，借款金额入帐','1455519896','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('423','12','19','-50.00','10277.79','0.00','0.00','50.00','第38号标借款成功，冻结10%的保证金','1455519896','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('424','4','20','1.00','479911.86','427402.67','116934.92','10601.10','第38号标复审通过，获取投标奖励','1455519896','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('425','12','21','-1.00','10276.79','0.00','0.00','50.00','第38号标复审通过，支付投标奖励','1455519896','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('426','4','15','100.00','479911.86','427402.67','117034.92','10501.10','第38号标复审通过，冻结本金成为待收金额','1455519896','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('427','4','28','0.07','479911.86','427402.67','117034.99','10501.10','第38号标复审通过，应收利息成为待收利息','1455519896','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('428','14','20','4.00','9506.20','104.71','0.00','400.40','第38号标复审通过，获取投标奖励','1455519896','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('429','12','21','-4.00','10272.79','0.00','0.00','50.00','第38号标复审通过，支付投标奖励','1455519896','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('430','14','15','400.00','9506.20','104.71','400.00','0.40','第38号标复审通过，冻结本金成为待收金额','1455519896','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('431','14','28','0.26','9506.20','104.71','400.26','0.40','第38号标复审通过，应收利息成为待收利息','1455519896','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('432','4','34','0.10','479911.96','427402.67','117034.99','10501.00','续投奖励(38号标)预奖励到账','1455519896','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('433','14','34','0.40','9506.60','104.71','400.26','0.00','续投奖励(38号标)预奖励到账','1455519896','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('434','12','11','-500.33','9772.46','0.00','0.00','50.00','对38号标第1期还款','1455519914','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('435','4','9','100.07','479911.96','427502.74','116934.92','10501.00','收到会员对38号标第1期的还款','1455519914','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('436','4','23','-0.04','479911.96','427502.70','116934.92','10501.00','网站已将第38号标第1期还款的利息管理费扣除','1455519914','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('437','14','9','400.26','9506.60','504.97','0.00','0.00','收到会员对38号标第1期的还款','1455519914','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('438','14','23','-0.18','9506.60','504.79','0.00','0.00','网站已将第38号标第1期还款的利息管理费扣除','1455519914','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('439','14','99','0.33','9506.60','505.12','0.00','0.00','收到38号标31号投资84号加息券第1期还款的加息券收益','1455519914','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('440','12','24','50.00','9822.46','0.00','0.00','0.00','网站对38号标还款完成的解冻保证金','1455519915','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('441','12','6','-500.00','9322.46','0.00','0.00','500.00','对40号标进行投标','1455521133','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('442','14','17','500.00','10006.60','505.12','0.00','0.00','第40号标复审通过，借款金额入帐','1455521146','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('443','14','19','-50.00','9956.60','505.12','0.00','50.00','第40号标借款成功，冻结10%的保证金','1455521146','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('444','12','15','500.00','9322.46','0.00','500.00','0.00','第40号标复审通过，冻结本金成为待收金额','1455521146','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('445','12','28','5.00','9322.46','0.00','505.00','0.00','第40号标复审通过，应收利息成为待收利息','1455521146','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('446','6','13','0.01','14765.34','58346.07','2319.04','210.00','17853738946对40号标投资成功，你获得推广奖励0.01元。','1455521146','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('447','4','27','1000.00','480911.96','427502.70','116934.92','10501.00','管理员手动审核充值','1455521474','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('448','4','29','-10000.00','480911.96','427502.70','116934.92','501.00','提现成功,扣除实际手续费50.00元，减去冻结资金，到帐金额10000.00元','1455521626','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('449','1','46','-505.00','25374.60','0.00','3421.58','300.00','购买1号债权','1455521789','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('450','1','46','505.00','25374.60','0.00','3926.58','300.00','购买1号债权,增加待收资金','1455521789','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('451','12','47','505.00','9827.46','0.00','505.00','0.00','转让1号债权','1455521789','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('452','12','47','-505.00','9827.46','0.00','0.00','0.00','转让1号债权,减少待收资金','1455521789','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('453','12','48','-5.05','9822.41','0.00','0.00','0.00','转让1号债权手续费（转让金额的1%）','1455521789','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('454','4','4','-10000.00','480911.96','417502.70','116934.92','10501.00','提现,默认自动扣减手续费10元','1455521880','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('455','4','36','-10000.00','480911.96','417492.70','116934.92','10501.00','提现申请已通过，扣除实际手续费10元，到帐金额10000.00元','1455521972','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('456','14','11','-505.00','9956.60','0.12','0.00','50.00','对40号标第1期还款','1455522153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('457','1','9','505.00','25374.60','505.00','3421.58','300.00','收到会员对1号债权第1期的还款','1455522153','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('458','1','23','-3.40','25374.60','501.60','3421.58','300.00','网站已将第40号标第1期还款的利息管理费扣除','1455522153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('459','1','99','4.17','25374.60','505.77','3421.58','300.00','收到40号标32号投资68号加息券第1期还款的加息券收益','1455522153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('460','14','24','50.00','10006.60','0.12','0.00','0.00','网站对40号标还款完成的解冻保证金','1455522153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('461','4','8','500.00','481411.96','417492.70','116934.92','10001.00','第36号标募集期内标未满,流标，返回冻结资金','1455522993','61.156.219.212','2','17777777777');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('462','4','35','-1.00','481411.96','417492.70','116934.92','10000.00','续投奖励(36号标)预奖励取消','1455522993','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('463','14','4','-100.00','9906.72','0.00','0.00','100.00','提现,默认自动扣减手续费10元','1455523071','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('464','14','36','-100.00','9896.72','0.00','0.00','100.00','提现申请已通过，扣除实际手续费10元，到帐金额100.00元','1455523247','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('465','14','29','-100.00','9896.72','0.00','0.00','0.00','提现成功,扣除实际手续费10.00元，减去冻结资金，到帐金额100.00元','1455523259','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('466','4','37','-1000.00','481411.96','416492.70','116934.92','11000.00','对4号优计划进行了投标','1455524342','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('467','6','17','1000.00','15765.34','58346.07','2319.04','210.00','第4号优计划已被认购1000元，1000元已入帐','1455524342','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('468','4','39','1000.00','481411.96','416492.70','117934.92','10000.00','您对第4号优计划投标成功，冻结本金成为待收金额','1455524342','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('469','4','38','7.98','481411.96','416492.70','117942.90','10000.00','第4号优计划应收利息成为待收利息','1455524342','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('470','2','13','2.00','10161547.49','302.41','5040.03','10200.00','13706360071对4号标投资成功，你获得推广奖励2.00元。','1455524342','61.156.219.212','4','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('471','4','40','2.00','481413.96','416492.70','117942.90','10000.00','优计划续投有效金额(1000)的奖励(4号优计划)奖励','1455524342','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('472','15','3','100000.00','100000.00','0.00','0.00','0.00','管理员手动审核充值','1455526459','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('473','15','37','-500.00','99500.00','0.00','0.00','500.00','对4号优计划进行了投标','1455527119','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('474','6','17','500.00','16265.34','58346.07','2319.04','210.00','第4号优计划已被认购500元，500元已入帐','1455527119','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('475','6','18','-10.00','16255.34','58346.07','2319.04','210.00','第4号优计划被认购完毕，扣除借款管理费10.00元','1455527119','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('476','15','39','500.00','99500.00','0.00','500.00','0.00','您对第4号优计划投标成功，冻结本金成为待收金额','1455527119','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('477','15','38','4.03','99500.00','0.00','504.03','0.00','第4号优计划应收利息成为待收利息','1455527119','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('478','15','14','-10.00','99490.00','0.00','504.03','0.00','升级VIP成功','1455527557','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('479','15','4','-10000.00','89490.00','0.00','504.03','10000.00','提现,默认自动扣减手续费10元','1455584552','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('480','14','6','-600.00','9296.72','0.00','0.00','600.00','对42号标进行投标','1455584581','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('481','1','17','600.00','25974.60','505.77','3421.58','300.00','第42号标复审通过，借款金额入帐','1455584603','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('482','1','19','-60.00','25914.60','505.77','3421.58','360.00','第42号标借款成功，冻结10%的保证金','1455584603','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('483','14','20','12.00','9308.72','0.00','0.00','600.00','第42号标复审通过，获取投标奖励','1455584603','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('484','1','21','-12.00','25902.60','505.77','3421.58','360.00','第42号标复审通过，支付投标奖励','1455584603','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('485','14','15','600.00','9308.72','0.00','600.00','0.00','第42号标复审通过，冻结本金成为待收金额','1455584603','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('486','14','28','6.00','9308.72','0.00','606.00','0.00','第42号标复审通过，应收利息成为待收利息','1455584603','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('487','12','13','0.01','9822.42','0.00','0.00','0.00','18266479979对42号标投资成功，你获得推广奖励0.01元。','1455584603','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('488','1','11','-606.00','25802.37','0.00','3421.58','360.00','对42号标第1期还款','1455584618','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('489','14','9','606.00','9308.72','606.00','0.00','0.00','收到会员对42号标第1期的还款','1455584618','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('490','14','23','-4.08','9308.72','601.92','0.00','0.00','网站已将第42号标第1期还款的利息管理费扣除','1455584618','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('491','1','24','60.00','25862.37','0.00','3421.58','300.00','网站对42号标还款完成的解冻保证金','1455584618','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('492','14','6','-400.00','9308.72','201.92','0.00','400.00','对43号标进行投标','1455586348','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('493','14','33','0.60','9308.72','201.92','0.00','400.60','续投有效金额(400)的奖励(43号标)预奖励','1455586348','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('494','1','17','400.00','26262.37','0.00','3421.58','300.00','第43号标复审通过，借款金额入帐','1455586364','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('495','1','19','-40.00','26222.37','0.00','3421.58','340.00','第43号标借款成功，冻结10%的保证金','1455586364','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('496','14','15','400.00','9308.72','201.92','400.00','0.60','第43号标复审通过，冻结本金成为待收金额','1455586364','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('497','14','34','0.60','9309.32','201.92','400.00','0.00','续投奖励(43号标)预奖励到账','1455586364','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('498','1','11','-200.00','26022.37','0.00','3421.58','340.00','对43号标第1期还款','1455586394','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('499','14','9','200.00','9309.32','401.92','200.00','0.00','收到会员对43号标第1期的还款','1455586394','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('500','1','11','-200.00','25822.37','0.00','3421.58','340.00','对43号标第2期还款','1455586395','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('501','14','9','200.00','9309.32','601.92','0.00','0.00','收到会员对43号标第2期的还款','1455586395','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('502','1','24','40.00','25862.37','0.00','3421.58','300.00','网站对43号标还款完成的解冻保证金','1455586395','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('503','14','6','-200.00','9309.32','401.92','0.00','200.00','对44号标进行投标','1455587105','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('504','14','33','0.20','9309.32','401.92','0.00','200.20','续投有效金额(200)的奖励(44号标)预奖励','1455587105','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('505','1','17','200.00','26062.37','0.00','3421.58','300.00','第44号标复审通过，借款金额入帐','1455587123','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('506','1','19','-20.00','26042.37','0.00','3421.58','320.00','第44号标借款成功，冻结10%的保证金','1455587123','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('507','14','20','2.00','9311.32','401.92','0.00','200.20','第44号标复审通过，获取投标奖励','1455587123','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('508','1','21','-2.00','26040.37','0.00','3421.58','320.00','第44号标复审通过，支付投标奖励','1455587123','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('509','14','15','200.00','9311.32','401.92','200.00','0.20','第44号标复审通过，冻结本金成为待收金额','1455587123','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('510','14','28','4.17','9311.32','401.92','204.17','0.20','第44号标复审通过，应收利息成为待收利息','1455587123','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('511','12','13','0.01','9822.43','0.00','0.00','0.00','18266479979对44号标投资成功，你获得推广奖励0.01元。','1455587123','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('512','14','34','0.20','9311.52','401.92','204.17','0.00','续投奖励(44号标)预奖励到账','1455587123','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('513','1','11','-204.17','25836.20','0.00','3421.58','320.00','对44号标第1期还款','1455587139','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('514','14','9','204.17','9311.52','606.09','0.00','0.00','收到会员对44号标第1期的还款','1455587139','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('515','14','23','-2.83','9311.52','603.26','0.00','0.00','网站已将第44号标第1期还款的利息管理费扣除','1455587139','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('516','1','24','20.00','25856.20','0.00','3421.58','300.00','网站对44号标还款完成的解冻保证金','1455587139','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('517','14','4','-100.00','9311.52','503.26','0.00','100.00','提现,默认自动扣减手续费10元','1455589417','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('518','14','5','100.00','9311.52','603.26','0.00','0.00','撤消提现','1455589503','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('519','14','4','-100.00','9311.52','503.26','0.00','100.00','提现,默认自动扣减手续费10元','1455589722','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('520','14','12','100.00','9311.52','603.26','0.00','0.00','提现未通过,返还','1455589757','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('521','12','37','-200.00','9622.43','0.00','0.00','200.00','对9号优计划进行了投标','1455590854','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('522','1','17','200.00','26056.20','0.00','3421.58','300.00','第9号优计划已被认购200元，200元已入帐','1455590854','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('523','12','39','200.00','9622.43','0.00','200.00','0.00','您对第9号优计划投标成功，冻结本金成为待收金额','1455590854','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('524','12','38','0.64','9622.43','0.00','200.64','0.00','第9号优计划应收利息成为待收利息','1455590854','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('525','6','13','0.40','16255.74','58346.07','2319.04','210.00','17853738946对9号标投资成功，你获得推广奖励0.40元。','1455590854','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('526','14','37','-400.00','9311.52','203.26','0.00','400.00','对9号优计划进行了投标','1455590951','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('527','1','17','400.00','26456.20','0.00','3421.58','300.00','第9号优计划已被认购400元，400元已入帐','1455590951','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('528','14','39','400.00','9311.52','203.26','400.00','0.00','您对第9号优计划投标成功，冻结本金成为待收金额','1455590951','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('529','14','38','1.28','9311.52','203.26','401.28','0.00','第9号优计划应收利息成为待收利息','1455590951','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('530','12','13','0.80','9623.23','0.00','200.64','0.00','18266479979对9号标投资成功，你获得推广奖励0.80元。','1455590951','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('531','12','37','-200.00','9423.23','0.00','200.64','200.00','对10号优计划进行了投标','1455591342','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('532','1','17','200.00','26656.20','0.00','3421.58','300.00','第10号优计划已被认购200元，200元已入帐','1455591342','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('533','12','39','200.00','9423.23','0.00','400.64','0.00','您对第10号优计划投标成功，冻结本金成为待收金额','1455591342','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('534','12','38','1.92','9423.23','0.00','402.56','0.00','第10号优计划应收利息成为待收利息','1455591342','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('535','6','13','0.40','16256.14','58346.07','2319.04','210.00','17853738946对10号标投资成功，你获得推广奖励0.40元。','1455591342','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('536','14','37','-200.00','9311.52','3.26','401.28','200.00','对10号优计划进行了投标','1455591342','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('537','1','17','200.00','26856.20','0.00','3421.58','300.00','第10号优计划已被认购200元，200元已入帐','1455591342','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('538','14','39','200.00','9311.52','3.26','601.28','0.00','您对第10号优计划投标成功，冻结本金成为待收金额','1455591342','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('539','14','38','1.92','9311.52','3.26','603.20','0.00','第10号优计划应收利息成为待收利息','1455591342','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('540','12','13','0.40','9423.63','0.00','402.56','0.00','18266479979对10号标投资成功，你获得推广奖励0.40元。','1455591342','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('541','14','40','0.40','9311.92','3.26','603.20','0.00','优计划续投有效金额(200)的奖励(10号优计划)奖励','1455591342','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('542','14','6','-200.00','9115.18','0.00','603.20','200.00','对48号标进行投标','1455601388','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('543','14','33','0.01','9115.18','0.00','603.20','200.01','续投有效金额(3.26)的奖励(48号标)预奖励','1455601388','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('544','12','6','-200.00','9223.63','0.00','402.56','200.00','对48号标进行投标','1455601388','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('545','15','6','-50000.00','39490.00','0.00','504.03','60000.00','对48号标进行投标','1455601417','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('546','4','6','-500.00','481413.96','415992.70','117942.90','10500.00','对49号标进行投标','1455603544','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('547','4','33','1.00','481413.96','415992.70','117942.90','10501.00','续投有效金额(500.00)的奖励(49号标)预奖励','1455603544','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('548','14','6','-200.00','8915.18','0.00','603.20','400.01','对49号标进行投标','1455603544','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('549','12','6','-200.00','9023.63','0.00','402.56','400.00','对49号标进行投标','1455603545','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('550','1','6','-2100.00','24756.20','0.00','3421.58','2400.00','对49号标进行投标','1455603623','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('551','6','17','3000.00','19256.14','58346.07','2319.04','210.00','第49号标复审通过，借款金额入帐','1455603651','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('552','6','19','-300.00','18956.14','58346.07','2319.04','510.00','第49号标借款成功，冻结10%的保证金','1455603651','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('553','1','15','2100.00','24756.20','0.00','5521.58','300.00','第49号标复审通过，冻结本金成为待收金额','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('554','1','28','97.44','24756.20','0.00','5619.02','300.00','第49号标复审通过，应收利息成为待收利息','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('555','6','13','0.19','18956.33','58346.07','2319.04','510.00','18661395415对49号标投资成功，你获得推广奖励0.19元。','1455603651','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('556','4','15','500.00','481413.96','415992.70','118442.90','10001.00','第49号标复审通过，冻结本金成为待收金额','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('557','4','28','23.21','481413.96','415992.70','118466.11','10001.00','第49号标复审通过，应收利息成为待收利息','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('558','2','13','0.05','10161547.54','302.41','5040.03','10200.00','18888888888对49号标投资成功，你获得推广奖励0.05元。','1455603651','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('559','12','15','200.00','9023.63','0.00','602.56','200.00','第49号标复审通过，冻结本金成为待收金额','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('560','12','28','9.27','9023.63','0.00','611.83','200.00','第49号标复审通过，应收利息成为待收利息','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('561','6','13','0.02','18956.35','58346.07','2319.04','510.00','17853738946对49号标投资成功，你获得推广奖励0.02元。','1455603651','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('562','14','15','200.00','8915.18','0.00','803.20','200.01','第49号标复审通过，冻结本金成为待收金额','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('563','14','28','9.27','8915.18','0.00','812.47','200.01','第49号标复审通过，应收利息成为待收利息','1455603651','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('564','12','13','0.02','9023.65','0.00','611.83','200.00','18266479979对49号标投资成功，你获得推广奖励0.02元。','1455603651','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('565','4','34','1.00','481414.96','415992.70','118466.11','10000.00','续投奖励(49号标)预奖励到账','1455603651','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('566','6','11','-313.92','18956.35','58032.15','2319.04','510.00','对49号标第1期还款','1455603765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('567','1','9','219.74','24756.20','219.74','5399.28','300.00','收到会员对49号标第1期的还款','1455603765','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('568','1','23','-11.90','24756.20','207.84','5399.28','300.00','网站已将第49号标第1期还款的利息管理费扣除','1455603765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('569','4','9','52.32','481414.96','416045.02','118413.79','10000.00','收到会员对49号标第1期的还款','1455603765','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('570','4','23','-2.83','481414.96','416042.19','118413.79','10000.00','网站已将第49号标第1期还款的利息管理费扣除','1455603765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('571','12','9','20.93','9023.65','20.93','590.90','200.00','收到会员对49号标第1期的还款','1455603765','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('572','12','23','-1.13','9023.65','19.80','590.90','200.00','网站已将第49号标第1期还款的利息管理费扣除','1455603765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('573','14','9','20.93','8915.18','20.93','791.54','200.01','收到会员对49号标第1期的还款','1455603765','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('574','14','23','-1.13','8915.18','19.80','791.54','200.01','网站已将第49号标第1期还款的利息管理费扣除','1455603765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('575','6','11','-313.92','18956.35','57718.23','2319.04','510.00','对49号标第2期还款','1455603766','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('576','1','9','219.74','24756.20','427.58','5179.54','300.00','收到会员对49号标第2期的还款','1455603766','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('577','1','23','-10.75','24756.20','416.83','5179.54','300.00','网站已将第49号标第2期还款的利息管理费扣除','1455603766','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('578','4','9','52.32','481414.96','416094.51','118361.47','10000.00','收到会员对49号标第2期的还款','1455603766','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('579','4','23','-2.56','481414.96','416091.95','118361.47','10000.00','网站已将第49号标第2期还款的利息管理费扣除','1455603766','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('580','12','9','20.93','9023.65','40.73','569.97','200.00','收到会员对49号标第2期的还款','1455603766','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('581','12','23','-1.02','9023.65','39.71','569.97','200.00','网站已将第49号标第2期还款的利息管理费扣除','1455603766','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('582','14','9','20.93','8915.18','40.73','770.61','200.01','收到会员对49号标第2期的还款','1455603766','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('583','14','23','-1.02','8915.18','39.71','770.61','200.01','网站已将第49号标第2期还款的利息管理费扣除','1455603766','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('584','6','11','-313.91','18956.35','57404.32','2319.04','510.00','对49号标第3期还款','1455603767','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('585','1','9','219.75','24756.20','636.58','4959.79','300.00','收到会员对49号标第3期的还款','1455603767','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('586','1','23','-9.60','24756.20','626.98','4959.79','300.00','网站已将第49号标第3期还款的利息管理费扣除','1455603767','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('587','4','9','52.32','481414.96','416144.27','118309.15','10000.00','收到会员对49号标第3期的还款','1455603767','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('588','4','23','-2.29','481414.96','416141.98','118309.15','10000.00','网站已将第49号标第3期还款的利息管理费扣除','1455603767','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('589','12','9','20.92','9023.65','60.63','549.05','200.00','收到会员对49号标第3期的还款','1455603767','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('590','12','23','-0.91','9023.65','59.72','549.05','200.00','网站已将第49号标第3期还款的利息管理费扣除','1455603767','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('591','14','9','20.92','8915.18','60.63','749.69','200.01','收到会员对49号标第3期的还款','1455603767','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('592','14','23','-0.91','8915.18','59.72','749.69','200.01','网站已将第49号标第3期还款的利息管理费扣除','1455603767','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('593','6','11','-313.92','18956.35','57090.40','2319.04','510.00','对49号标第4期还款','1455603773','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('594','1','9','219.74','24756.20','846.72','4740.05','300.00','收到会员对49号标第4期的还款','1455603773','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('595','1','23','-8.43','24756.20','838.29','4740.05','300.00','网站已将第49号标第4期还款的利息管理费扣除','1455603773','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('596','4','9','52.32','481414.96','416194.30','118256.83','10000.00','收到会员对49号标第4期的还款','1455603773','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('597','4','23','-2.01','481414.96','416192.29','118256.83','10000.00','网站已将第49号标第4期还款的利息管理费扣除','1455603773','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('598','12','9','20.93','9023.65','80.65','528.12','200.00','收到会员对49号标第4期的还款','1455603773','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('599','12','23','-0.80','9023.65','79.85','528.12','200.00','网站已将第49号标第4期还款的利息管理费扣除','1455603773','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('600','14','9','20.93','8915.18','80.65','728.76','200.01','收到会员对49号标第4期的还款','1455603773','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('601','14','23','-0.80','8915.18','79.85','728.76','200.01','网站已将第49号标第4期还款的利息管理费扣除','1455603773','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('602','6','11','-313.92','18956.35','56776.48','2319.04','510.00','对49号标第5期还款','1455603775','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('603','1','9','219.74','24756.20','1058.03','4520.31','300.00','收到会员对49号标第5期的还款','1455603775','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('604','1','23','-7.26','24756.20','1050.77','4520.31','300.00','网站已将第49号标第5期还款的利息管理费扣除','1455603775','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('605','4','9','52.32','481414.96','416244.61','118204.51','10000.00','收到会员对49号标第5期的还款','1455603775','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('606','4','23','-1.73','481414.96','416242.88','118204.51','10000.00','网站已将第49号标第5期还款的利息管理费扣除','1455603775','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('607','12','9','20.93','9023.65','100.78','507.19','200.00','收到会员对49号标第5期的还款','1455603775','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('608','12','23','-0.69','9023.65','100.09','507.19','200.00','网站已将第49号标第5期还款的利息管理费扣除','1455603775','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('609','14','9','20.93','8915.18','100.78','707.83','200.01','收到会员对49号标第5期的还款','1455603775','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('610','14','23','-0.69','8915.18','100.09','707.83','200.01','网站已将第49号标第5期还款的利息管理费扣除','1455603775','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('611','1','10','219.74','24756.20','1270.51','4300.57','300.00','网站对49号标第6期代还','1483338270','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('612','4','10','52.32','481414.96','416295.20','118152.19','10000.00','网站对49号标第6期代还','1483338270','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('613','12','10','20.93','9023.65','121.02','486.26','200.00','网站对49号标第6期代还','1483338270','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('614','14','10','20.93','8915.18','121.02','686.90','200.01','网站对49号标第6期代还','1483338270','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('615','1','10','219.74','24756.20','1490.25','4080.83','300.00','网站对49号标第7期代还','1483338277','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('616','4','10','52.32','481414.96','416347.52','118099.87','10000.00','网站对49号标第7期代还','1483338277','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('617','12','10','20.92','9023.65','141.94','465.34','200.00','网站对49号标第7期代还','1483338277','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('618','14','10','20.92','8915.18','141.94','665.98','200.01','网站对49号标第7期代还','1483338277','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('619','14','37','-400.00','8657.12','0.00','665.98','600.01','对11号优计划进行了投标','1455606156','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('620','1','17','400.00','25156.20','1490.25','4080.83','300.00','第11号优计划已被认购400元，400元已入帐','1455606156','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('621','14','39','400.00','8657.12','0.00','1065.98','200.01','您对第11号优计划投标成功，冻结本金成为待收金额','1455606156','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('622','14','38','7.04','8657.12','0.00','1073.02','200.01','第11号优计划应收利息成为待收利息','1455606156','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('623','12','13','0.80','9024.45','141.94','465.34','200.00','18266479979对11号标投资成功，你获得推广奖励0.80元。','1455606156','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('624','14','40','0.28','8657.40','0.00','1073.02','200.01','优计划续投有效金额(141.94)的奖励(11号优计划)奖励','1455606156','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('625','12','37','-200.00','8966.39','0.00','465.34','400.00','对11号优计划进行了投标','1455606156','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('626','1','17','200.00','25356.20','1490.25','4080.83','300.00','第11号优计划已被认购200元，200元已入帐','1455606156','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('627','12','39','200.00','8966.39','0.00','665.34','200.00','您对第11号优计划投标成功，冻结本金成为待收金额','1455606156','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('628','12','38','3.52','8966.39','0.00','668.86','200.00','第11号优计划应收利息成为待收利息','1455606156','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('629','6','13','0.40','18956.75','56776.48','2319.04','510.00','17853738946对11号标投资成功，你获得推广奖励0.40元。','1455606156','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('630','12','40','0.28','8966.67','0.00','668.86','200.00','优计划续投有效金额(141.94)的奖励(11号优计划)奖励','1455606156','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('631','12','6','-200.00','8766.67','0.00','668.86','400.00','对47号标进行投标','1455606734','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('632','14','17','200.00','8857.40','0.00','1073.02','200.01','第47号标复审通过，借款金额入帐','1455606765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('633','14','19','-20.00','8837.40','0.00','1073.02','220.01','第47号标借款成功，冻结10%的保证金','1455606765','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('634','12','20','8.00','8774.67','0.00','668.86','400.00','第47号标复审通过，获取投标奖励','1455606765','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('635','14','21','-8.00','8829.40','0.00','1073.02','220.01','第47号标复审通过，支付投标奖励','1455606765','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('636','12','15','200.00','8774.67','0.00','868.86','200.00','第47号标复审通过，冻结本金成为待收金额','1455606765','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('637','12','28','2.00','8774.67','0.00','870.86','200.00','第47号标复审通过，应收利息成为待收利息','1455606765','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('638','4','6','-100.00','481414.96','416247.52','118099.87','10100.00','对50号标进行投标','1455608446','61.156.219.212','15','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('639','4','33','0.15','481414.96','416247.52','118099.87','10100.15','续投有效金额(100)的奖励(50号标)预奖励','1455608446','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('640','14','11','-202.00','8627.40','0.00','1073.02','220.01','对47号标第1期还款','1455610314','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('641','12','9','202.00','8774.67','202.00','668.86','200.00','收到会员对47号标第1期的还款','1455610314','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('642','12','23','-1.36','8774.67','200.64','668.86','200.00','网站已将第47号标第1期还款的利息管理费扣除','1455610314','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('643','12','99','2.50','8774.67','203.14','668.86','200.00','收到47号标43号投资82号加息券第1期还款的加息券收益','1455610314','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('644','14','24','20.00','8647.40','0.00','1073.02','200.01','网站对47号标还款完成的解冻保证金','1455610314','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('645','11','7','20000.00','20000.00','0.00','0.00','0.00','0','1455672332','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('646','12','6','-200.00','8774.67','3.14','668.86','400.00','对52号标进行投标','1455676308','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('647','12','33','0.20','8774.67','3.14','668.86','400.20','续投有效金额(200)的奖励(52号标)预奖励','1455676308','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('648','14','17','200.00','8847.40','0.00','1073.02','200.01','第52号标复审通过，借款金额入帐','1455676327','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('649','14','18','-2.00','8845.40','0.00','1073.02','200.01','第52号标借款成功，扣除借款管理费','1455676327','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('650','14','19','-20.00','8825.40','0.00','1073.02','220.01','第52号标借款成功，冻结10%的保证金','1455676327','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('651','12','20','10.00','8784.67','3.14','668.86','400.20','第52号标复审通过，获取投标奖励','1455676327','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('652','14','21','-10.00','8815.40','0.00','1073.02','220.01','第52号标复审通过，支付投标奖励','1455676327','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('653','12','15','200.00','8784.67','3.14','868.86','200.20','第52号标复审通过，冻结本金成为待收金额','1455676327','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('654','12','28','4.00','8784.67','3.14','872.86','200.20','第52号标复审通过，应收利息成为待收利息','1455676327','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('655','12','34','0.20','8784.87','3.14','872.86','200.00','续投奖励(52号标)预奖励到账','1455676327','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('656','14','11','-204.00','8611.40','0.00','1073.02','220.01','对52号标第1期还款','1455676367','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('657','12','9','204.00','8784.87','207.14','668.86','200.00','收到会员对52号标第1期的还款','1455676367','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('658','12','23','-2.72','8784.87','204.42','668.86','200.00','网站已将第52号标第1期还款的利息管理费扣除','1455676367','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('659','12','99','3.33','8784.87','207.75','668.86','200.00','收到52号标45号投资105号加息券第1期还款的加息券收益','1455676367','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('660','14','24','20.00','8631.40','0.00','1073.02','200.01','网站对52号标还款完成的解冻保证金','1455676367','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('661','14','6','-300.00','8331.40','0.00','1073.02','500.01','对51号标进行投标','1455676734','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('662','12','17','300.00','9084.87','207.75','668.86','200.00','第51号标复审通过，借款金额入帐','1455676893','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('663','12','18','-3.00','9081.87','207.75','668.86','200.00','第51号标借款成功，扣除借款管理费','1455676893','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('664','12','19','-30.00','9051.87','207.75','668.86','230.00','第51号标借款成功，冻结10%的保证金','1455676893','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('665','14','20','36.00','8367.40','0.00','1073.02','500.01','第51号标复审通过，获取投标奖励','1455676893','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('666','12','21','-36.00','9015.87','207.75','668.86','230.00','第51号标复审通过，支付投标奖励','1455676893','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('667','14','15','300.00','8367.40','0.00','1373.02','200.01','第51号标复审通过，冻结本金成为待收金额','1455676893','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('668','14','28','3.00','8367.40','0.00','1376.02','200.01','第51号标复审通过，应收利息成为待收利息','1455676893','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('669','12','13','0.01','9015.88','207.75','668.86','230.00','18266479979对51号标投资成功，你获得推广奖励0.01元。','1455676893','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('670','12','11','-303.00','8920.63','0.00','668.86','230.00','对51号标第1期还款','1455676912','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('671','14','9','303.00','8367.40','303.00','1073.02','200.01','收到会员对51号标第1期的还款','1455676912','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('672','14','23','-2.04','8367.40','300.96','1073.02','200.01','网站已将第51号标第1期还款的利息管理费扣除','1455676912','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('673','14','99','5.00','8367.40','305.96','1073.02','200.01','收到51号标46号投资106号加息券第1期还款的加息券收益','1455676912','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('674','12','24','30.00','8950.63','0.00','668.86','200.00','网站对51号标还款完成的解冻保证金','1455676912','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('675','14','6','-200.00','8367.40','105.96','1073.02','400.01','对53号标进行投标','1455677181','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('676','14','33','0.20','8367.40','105.96','1073.02','400.21','续投有效金额(200)的奖励(53号标)预奖励','1455677181','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('677','12','17','200.00','9150.63','0.00','668.86','200.00','第53号标复审通过，借款金额入帐','1455677336','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('678','12','18','-2.00','9148.63','0.00','668.86','200.00','第53号标借款成功，扣除借款管理费','1455677336','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('679','12','19','-20.00','9128.63','0.00','668.86','220.00','第53号标借款成功，冻结10%的保证金','1455677336','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('680','14','20','10.00','8377.40','105.96','1073.02','400.21','第53号标复审通过，获取投标奖励','1455677336','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('681','12','21','-10.00','9118.63','0.00','668.86','220.00','第53号标复审通过，支付投标奖励','1455677336','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('682','14','15','200.00','8377.40','105.96','1273.02','200.21','第53号标复审通过，冻结本金成为待收金额','1455677336','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('683','14','28','2.00','8377.40','105.96','1275.02','200.21','第53号标复审通过，应收利息成为待收利息','1455677336','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('684','14','34','0.20','8377.60','105.96','1275.02','200.01','续投奖励(53号标)预奖励到账','1455677336','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('685','12','11','-202.00','8916.63','0.00','668.86','220.00','对53号标第1期还款','1455677392','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('686','14','9','202.00','8377.60','307.96','1073.02','200.01','收到会员对53号标第1期的还款','1455677392','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('687','14','23','-1.36','8377.60','306.60','1073.02','200.01','网站已将第53号标第1期还款的利息管理费扣除','1455677392','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('688','12','24','20.00','8936.63','0.00','668.86','200.00','网站对53号标还款完成的解冻保证金','1455677392','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('689','14','6','-300.00','8377.60','6.60','1073.02','500.01','对54号标进行投标','1455677571','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('690','14','33','0.30','8377.60','6.60','1073.02','500.31','续投有效金额(300)的奖励(54号标)预奖励','1455677571','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('691','12','17','300.00','9236.63','0.00','668.86','200.00','第54号标复审通过，借款金额入帐','1455677610','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('692','12','18','-3.00','9233.63','0.00','668.86','200.00','第54号标借款成功，扣除借款管理费','1455677610','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('693','12','19','-30.00','9203.63','0.00','668.86','230.00','第54号标借款成功，冻结10%的保证金','1455677610','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('694','14','15','300.00','8377.60','6.60','1373.02','200.31','第54号标复审通过，冻结本金成为待收金额','1455677610','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('695','14','28','3.00','8377.60','6.60','1376.02','200.31','第54号标复审通过，应收利息成为待收利息','1455677610','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('696','12','13','0.01','9203.64','0.00','668.86','230.00','18266479979对54号标投资成功，你获得推广奖励0.01元。','1455677610','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('697','14','34','0.30','8377.90','6.60','1376.02','200.01','续投奖励(54号标)预奖励到账','1455677610','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('698','12','11','-303.00','8900.64','0.00','668.86','230.00','对54号标第1期还款','1455677654','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('699','14','9','303.00','8377.90','309.60','1073.02','200.01','收到会员对54号标第1期的还款','1455677654','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('700','14','23','-2.04','8377.90','307.56','1073.02','200.01','网站已将第54号标第1期还款的利息管理费扣除','1455677654','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('701','12','24','30.00','8930.64','0.00','668.86','200.00','网站对54号标还款完成的解冻保证金','1455677654','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('702','14','6','-400.00','8285.46','0.00','1073.02','600.01','对55号标进行投标','1455677977','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('703','14','33','0.62','8285.46','0.00','1073.02','600.63','续投有效金额(307.56)的奖励(55号标)预奖励','1455677977','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('704','12','17','400.00','9330.64','0.00','668.86','200.00','第55号标复审通过，借款金额入帐','1455678017','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('705','12','18','-4.00','9326.64','0.00','668.86','200.00','第55号标借款成功，扣除借款管理费','1455678017','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('706','12','19','-40.00','9286.64','0.00','668.86','240.00','第55号标借款成功，冻结10%的保证金','1455678017','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('707','14','15','400.00','8285.46','0.00','1473.02','200.63','第55号标复审通过，冻结本金成为待收金额','1455678017','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('708','14','28','10.05','8285.46','0.00','1483.07','200.63','第55号标复审通过，应收利息成为待收利息','1455678017','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('709','12','13','0.02','9286.66','0.00','668.86','240.00','18266479979对55号标投资成功，你获得推广奖励0.02元。','1455678017','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('710','14','34','0.62','8286.08','0.00','1483.07','200.01','续投奖励(55号标)预奖励到账','1455678017','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('711','12','11','-102.51','9184.15','0.00','668.86','240.00','对55号标第1期还款','1455678050','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('712','14','9','102.51','8286.08','102.51','1380.56','200.01','收到会员对55号标第1期的还款','1455678050','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('713','14','23','-2.72','8286.08','99.79','1380.56','200.01','网站已将第55号标第1期还款的利息管理费扣除','1455678050','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('714','12','11','-102.51','9081.64','0.00','668.86','240.00','对55号标第2期还款','1455678060','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('715','14','9','102.51','8286.08','202.30','1278.05','200.01','收到会员对55号标第2期的还款','1455678060','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('716','14','23','-2.05','8286.08','200.25','1278.05','200.01','网站已将第55号标第2期还款的利息管理费扣除','1455678060','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('717','12','11','-102.51','8979.13','0.00','668.86','240.00','对55号标第3期还款','1455678065','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('718','14','9','102.51','8286.08','302.76','1175.54','200.01','收到会员对55号标第3期的还款','1455678065','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('719','14','23','-1.37','8286.08','301.39','1175.54','200.01','网站已将第55号标第3期还款的利息管理费扣除','1455678065','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('720','12','11','-102.52','8876.61','0.00','668.86','240.00','对55号标第4期还款','1455678072','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('721','14','9','102.52','8286.08','403.91','1073.02','200.01','收到会员对55号标第4期的还款','1455678072','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('722','14','23','-0.69','8286.08','403.22','1073.02','200.01','网站已将第55号标第4期还款的利息管理费扣除','1455678072','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('723','12','24','40.00','8916.61','0.00','668.86','200.00','网站对55号标还款完成的解冻保证金','1455678072','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('724','14','6','-100.00','8286.08','303.22','1073.02','300.01','对56号标进行投标','1455678204','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('725','14','33','0.10','8286.08','303.22','1073.02','300.11','续投有效金额(100)的奖励(56号标)预奖励','1455678204','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('726','14','6','-300.00','8286.08','3.22','1073.02','600.11','对50号标进行投标','1455678237','61.156.219.212','15','13706360071');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('727','14','33','0.45','8286.08','3.22','1073.02','600.56','续投有效金额(300)的奖励(50号标)预奖励','1455678237','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('728','12','6','-300.00','8616.61','0.00','668.86','500.00','对48号标进行投标','1455678373','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('729','12','6','-100.00','8516.61','0.00','668.86','600.00','对48号标进行投标','1455678584','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('730','12','8','200.00','8716.61','0.00','668.86','400.00','第48号标募集期内标未满,流标，返回冻结资金','1455691476','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('731','12','8','300.00','9016.61','0.00','668.86','100.00','第48号标募集期内标未满,流标，返回冻结资金','1455691476','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('732','12','8','100.00','9116.61','0.00','668.86','0.00','第48号标募集期内标未满,流标，返回冻结资金','1455691476','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('733','14','8','200.00','8486.08','3.22','1073.02','400.56','第48号标募集期内标未满,流标，返回冻结资金','1455691476','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('734','15','8','50000.00','89490.00','0.00','504.03','10000.00','第48号标募集期内标未满,流标，返回冻结资金','1455691476','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('735','14','35','-0.01','8486.08','3.22','1073.02','400.55','续投奖励(48号标)预奖励取消','1455691476','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('736','6','37','-200.00','18956.75','56576.48','2319.04','710.00','对11号优计划进行了投标','1455698097','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('737','1','17','200.00','25556.20','1490.25','4080.83','300.00','第11号优计划已被认购200元，200元已入帐','1455698097','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('738','6','39','200.00','18956.75','56576.48','2519.04','510.00','您对第11号优计划投标成功，冻结本金成为待收金额','1455698097','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('739','6','38','3.60','18956.75','56576.48','2522.64','510.00','第11号优计划应收利息成为待收利息','1455698097','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('740','1','13','0.40','25556.60','1490.25','4080.83','300.00','15553833036对11号标投资成功，你获得推广奖励0.40元。','1455698097','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('741','6','40','0.40','18957.15','56576.48','2522.64','510.00','优计划续投有效金额(200)的奖励(11号优计划)奖励','1455698097','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('742','6','37','-200.00','18957.15','56376.48','2522.64','710.00','对11号优计划进行了投标','1455698188','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('743','1','17','200.00','25756.60','1490.25','4080.83','300.00','第11号优计划已被认购200元，200元已入帐','1455698188','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('744','6','39','200.00','18957.15','56376.48','2722.64','510.00','您对第11号优计划投标成功，冻结本金成为待收金额','1455698188','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('745','6','38','3.60','18957.15','56376.48','2726.24','510.00','第11号优计划应收利息成为待收利息','1455698188','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('746','1','13','0.40','25757.00','1490.25','4080.83','300.00','15553833036对11号标投资成功，你获得推广奖励0.40元。','1455698188','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('747','6','40','0.40','18957.55','56376.48','2726.24','510.00','优计划续投有效金额(200)的奖励(11号优计划)奖励','1455698188','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('748','12','6','-200.00','8916.61','0.00','668.86','200.00','对57号标进行投标','1455698821','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('749','12','37','-200.00','8716.61','0.00','668.86','400.00','对12号优计划进行了投标','1455760346','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('750','6','17','200.00','19157.55','56376.48','2726.24','510.00','第12号优计划已被认购200元，200元已入帐','1455760346','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('751','12','39','200.00','8716.61','0.00','868.86','200.00','您对第12号优计划投标成功，冻结本金成为待收金额','1455760346','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('752','12','38','1.60','8716.61','0.00','870.46','200.00','第12号优计划应收利息成为待收利息','1455760346','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('753','6','13','0.40','19157.95','56376.48','2726.24','510.00','17853738946对12号标投资成功，你获得推广奖励0.40元。','1455760346','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('754','9','14','-10.00','7990.00','0.00','2030.05','0.00','升级VIP成功','1455845744','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('755','12','4','-100.00','8616.61','0.00','870.46','300.00','提现,默认自动扣减手续费10元','1455933384','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('756','12','4','-100.00','8516.61','0.00','870.46','400.00','提现,默认自动扣减手续费10元','1455933420','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('757','12','36','-100.00','8506.61','0.00','870.46','400.00','提现申请已通过，扣除实际手续费10元，到帐金额100.00元','1455933753','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('758','12','12','100.00','8606.61','0.00','870.46','300.00','提现未通过,返还','1455933763','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('759','12','17','100.00','8706.61','0.00','870.46','300.00','第56号标复审通过，借款金额入帐','1455934091','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('760','12','18','-1.00','8705.61','0.00','870.46','300.00','第56号标借款成功，扣除借款管理费','1455934092','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('761','12','19','-10.00','8695.61','0.00','870.46','310.00','第56号标借款成功，冻结10%的保证金','1455934092','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('762','14','15','100.00','8486.08','3.22','1173.02','300.55','第56号标复审通过，冻结本金成为待收金额','1455934092','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('763','14','28','0.83','8486.08','3.22','1173.85','300.55','第56号标复审通过，应收利息成为待收利息','1455934092','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('764','14','34','0.10','8486.18','3.22','1173.85','300.45','续投奖励(56号标)预奖励到账','1455934092','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('765','12','16','200.00','8895.61','0.00','870.46','110.00','第57号标复审未通过，返回冻结资金','1455934109','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('766','14','46','-1008.33','7481.07','0.00','1173.85','300.45','购买1号债权','1456107192','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('767','14','46','1008.33','7481.07','0.00','2182.18','300.45','购买1号债权,增加待收资金','1456107192','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('768','6','47','1008.33','20166.28','56376.48','2726.24','510.00','转让1号债权','1456107192','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('769','6','47','-1008.33','20166.28','56376.48','1717.91','510.00','转让1号债权,减少待收资金','1456107192','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('770','6','48','-10.08','20156.20','56376.48','1717.91','510.00','转让1号债权手续费（转让金额的1%）','1456107192','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('771','15','36','-10000.00','89480.00','0.00','504.03','10000.00','提现申请已通过，扣除实际手续费10元，到帐金额10000.00元','1456213938','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('772','1','11','-0.83','25757.00','1489.42','4080.83','300.00','对2号企业直投进行还款','1456470753','180.153.81.183','6','');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('773','6','44','0.26','20156.20','56376.74','1717.65','510.00','收到借款人对2号企业直投的还款','1456470753','180.153.81.183','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('774','1','11','-10083.33','17163.09','0.00','4080.83','300.00','对5号企业直投进行还款','1456470753','180.153.81.183','4','');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('775','4','44','10026.67','481414.96','426274.19','108073.20','10100.15','收到借款人对5号企业直投的还款','1456470753','180.153.81.183','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('776','4','6','-400.00','481414.96','425874.19','108073.20','10500.15','对58号标进行投标','1456541485','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('777','4','33','0.60','481414.96','425874.19','108073.20','10500.75','续投有效金额(400)的奖励(58号标)预奖励','1456541485','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('778','4','6','-200.00','481414.96','425674.19','108073.20','10700.75','对26号标进行投标','1456541701','61.156.219.212','11','15166272750');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('779','4','33','0.40','481414.96','425674.19','108073.20','10701.15','续投有效金额(200)的奖励(26号标)预奖励','1456541701','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('780','14','6','-800.00','6681.07','0.00','2182.18','1100.45','对60号标进行投标','1457337222','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('781','12','17','800.00','9695.61','0.00','870.46','110.00','第60号标复审通过，借款金额入帐','1457337247','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('782','12','18','-8.00','9687.61','0.00','870.46','110.00','第60号标借款成功，扣除借款管理费','1457337247','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('783','12','19','-80.00','9607.61','0.00','870.46','190.00','第60号标借款成功，冻结10%的保证金','1457337247','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('784','14','20','8.00','6689.07','0.00','2182.18','1100.45','第60号标复审通过，获取投标奖励','1457337248','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('785','12','21','-8.00','9599.61','0.00','870.46','190.00','第60号标复审通过，支付投标奖励','1457337248','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('786','14','15','800.00','6689.07','0.00','2982.18','300.45','第60号标复审通过，冻结本金成为待收金额','1457337248','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('787','14','28','6.67','6689.07','0.00','2988.85','300.45','第60号标复审通过，应收利息成为待收利息','1457337248','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('788','12','13','0.01','9599.62','0.00','870.46','190.00','18266479979对60号标投资成功，你获得推广奖励0.01元。','1457337248','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('789','12','11','-806.67','8792.95','0.00','870.46','190.00','对60号标第1期还款','1457337259','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('790','14','9','806.67','6689.07','806.67','2182.18','300.45','收到会员对60号标第1期的还款','1457337259','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('791','14','23','-4.53','6689.07','802.14','2182.18','300.45','网站已将第60号标第1期还款的利息管理费扣除','1457337259','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('792','14','99','6.67','6689.07','808.81','2182.18','300.45','收到60号标57号投资121号加息券第1期还款的加息券收益','1457337259','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('793','12','24','80.00','8872.95','0.00','870.46','110.00','网站对60号标还款完成的解冻保证金','1457337259','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('794','6','6','-1500.00','20156.20','54876.74','1717.65','2010.00','对61号标进行投标','1457337322','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('795','6','33','3.00','20156.20','54876.74','1717.65','2013.00','续投有效金额(1500)的奖励(61号标)预奖励','1457337322','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('796','1','17','1500.00','18663.09','0.00','4080.83','300.00','第61号标复审通过，借款金额入帐','1457337411','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('797','1','18','-15.00','18648.09','0.00','4080.83','300.00','第61号标借款成功，扣除借款管理费','1457337411','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('798','1','19','-150.00','18498.09','0.00','4080.83','450.00','第61号标借款成功，冻结10%的保证金','1457337411','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('799','6','15','1500.00','20156.20','54876.74','3217.65','513.00','第61号标复审通过，冻结本金成为待收金额','1457337411','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('800','6','28','25.07','20156.20','54876.74','3242.72','513.00','第61号标复审通过，应收利息成为待收利息','1457337411','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('801','1','13','0.05','18498.14','0.00','4080.83','450.00','15553833036对61号标投资成功，你获得推广奖励0.05元。','1457337411','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('802','6','34','3.00','20159.20','54876.74','3242.72','510.00','续投奖励(61号标)预奖励到账','1457337411','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('803','14','6','-900.00','6597.88','0.00','2182.18','1200.45','对62号标进行投标','1457337455','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('804','14','33','1.62','6597.88','0.00','2182.18','1202.07','续投有效金额(808.81)的奖励(62号标)预奖励','1457337455','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('805','12','17','900.00','9772.95','0.00','870.46','110.00','第62号标复审通过，借款金额入帐','1457337471','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('806','12','18','-9.00','9763.95','0.00','870.46','110.00','第62号标借款成功，扣除借款管理费','1457337471','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('807','12','19','-90.00','9673.95','0.00','870.46','200.00','第62号标借款成功，冻结10%的保证金','1457337471','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('808','14','20','9.00','6606.88','0.00','2182.18','1202.07','第62号标复审通过，获取投标奖励','1457337471','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('809','12','21','-9.00','9664.95','0.00','870.46','200.00','第62号标复审通过，支付投标奖励','1457337471','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('810','14','15','900.00','6606.88','0.00','3082.18','302.07','第62号标复审通过，冻结本金成为待收金额','1457337471','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('811','14','28','15.04','6606.88','0.00','3097.22','302.07','第62号标复审通过，应收利息成为待收利息','1457337471','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('812','12','13','0.03','9664.98','0.00','870.46','200.00','18266479979对62号标投资成功，你获得推广奖励0.03元。','1457337471','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('813','14','34','1.62','6608.50','0.00','3097.22','300.45','续投奖励(62号标)预奖励到账','1457337471','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('814','1','11','-508.36','17989.78','0.00','4080.83','450.00','对61号标第1期还款','1457337491','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('815','6','9','508.36','20159.20','55385.10','2734.36','510.00','收到会员对61号标第1期的还款','1457337491','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('816','6','23','-8.50','20159.20','55376.60','2734.36','510.00','网站已将第61号标第1期还款的利息管理费扣除','1457337491','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('817','6','99','6.25','20159.20','55382.85','2734.36','510.00','收到61号标58号投资132号加息券第1期还款的加息券收益','1457337491','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('818','1','11','-508.36','17481.42','0.00','4080.83','450.00','对61号标第2期还款','1457337492','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('819','6','9','508.36','20159.20','55891.21','2226.00','510.00','收到会员对61号标第2期的还款','1457337492','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('820','6','23','-5.69','20159.20','55885.52','2226.00','510.00','网站已将第61号标第2期还款的利息管理费扣除','1457337492','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('821','6','99','4.18','20159.20','55889.70','2226.00','510.00','收到61号标58号投资132号加息券第2期还款的加息券收益','1457337492','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('822','1','11','-508.36','16973.06','0.00','4080.83','450.00','对61号标第3期还款','1457337494','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('823','6','9','508.36','20159.20','56398.06','1717.64','510.00','收到会员对61号标第3期的还款','1457337494','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('824','6','23','-2.86','20159.20','56395.20','1717.64','510.00','网站已将第61号标第3期还款的利息管理费扣除','1457337494','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('825','6','99','2.09','20159.20','56397.29','1717.64','510.00','收到61号标58号投资132号加息券第3期还款的加息券收益','1457337494','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('826','1','24','150.00','17123.06','0.00','4080.83','300.00','网站对61号标还款完成的解冻保证金','1457337494','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('827','12','11','-305.01','9359.97','0.00','870.46','200.00','对62号标第1期还款','1457337547','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('828','14','9','305.01','6608.50','305.01','2792.21','300.45','收到会员对62号标第1期的还款','1457337547','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('829','14','23','-5.10','6608.50','299.91','2792.21','300.45','网站已将第62号标第1期还款的利息管理费扣除','1457337547','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('830','14','99','3.75','6608.50','303.66','2792.21','300.45','收到62号标59号投资140号加息券第1期还款的加息券收益','1457337547','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('831','12','11','-305.01','9054.96','0.00','870.46','200.00','对62号标第2期还款','1457337551','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('832','14','9','305.01','6608.50','608.67','2487.20','300.45','收到会员对62号标第2期的还款','1457337551','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('833','14','23','-3.41','6608.50','605.26','2487.20','300.45','网站已将第62号标第2期还款的利息管理费扣除','1457337551','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('834','14','99','2.51','6608.50','607.77','2487.20','300.45','收到62号标59号投资140号加息券第2期还款的加息券收益','1457337551','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('835','12','11','-305.01','8749.95','0.00','870.46','200.00','对62号标第3期还款','1457337556','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('836','14','9','305.01','6608.50','912.78','2182.19','300.45','收到会员对62号标第3期的还款','1457337556','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('837','14','23','-1.71','6608.50','911.07','2182.19','300.45','网站已将第62号标第3期还款的利息管理费扣除','1457337556','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('838','14','99','1.26','6608.50','912.33','2182.19','300.45','收到62号标59号投资140号加息券第3期还款的加息券收益','1457337556','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('839','12','24','90.00','8839.95','0.00','870.46','110.00','网站对62号标还款完成的解冻保证金','1457337556','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('840','14','3','100.00','6708.50','912.33','2182.19','300.45','管理员手动审核充值','1457338484','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('841','14','3','50.00','6758.50','912.33','2182.19','300.45','管理员手动审核充值','1457338556','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('842','14','6','-300.00','6758.50','612.33','2182.19','600.45','对63号标进行投标','1457339813','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('843','14','33','0.30','6758.50','612.33','2182.19','600.75','续投有效金额(300)的奖励(63号标)预奖励','1457339813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('844','12','17','300.00','9139.95','0.00','870.46','110.00','第63号标复审通过，借款金额入帐','1457339833','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('845','12','18','-3.00','9136.95','0.00','870.46','110.00','第63号标借款成功，扣除借款管理费','1457339833','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('846','12','19','-30.00','9106.95','0.00','870.46','140.00','第63号标借款成功，冻结10%的保证金','1457339833','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('847','14','20','3.00','6761.50','612.33','2182.19','600.75','第63号标复审通过，获取投标奖励','1457339833','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('848','12','21','-3.00','9103.95','0.00','870.46','140.00','第63号标复审通过，支付投标奖励','1457339833','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('849','14','15','300.00','6761.50','612.33','2482.19','300.75','第63号标复审通过，冻结本金成为待收金额','1457339833','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('850','14','28','3.00','6761.50','612.33','2485.19','300.75','第63号标复审通过，应收利息成为待收利息','1457339833','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('851','12','13','0.01','9103.96','0.00','870.46','140.00','18266479979对63号标投资成功，你获得推广奖励0.01元。','1457339833','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('852','14','34','0.30','6761.80','612.33','2485.19','300.45','续投奖励(63号标)预奖励到账','1457339833','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('853','12','11','-303.00','8800.96','0.00','870.46','140.00','对63号标第1期还款','1457339853','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('854','14','9','303.00','6761.80','915.33','2182.19','300.45','收到会员对63号标第1期的还款','1457339853','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('855','14','23','-2.04','6761.80','913.29','2182.19','300.45','网站已将第63号标第1期还款的利息管理费扣除','1457339853','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('856','12','24','30.00','8830.96','0.00','870.46','110.00','网站对63号标还款完成的解冻保证金','1457339853','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('857','14','6','-200.00','6761.80','713.29','2182.19','500.45','对64号标进行投标','1457340113','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('858','14','33','0.30','6761.80','713.29','2182.19','500.75','续投有效金额(200)的奖励(64号标)预奖励','1457340113','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('859','12','17','200.00','9030.96','0.00','870.46','110.00','第64号标复审通过，借款金额入帐','1457340150','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('860','12','18','-2.00','9028.96','0.00','870.46','110.00','第64号标借款成功，扣除借款管理费','1457340150','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('861','12','19','-20.00','9008.96','0.00','870.46','130.00','第64号标借款成功，冻结10%的保证金','1457340150','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('862','14','20','2.00','6763.80','713.29','2182.19','500.75','第64号标复审通过，获取投标奖励','1457340150','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('863','12','21','-2.00','9006.96','0.00','870.46','130.00','第64号标复审通过，支付投标奖励','1457340150','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('864','14','15','200.00','6763.80','713.29','2382.19','300.75','第64号标复审通过，冻结本金成为待收金额','1457340150','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('865','14','28','3.01','6763.80','713.29','2385.20','300.75','第64号标复审通过，应收利息成为待收利息','1457340150','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('866','12','13','0.01','9006.97','0.00','870.46','130.00','18266479979对64号标投资成功，你获得推广奖励0.01元。','1457340150','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('867','14','34','0.30','6764.10','713.29','2385.20','300.45','续投奖励(64号标)预奖励到账','1457340150','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('868','12','11','-101.50','8905.47','0.00','870.46','130.00','对64号标第1期还款','1457340169','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('869','14','9','101.50','6764.10','814.79','2283.70','300.45','收到会员对64号标第1期的还款','1457340169','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('870','14','23','-1.36','6764.10','813.43','2283.70','300.45','网站已将第64号标第1期还款的利息管理费扣除','1457340169','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('871','14','99','1.00','6764.10','814.43','2283.70','300.45','收到64号标61号投资159号加息券第1期还款的加息券收益','1457340169','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('872','12','11','-101.51','8803.96','0.00','870.46','130.00','对64号标第2期还款','1457340170','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('873','14','9','101.51','6764.10','915.94','2182.19','300.45','收到会员对64号标第2期的还款','1457340170','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('874','14','23','-0.68','6764.10','915.26','2182.19','300.45','网站已将第64号标第2期还款的利息管理费扣除','1457340170','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('875','14','99','0.50','6764.10','915.76','2182.19','300.45','收到64号标61号投资159号加息券第2期还款的加息券收益','1457340170','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('876','12','24','20.00','8823.96','0.00','870.46','110.00','网站对64号标还款完成的解冻保证金','1457340170','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('877','14','6','-200.00','6764.10','715.76','2182.19','500.45','对65号标进行投标','1457342267','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('878','14','33','0.20','6764.10','715.76','2182.19','500.65','续投有效金额(200)的奖励(65号标)预奖励','1457342267','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('879','6','6','-1000.00','20159.20','55397.29','1717.64','1510.00','对66号标进行投标','1457343001','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('880','6','33','2.00','20159.20','55397.29','1717.64','1512.00','续投有效金额(1000)的奖励(66号标)预奖励','1457343001','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('881','12','17','200.00','9023.96','0.00','870.46','110.00','第65号标复审通过，借款金额入帐','1457343050','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('882','12','18','-2.00','9021.96','0.00','870.46','110.00','第65号标借款成功，扣除借款管理费','1457343050','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('883','12','19','-20.00','9001.96','0.00','870.46','130.00','第65号标借款成功，冻结10%的保证金','1457343050','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('884','14','20','2.00','6766.10','715.76','2182.19','500.65','第65号标复审通过，获取投标奖励','1457343050','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('885','12','21','-2.00','8999.96','0.00','870.46','130.00','第65号标复审通过，支付投标奖励','1457343050','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('886','14','15','200.00','6766.10','715.76','2382.19','300.65','第65号标复审通过，冻结本金成为待收金额','1457343050','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('887','14','28','1.67','6766.10','715.76','2383.86','300.65','第65号标复审通过，应收利息成为待收利息','1457343050','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('888','14','34','0.20','6766.30','715.76','2383.86','300.45','续投奖励(65号标)预奖励到账','1457343050','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('889','14','6','-200.00','6766.30','515.76','2383.86','500.45','对67号标进行投标','1457343137','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('890','14','33','0.20','6766.30','515.76','2383.86','500.65','续投有效金额(200)的奖励(67号标)预奖励','1457343137','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('891','12','17','200.00','9199.96','0.00','870.46','130.00','第67号标复审通过，借款金额入帐','1457343153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('892','12','18','-2.00','9197.96','0.00','870.46','130.00','第67号标借款成功，扣除借款管理费','1457343153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('893','12','19','-20.00','9177.96','0.00','870.46','150.00','第67号标借款成功，冻结10%的保证金','1457343153','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('894','14','20','2.00','6768.30','515.76','2383.86','500.65','第67号标复审通过，获取投标奖励','1457343153','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('895','12','21','-2.00','9175.96','0.00','870.46','150.00','第67号标复审通过，支付投标奖励','1457343154','61.156.219.212','14','18266479979');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('896','14','15','200.00','6768.30','515.76','2583.86','300.65','第67号标复审通过，冻结本金成为待收金额','1457343154','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('897','14','28','1.67','6768.30','515.76','2585.53','300.65','第67号标复审通过，应收利息成为待收利息','1457343154','61.156.219.212','12','17853738946');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('898','14','34','0.20','6768.50','515.76','2585.53','300.45','续投奖励(67号标)预奖励到账','1457343154','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('899','23','7','10000000.00','10000000.00','0.00','0.00','0.00','1','1458634960','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('900','23','14','-10.00','9999990.00','0.00','0.00','0.00','升级VIP成功','1458634972','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('901','4','6','-500.00','481414.96','425174.19','108073.20','11201.15','对69号标进行投标','1458723534','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('902','4','33','1.00','481414.96','425174.19','108073.20','11202.15','续投有效金额(500.00)的奖励(69号标)预奖励','1458723534','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('903','4','6','-2500.00','481414.96','422674.19','108073.20','13702.15','对69号标进行投标','1458723633','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('904','4','33','5.00','481414.96','422674.19','108073.20','13707.15','续投有效金额(2500)的奖励(69号标)预奖励','1458723634','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('905','6','17','3000.00','23159.20','55397.29','1717.64','1512.00','第69号标复审通过，借款金额入帐','1458723787','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('906','6','18','-78.00','23081.20','55397.29','1717.64','1512.00','第69号标借款成功，扣除借款管理费','1458723787','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('907','6','19','-300.00','22781.20','55397.29','1717.64','1812.00','第69号标借款成功，冻结10%的保证金','1458723787','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('908','4','15','500.00','481414.96','422674.19','108573.20','13207.15','第69号标复审通过，冻结本金成为待收金额','1458723787','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('909','4','28','12.58','481414.96','422674.19','108585.78','13207.15','第69号标复审通过，应收利息成为待收利息','1458723787','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('910','2','13','0.03','10161547.57','302.41','5040.03','10200.00','18888888888对69号标投资成功，你获得推广奖励0.03元。','1458723787','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('911','4','15','2500.00','481414.96','422674.19','111085.78','10707.15','第69号标复审通过，冻结本金成为待收金额','1458723787','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('912','4','28','62.85','481414.96','422674.19','111148.63','10707.15','第69号标复审通过，应收利息成为待收利息','1458723787','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('913','2','13','0.13','10161547.70','302.41','5040.03','10200.00','18888888888对69号标投资成功，你获得推广奖励0.13元。','1458723787','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('914','4','34','1.00','481415.96','422674.19','111148.63','10706.15','续投奖励(69号标)预奖励到账','1458723787','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('915','4','34','5.00','481420.96','422674.19','111148.63','10701.15','续投奖励(69号标)预奖励到账','1458723787','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('916','6','11','-615.09','22781.20','54782.20','1717.64','1812.00','对69号标第1期还款','1458723807','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('917','4','9','102.52','481420.96','422776.71','111046.11','10701.15','收到会员对69号标第1期的还款','1458723807','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('918','4','23','-2.83','481420.96','422773.88','111046.11','10701.15','网站已将第69号标第1期还款的利息管理费扣除','1458723807','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('919','4','9','512.57','481420.96','423286.45','110533.54','10701.15','收到会员对69号标第1期的还款','1458723807','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('920','4','23','-14.17','481420.96','423272.28','110533.54','10701.15','网站已将第69号标第1期还款的利息管理费扣除','1458723807','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('921','6','11','-615.09','22781.20','54167.11','1717.64','1812.00','对69号标第2期还款','1458723813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('922','4','9','102.52','481420.96','423374.80','110431.02','10701.15','收到会员对69号标第2期的还款','1458723813','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('923','4','23','-2.28','481420.96','423372.52','110431.02','10701.15','网站已将第69号标第2期还款的利息管理费扣除','1458723813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('924','4','9','512.57','481420.96','423885.09','109918.45','10701.15','收到会员对69号标第2期的还款','1458723813','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('925','4','23','-11.38','481420.96','423873.71','109918.45','10701.15','网站已将第69号标第2期还款的利息管理费扣除','1458723813','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('926','6','11','-615.08','22781.20','53552.03','1717.64','1812.00','对69号标第3期还款','1458723815','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('927','4','9','102.51','481420.96','423976.22','109815.94','10701.15','收到会员对69号标第3期的还款','1458723815','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('928','4','23','-1.71','481420.96','423974.51','109815.94','10701.15','网站已将第69号标第3期还款的利息管理费扣除','1458723815','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('929','4','9','512.57','481420.96','424487.08','109303.37','10701.15','收到会员对69号标第3期的还款','1458723815','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('930','4','23','-8.57','481420.96','424478.51','109303.37','10701.15','网站已将第69号标第3期还款的利息管理费扣除','1458723815','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('931','6','11','-615.09','22781.20','52936.94','1717.64','1812.00','对69号标第4期还款','1458723816','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('932','4','9','102.52','481420.96','424581.03','109200.85','10701.15','收到会员对69号标第4期的还款','1458723816','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('933','4','23','-1.15','481420.96','424579.88','109200.85','10701.15','网站已将第69号标第4期还款的利息管理费扣除','1458723816','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('934','4','9','512.57','481420.96','425092.45','108688.28','10701.15','收到会员对69号标第4期的还款','1458723816','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('935','4','23','-5.74','481420.96','425086.71','108688.28','10701.15','网站已将第69号标第4期还款的利息管理费扣除','1458723816','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('936','6','11','-615.09','22781.20','52321.85','1717.64','1812.00','对69号标第5期还款','1458723818','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('937','4','9','102.52','481420.96','425189.23','108585.76','10701.15','收到会员对69号标第5期的还款','1458723818','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('938','4','23','-0.58','481420.96','425188.65','108585.76','10701.15','网站已将第69号标第5期还款的利息管理费扣除','1458723818','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('939','4','9','512.57','481420.96','425701.22','108073.19','10701.15','收到会员对69号标第5期的还款','1458723818','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('940','4','23','-2.88','481420.96','425698.34','108073.19','10701.15','网站已将第69号标第5期还款的利息管理费扣除','1458723818','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('941','4','6','-400.00','481420.96','425298.34','108073.19','11101.15','对70号标进行投标','1464832905','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('942','4','33','0.80','481420.96','425298.34','108073.19','11101.95','续投有效金额(400)的奖励(70号标)预奖励','1464832905','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('943','4','6','-1600.00','481420.96','423698.34','108073.19','12701.95','对70号标进行投标','1464832944','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('944','4','33','3.20','481420.96','423698.34','108073.19','12705.15','续投有效金额(1600)的奖励(70号标)预奖励','1464832944','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('945','6','17','2000.00','24781.20','52321.85','1717.64','1812.00','第70号标复审通过，借款金额入帐','1464832954','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('946','6','18','-64.00','24717.20','52321.85','1717.64','1812.00','第70号标借款成功，扣除借款管理费','1464832954','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('947','6','19','-200.00','24517.20','52321.85','1717.64','2012.00','第70号标借款成功，冻结10%的保证金','1464832954','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('948','4','15','400.00','481420.96','423698.34','108473.19','12305.15','第70号标复审通过，冻结本金成为待收金额','1464832955','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('949','4','28','18.56','481420.96','423698.34','108491.75','12305.15','第70号标复审通过，应收利息成为待收利息','1464832955','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('950','2','13','0.04','10161547.74','302.41','5040.03','10200.00','18888888888对70号标投资成功，你获得推广奖励0.04元。','1464832955','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('951','4','15','1600.00','481420.96','423698.34','110091.75','10705.15','第70号标复审通过，冻结本金成为待收金额','1464832955','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('952','4','28','74.25','481420.96','423698.34','110166.00','10705.15','第70号标复审通过，应收利息成为待收利息','1464832955','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('953','2','13','0.15','10161547.89','302.41','5040.03','10200.00','18888888888对70号标投资成功，你获得推广奖励0.15元。','1464832955','61.156.219.212','4','18888888888');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('954','4','34','0.80','481421.76','423698.34','110166.00','10704.35','续投奖励(70号标)预奖励到账','1464832955','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('955','4','34','3.20','481424.96','423698.34','110166.00','10701.15','续投奖励(70号标)预奖励到账','1464832955','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('956','6','11','-209.27','24517.20','52112.58','1717.64','2012.00','对70号标第1期还款','1464832973','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('957','4','9','41.85','481424.96','423740.19','110124.15','10701.15','收到会员对70号标第1期的还款','1464832973','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('958','4','23','-2.27','481424.96','423737.92','110124.15','10701.15','网站已将第70号标第1期还款的利息管理费扣除','1464832973','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('959','4','9','167.42','481424.96','423905.34','109956.73','10701.15','收到会员对70号标第1期的还款','1464832973','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('960','4','23','-9.07','481424.96','423896.27','109956.73','10701.15','网站已将第70号标第1期还款的利息管理费扣除','1464832973','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('961','6','11','-209.28','24517.20','51903.30','1717.64','2012.00','对70号标第2期还款','1464832974','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('962','4','9','41.85','481424.96','423938.12','109914.88','10701.15','收到会员对70号标第2期的还款','1464832974','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('963','4','23','-2.05','481424.96','423936.07','109914.88','10701.15','网站已将第70号标第2期还款的利息管理费扣除','1464832974','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('964','4','9','167.43','481424.96','424103.50','109747.45','10701.15','收到会员对70号标第2期的还款','1464832974','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('965','4','23','-8.19','481424.96','424095.31','109747.45','10701.15','网站已将第70号标第2期还款的利息管理费扣除','1464832974','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('966','6','11','-209.28','24517.20','51694.02','1717.64','2012.00','对70号标第3期还款','1464832975','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('967','4','9','41.86','481424.96','424137.17','109705.59','10701.15','收到会员对70号标第3期的还款','1464832975','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('968','4','23','-1.83','481424.96','424135.34','109705.59','10701.15','网站已将第70号标第3期还款的利息管理费扣除','1464832975','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('969','4','9','167.42','481424.96','424302.76','109538.17','10701.15','收到会员对70号标第3期的还款','1464832975','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('970','4','23','-7.31','481424.96','424295.45','109538.17','10701.15','网站已将第70号标第3期还款的利息管理费扣除','1464832975','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('971','6','11','-209.28','24517.20','51484.74','1717.64','2012.00','对70号标第4期还款','1464832978','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('972','4','9','41.85','481424.96','424337.30','109496.32','10701.15','收到会员对70号标第4期的还款','1464832978','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('973','4','23','-1.61','481424.96','424335.69','109496.32','10701.15','网站已将第70号标第4期还款的利息管理费扣除','1464832978','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('974','4','9','167.43','481424.96','424503.12','109328.89','10701.15','收到会员对70号标第4期的还款','1464832978','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('975','4','23','-6.43','481424.96','424496.69','109328.89','10701.15','网站已将第70号标第4期还款的利息管理费扣除','1464832978','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('976','6','11','-209.27','24517.20','51275.47','1717.64','2012.00','对70号标第5期还款','1464832979','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('977','4','9','41.85','481424.96','424538.54','109287.04','10701.15','收到会员对70号标第5期的还款','1464832979','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('978','4','23','-1.38','481424.96','424537.16','109287.04','10701.15','网站已将第70号标第5期还款的利息管理费扣除','1464832979','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('979','4','9','167.42','481424.96','424704.58','109119.62','10701.15','收到会员对70号标第5期的还款','1464832979','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('980','4','23','-5.53','481424.96','424699.05','109119.62','10701.15','网站已将第70号标第5期还款的利息管理费扣除','1464832979','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('981','6','11','-209.29','24517.20','51066.18','1717.64','2012.00','对70号标第6期还款','1464832980','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('982','4','9','41.86','481424.96','424740.91','109077.76','10701.15','收到会员对70号标第6期的还款','1464832980','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('983','4','23','-1.16','481424.96','424739.75','109077.76','10701.15','网站已将第70号标第6期还款的利息管理费扣除','1464832980','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('984','4','9','167.43','481424.96','424907.18','108910.33','10701.15','收到会员对70号标第6期的还款','1464832980','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('985','4','23','-4.63','481424.96','424902.55','108910.33','10701.15','网站已将第70号标第6期还款的利息管理费扣除','1464832980','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('986','6','11','-209.29','24517.20','50856.89','1717.64','2012.00','对70号标第7期还款','1464832983','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('987','4','9','41.86','481424.96','424944.41','108868.47','10701.15','收到会员对70号标第7期的还款','1464832983','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('988','4','23','-0.93','481424.96','424943.48','108868.47','10701.15','网站已将第70号标第7期还款的利息管理费扣除','1464832983','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('989','4','9','167.43','481424.96','425110.91','108701.04','10701.15','收到会员对70号标第7期的还款','1464832983','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('990','4','23','-3.72','481424.96','425107.19','108701.04','10701.15','网站已将第70号标第7期还款的利息管理费扣除','1464832983','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('991','6','11','-209.29','24517.20','50647.60','1717.64','2012.00','对70号标第8期还款','1464832985','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('992','4','9','41.86','481424.96','425149.05','108659.18','10701.15','收到会员对70号标第8期的还款','1464832985','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('993','4','23','-0.70','481424.96','425148.35','108659.18','10701.15','网站已将第70号标第8期还款的利息管理费扣除','1464832985','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('994','4','9','167.43','481424.96','425315.78','108491.75','10701.15','收到会员对70号标第8期的还款','1464832985','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('995','4','23','-2.80','481424.96','425312.98','108491.75','10701.15','网站已将第70号标第8期还款的利息管理费扣除','1464832985','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('996','6','11','-209.29','24517.20','50438.31','1717.64','2012.00','对70号标第9期还款','1464832987','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('997','4','9','41.86','481424.96','425354.84','108449.89','10701.15','收到会员对70号标第9期的还款','1464832987','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('998','4','23','-0.47','481424.96','425354.37','108449.89','10701.15','网站已将第70号标第9期还款的利息管理费扣除','1464832987','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('999','4','9','167.43','481424.96','425521.80','108282.46','10701.15','收到会员对70号标第9期的还款','1464832987','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1000','4','23','-1.87','481424.96','425519.93','108282.46','10701.15','网站已将第70号标第9期还款的利息管理费扣除','1464832987','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1001','6','11','-209.28','24517.20','50229.03','1717.64','2012.00','对70号标第10期还款','1464833003','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1002','4','9','41.86','481424.96','425561.79','108240.60','10701.15','收到会员对70号标第10期的还款','1464833003','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1003','4','23','-0.24','481424.96','425561.55','108240.60','10701.15','网站已将第70号标第10期还款的利息管理费扣除','1464833003','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1004','4','9','167.42','481424.96','425728.97','108073.18','10701.15','收到会员对70号标第10期的还款','1464833003','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1005','4','23','-0.94','481424.96','425728.03','108073.18','10701.15','网站已将第70号标第10期还款的利息管理费扣除','1464833003','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1006','6','24','200.00','24717.20','50229.03','1717.64','1812.00','网站对70号标还款完成的解冻保证金','1464833003','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1007','1','10','1002.74','17123.06','1002.74','3078.09','300.00','网站对5号标第1期代还','1459386341','124.236.30.191','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1008','1','10','1002.74','17123.06','2005.48','2075.35','300.00','网站对5号标第1期代还','1459386341','124.236.30.191','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1009','8','7','10000.00','10000.01','0.00','0.00','0.00','','1459476158','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1010','8','4','-1000.00','9000.01','0.00','0.00','1000.00','提现,默认自动扣减手续费10元','1459476170','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1011','8','36','-1000.00','8990.01','0.00','0.00','1000.00','提现申请已通过，扣除实际手续费10元，到帐金额1000.00元','1459476202','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1012','8','29','-1000.00','8990.01','0.00','0.00','0.00','提现成功,扣除实际手续费10.00元，减去冻结资金，到帐金额1000.00元','1459476278','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1013','18','7','100000.00','100000.00','0.00','0.00','0.00','1','1459481910','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1014','18','37','-200.00','99800.00','0.00','0.00','200.00','对14号优计划进行了投标','1459481927','61.156.219.212','23','18654658738');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1015','23','17','200.00','10000190.00','0.00','0.00','0.00','第14号优计划已被认购200元，200元已入帐','1459481927','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1016','18','39','200.00','99800.00','0.00','200.00','0.00','您对第14号优计划投标成功，冻结本金成为待收金额','1459481927','61.156.219.212','23','18654658738');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1017','18','38','12.96','99800.00','0.00','212.96','0.00','第14号优计划应收利息成为待收利息','1459481927','61.156.219.212','23','18654658738');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1018','5','13','0.40','0.40','0.00','0.00','0.00','13148437042对14号标投资成功，你获得推广奖励0.40元。','1459481927','61.156.219.212','18','13148437042');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1019','9','10','253.76','7990.00','253.76','1776.29','0.00','网站对13号标第1期代还','1459784511','114.255.40.24','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1020','9','10','761.27','7990.00','1015.03','1015.02','0.00','网站对13号标第1期代还','1459784511','114.255.40.24','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1021','20','7','5000.00','5000.00','0.00','0.00','0.00','0','1459822693','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1022','20','37','-200.00','4800.00','0.00','0.00','200.00','对9号优计划进行了投标','1459822724','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1023','1','17','200.00','17323.06','2005.48','2075.35','300.00','第9号优计划已被认购200元，200元已入帐','1459822724','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1024','20','39','200.00','4800.00','0.00','200.00','0.00','您对第9号优计划投标成功，冻结本金成为待收金额','1459822724','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1025','20','38','0.64','4800.00','0.00','200.64','0.00','第9号优计划应收利息成为待收利息','1459822724','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1026','20','14','-10.00','4790.00','0.00','200.64','0.00','升级VIP成功','1459823951','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1027','26','7','100000.00','100000.00','0.00','0.00','0.00','yinwei wo queqian','1459837222','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1028','26','14','-10.00','99990.00','0.00','0.00','0.00','升级VIP成功','1459837270','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1029','25','27','10000000.00','10000000.00','0.00','0.00','0.00','管理员手动审核充值','1459839108','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1030','25','6','-10000.00','9990000.00','0.00','0.00','10000.00','对71号标进行投标','1459839486','61.156.219.212','26','18264843589');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1031','26','17','10000.00','109990.00','0.00','0.00','0.00','第71号标复审通过，借款金额入帐','1459839756','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1032','26','18','-100.00','109890.00','0.00','0.00','0.00','第71号标借款成功，扣除借款管理费','1459839756','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1033','26','19','-1000.00','108890.00','0.00','0.00','1000.00','第71号标借款成功，冻结10%的保证金','1459839756','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1034','25','15','10000.00','9990000.00','0.00','10000.00','0.00','第71号标复审通过，冻结本金成为待收金额','1459839756','61.156.219.212','26','18264843589');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1035','25','28','31.25','9990000.00','0.00','10031.25','0.00','第71号标复审通过，应收利息成为待收利息','1459839756','61.156.219.212','26','18264843589');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1036','26','11','-10031.25','98858.75','0.00','0.00','1000.00','对71号标第1期还款','1459926803','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1037','25','9','10031.25','9990000.00','10031.25','0.00','0.00','收到会员对71号标第1期的还款','1459926803','61.156.219.212','26','18264843589');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1038','25','23','-21.25','9990000.00','10010.00','0.00','0.00','网站已将第71号标第1期还款的利息管理费扣除','1459926803','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1039','26','24','1000.00','99858.75','0.00','0.00','0.00','网站对71号标还款完成的解冻保证金','1459926803','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1040','27','27','10000.00','10000.00','0.00','0.00','0.00','管理员手动审核充值','1460099212','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1041','27','37','-2000.00','8000.00','0.00','0.00','2000.00','对15号优计划进行了投标','1460099337','61.156.219.212','23','18654658738');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1042','23','17','2000.00','10002190.00','0.00','0.00','0.00','第15号优计划已被认购2000元，2000元已入帐','1460099337','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1043','27','39','2000.00','8000.00','0.00','2000.00','0.00','您对第15号优计划投标成功，冻结本金成为待收金额','1460099337','61.156.219.212','23','18654658738');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1044','27','38','5.34','8000.00','0.00','2005.34','0.00','第15号优计划应收利息成为待收利息','1460099337','61.156.219.212','23','18654658738');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1045','6','13','4.00','24721.20','50229.03','1717.64','1812.00','18206386604对15号标投资成功，你获得推广奖励4.00元。','1460099337','61.156.219.212','27','18206386604');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1046','29','7','10.00','10.00','0.00','0.00','0.00','12','1460517531','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1047','29','14','-10.00','0.00','0.00','0.00','0.00','升级VIP成功','1460517605','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1048','29','7','5000.00','5000.00','0.00','0.00','0.00','123','1460517718','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1049','29','37','-200.00','4800.00','0.00','0.00','200.00','对9号优计划进行了投标','1460517750','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1050','1','17','200.00','17523.06','2005.48','2075.35','300.00','第9号优计划已被认购200元，200元已入帐','1460517751','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1051','29','39','200.00','4800.00','0.00','200.00','0.00','您对第9号优计划投标成功，冻结本金成为待收金额','1460517751','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1052','29','38','0.64','4800.00','0.00','200.64','0.00','第9号优计划应收利息成为待收利息','1460517751','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1053','29','37','-100.00','4700.00','0.00','200.64','100.00','对12号优计划进行了投标','1460519267','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1054','6','17','100.00','24821.20','50229.03','1717.64','1812.00','第12号优计划已被认购100元，100元已入帐','1460519267','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1055','29','39','100.00','4700.00','0.00','300.64','0.00','您对第12号优计划投标成功，冻结本金成为待收金额','1460519267','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1056','29','38','0.78','4700.00','0.00','301.42','0.00','第12号优计划应收利息成为待收利息','1460519267','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1057','30','7','1000000000.00','1000000000.00','0.00','0.00','0.00','123','1460519748','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1058','30','14','-10.00','999999990.00','0.00','0.00','0.00','升级VIP成功','1460519793','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1059','30','37','-1000.00','999998990.00','0.00','0.00','1000.00','对9号优计划进行了投标','1460528950','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1060','1','17','1000.00','18523.06','2005.48','2075.35','300.00','第9号优计划已被认购1000元，1000元已入帐','1460528950','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1061','1','18','-20.00','18503.06','2005.48','2075.35','300.00','第9号优计划被认购完毕，扣除借款管理费20.00元','1460528950','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1062','30','39','1000.00','999998990.00','0.00','1000.00','0.00','您对第9号优计划投标成功，冻结本金成为待收金额','1460528951','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1063','30','38','3.20','999998990.00','0.00','1003.20','0.00','第9号优计划应收利息成为待收利息','1460528951','61.156.219.212','1','18661395415');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1064','29','7','-4700.00','0.00','0.00','301.42','0.00','111','1460529754','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1065','29','7','200.00','200.00','0.00','301.42','0.00','123','1460530434','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1066','29','7','500.00','700.00','0.00','301.42','0.00','12','1460530489','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1067','29','37','-500.00','200.00','0.00','301.42','500.00','对6号优计划进行了投标','1460530506','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1068','6','17','500.00','25321.20','50229.03','1717.64','1812.00','第6号优计划已被认购500元，500元已入帐','1460530506','61.156.219.212','0','@网站管理员@');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1069','29','39','500.00','200.00','0.00','801.42','0.00','您对第6号优计划投标成功，冻结本金成为待收金额','1460530506','61.156.219.212','6','15553833036');/* DBReback Separation */
 /* 插入数据 `shang_member_moneylog` */
 INSERT INTO `shang_member_moneylog` VALUES ('1070','29','38','6.78','200.00','0.00','808.20','0.00','第6号优计划应收利息成为待收利息','1460530506','61.156.219.212','6','15553833036');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_msg`*/ 
 DROP TABLE IF EXISTS `shang_member_msg`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) NOT NULL,
  `from_uname` varchar(20) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `to_uname` varchar(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `msg` varchar(2000) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) NOT NULL,
  `to_del` tinyint(4) NOT NULL DEFAULT '0',
  `from_del` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_member_payonline`*/ 
 DROP TABLE IF EXISTS `shang_member_payonline`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_payonline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `nid` char(32) NOT NULL,
  `money` decimal(15,2) NOT NULL,
  `fee` decimal(8,2) NOT NULL,
  `way` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `tran_id` varchar(50) NOT NULL,
  `off_bank` varchar(50) NOT NULL,
  `off_way` varchar(100) NOT NULL,
  `deal_user` varchar(40) NOT NULL,
  `deal_uid` int(11) NOT NULL,
  `payimg` varchar(1000) NOT NULL COMMENT '上传打款凭证',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`status`,`nid`,`id`),
  KEY `uid_2` (`uid`,`money`,`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('1','2','offline','10000000.00','0.00','off','1','1453768934','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('2','4','offline','1000000.00','0.00','off','1','1453769206','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('3','2','offline','100000.00','0.00','off','1','1453769584','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','汇款','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('4','1','33864d6bae4b2d61380c65a451035712','10000.00','0.00','allinpay','1','1453794070','61.156.219.212','20160126154110413519','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('5','4','49223e527f0b460cb8c5337f85e864f0','10000.00','0.00','allinpay','1','1453864995','61.156.219.212','20160127112315505898','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('6','4','be548f15445d4dccff52a6b32a7a96dd','10000.00','0.00','allinpay','0','1453865004','61.156.219.212','20160127112324225671','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('7','4','e6357541b9f420f9915f5a0980fbb916','10000.00','0.00','allinpay','0','1453865017','61.156.219.212','20160127112337675130','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('8','4','bbdea3cff36e7f33940b1e2ebc4cb9dc','10000.00','0.00','allinpay','0','1453865087','61.156.219.212','20160127112447267237','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('9','6','dbe36f8f16a072796ac547cf4e35ed5b','1000.00','0.00','allinpay','0','1453873062','61.156.219.212','20160127133742485142','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('10','8','742b68c01ba0c22e6c0e98a7fd6ae194','50.00','5.00','chinabank','0','1454033356','61.156.219.212','','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('11','8','0c77674207297825b9c3c655b591688c','50.00','5.00','chinabank','0','1454036045','61.156.219.212','20160129105405107038','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('12','8','5739c23119f695006a7105a9ffafae9e','50.00','5.00','chinabank','0','1454036366','61.156.219.212','20160129105926946320','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('13','8','abfb0501160fa9552fbad4058dde39d6','50.00','5.00','chinabank','0','1454036913','61.156.219.212','20160129110833633405','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('14','8','ec26b91b5af510fbb6f9b827cbfebf4f','0.01','0.00','chinabank','0','1454037920','61.156.219.212','20160129112520306823','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('15','8','93f5a7445aa1ecdb7fb723b602db0b60','0.01','0.00','chinabank','0','1454038799','61.156.219.212','20160129113959808442','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('16','8','36840abd01f2f74e8955ee546943704a','0.01','0.00','chinabank','1','1454039050','61.156.219.212','20160129114410911663','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('17','8','5ad757740918123b7c7ba4011f889219','0.01','0.00','chinabank','0','1454039512','61.156.219.212','20160129115152217209','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('18','8','ae216e66b0533ba8ca0aea9bb15d768a','0.01','0.00','chinabank','0','1454039521','61.156.219.212','20160129115201809908','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('19','8','b74045aaac491586c2aceb6ba06d9ac6','0.01','0.00','chinabank','0','1454039588','61.156.219.212','20160129115308115302','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('20','8','df5f3b90e986cebafcdcf9cc58ef659b','0.01','0.00','chinabank','0','1454039594','61.156.219.212','20160129115314344389','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('21','8','386d7378fc5d9e0f2f9df67671c4c23b','0.01','0.00','chinabank','0','1454039621','61.156.219.212','20160129115341367881','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('22','8','c526779fee59df289bd4b0c7e26a8838','0.01','0.00','chinabank','0','1454039935','61.156.219.212','20160129115855662873','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('23','8','f354ed65445ecdb9af5bcba660e23cd5','0.01','0.00','chinabank','0','1454039940','61.156.219.212','20160129115900976813','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('24','8','569fffd5e2517a6976e8204a9d2811ba','0.01','0.00','chinabank','0','1454039965','61.156.219.212','20160129115925749445','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('25','8','8130dd8c19d6eab7abe0fc6fbd4e4baa','0.01','0.00','chinabank','0','1454039993','61.156.219.212','20160129115953450316','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('26','12','e58c001178e1cfd67f2831b3bc97dc0b','10000.00','0.00','allinpay','1','1454119053','61.156.219.212','20160130095733910626','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('27','12','offline','10000.00','0.00','off','0','1454119158','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','柜台汇款','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('28','12','offline','10000.00','0.00','off','0','1454119431','61.156.219.212','20160129114410911663','中国银行 开户名：刘克涛','网银转账','','0','a:1:{i:0;s:46:\"/Static/Uploads/PayImg/12/2016013010034414.jpg\";}');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('29','12','offline','10000.00','0.00','off','0','1454119431','61.156.219.212','20160129114410911663','中国银行 开户名：刘克涛','网银转账','','0','a:1:{i:0;s:46:\"/Static/Uploads/PayImg/12/2016013010034414.jpg\";}');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('30','3','offline','10000.00','0.00','off','1','1454292862','222.173.174.202','555','中国银行 开户名：刘克涛','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('31','13','offline','100000.00','0.00','off','1','1455502940','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','汇款','tuanshang','113','a:1:{i:0;s:47:\"/Static/Uploads/PayImg/13/20160215102157721.jpg\";}');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('32','4','c4edb3d18c916531cd83db3bc08ae797','200.00','0.00','allinpay','0','1455504994','61.156.219.212','20160215105634833080','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('33','4','offline','1000.00','0.00','off','0','1455505093','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','充值','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('34','14','69b89c64d13cef572afc20fd7102b567','10000.00','0.00','allinpay','1','1455514638','61.156.219.212','20160215133718281766','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('35','4','offline','1000.00','0.00','off','1','1455521455','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','汇款','tuanshang','113','a:1:{i:0;s:46:\"/Static/Uploads/PayImg/4/20160215153031328.png\";}');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('36','15','186dd310e5e4d392733585738df0a3ec','100000.00','0.00','allinpay','1','1455526430','61.156.219.212','20160215165350812848','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('37','14','c17977a7972919ec73e5eab0dba73a15','100.00','0.00','allinpaywap','1','1457338446','61.156.219.212','20160307161406815782','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('38','14','2d847692141a6f65886063e62d05546b','50.00','0.00','allinpaywap','1','1457338525','61.156.219.212','20160307161525151924','','','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('39','25','offline','10000000.00','0.00','off','1','1459839083','61.156.219.212','3695656856521512','中国银行 开户名：刘克涛','网银转帐','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('40','27','offline','10000.00','0.00','off','1','1460099202','61.156.219.212','00','中国银行 开户名：刘克涛','0','tuanshang','113','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('41','30','offline','1000.00','0.00','off','0','1460519130','61.156.219.212','1111','中国银行 开户名：刘克涛','123','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('42','30','offline','1000.00','0.00','off','0','1460519263','61.156.219.212','123123','中国农业银行 开户名：刘克涛','112233','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('43','30','5ff9bfaf62ed1cdb669401a85fb6a981','11111111.00','0.00','allinpay','0','1460519452','61.156.219.212','20160413115052319853','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('44','30','de8320a0dc7870e129c6cba63ed688f2','123.00','0.00','allinpay','0','1460519460','61.156.219.212','20160413115100992215','','','','0','');/* DBReback Separation */
 /* 插入数据 `shang_member_payonline` */
 INSERT INTO `shang_member_payonline` VALUES ('45','30','offline','123.00','0.00','off','0','1460519472','61.156.219.212','123123','中国银行 开户名：刘克涛','','','0','');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_remark`*/ 
 DROP TABLE IF EXISTS `shang_member_remark`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_remark` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_real_name` varchar(50) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_member_safequestion`*/ 
 DROP TABLE IF EXISTS `shang_member_safequestion`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_safequestion` (
  `uid` int(10) unsigned NOT NULL,
  `question1` varchar(100) NOT NULL,
  `answer1` varchar(100) NOT NULL,
  `question2` varchar(100) NOT NULL,
  `answer2` varchar(100) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_safequestion` */
 INSERT INTO `shang_member_safequestion` VALUES ('4','您的出生地是哪里？','0','您打字经常用什么输入法？','0','1453883992');/* DBReback Separation */
 /* 插入数据 `shang_member_safequestion` */
 INSERT INTO `shang_member_safequestion` VALUES ('15','您的属相是什么的？','马','您打字经常用什么输入法？','搜狗','1455583700');/* DBReback Separation */ 
 /* 数据表结构 `shang_member_withdraw`*/ 
 DROP TABLE IF EXISTS `shang_member_withdraw`;/* DBReback Separation */ 
 CREATE TABLE `shang_member_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `withdraw_money` decimal(15,2) NOT NULL,
  `withdraw_status` tinyint(4) NOT NULL,
  `withdraw_fee` decimal(15,2) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_user` varchar(50) NOT NULL,
  `deal_info` varchar(200) NOT NULL,
  `second_fee` decimal(15,2) NOT NULL COMMENT '修改后的提现手续费',
  `success_money` decimal(15,2) NOT NULL COMMENT '实际到账金额',
  `account_num` decimal(15,2) DEFAULT NULL COMMENT '从充值资金池中体现的金额',
  `back_num` decimal(15,2) DEFAULT NULL COMMENT '从回款资金池中体现的金额',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`withdraw_status`,`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('1','4','10000.00','2','50.00','1453865656','61.156.219.212','1455521626','tuanshang','恭喜提现成功','50.00','10000.00','10000.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('3','13','10000.00','1','50.00','1455507376','61.156.219.212','1455507398','tuanshang','0','50.00','10000.00','10000.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('4','13','29950.00','1','50.00','1455507492','61.156.219.212','1455507540','tuanshang','0','50.00','29900.00','29950.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('5','13','30000.00','1','50.00','1455507509','61.156.219.212','1455507548','tuanshang','0','50.00','29950.00','30000.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('6','13','30000.00','2','50.00','1455507519','61.156.219.212','1455507643','tuanshang','0','50.00','29950.00','30000.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('8','12','100.00','2','10.00','1455508693','61.156.219.212','1455508740','tuanshang','0','10.00','100.00','100.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('10','4','10000.00','1','10.00','1455521880','61.156.219.212','1455521972','tuanshang','恭喜您的提现申请已通过','10.00','10000.00','0.00','10000.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('11','14','100.00','2','10.00','1455523071','61.156.219.212','1455523259','tuanshang','1','10.00','100.00','99.88','0.12');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('12','15','10000.00','1','10.00','1455584552','61.156.219.212','1456213938','tuanshang','1','10.00','10000.00','10000.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('14','14','100.00','3','10.00','1455589722','61.156.219.212','1455589757','tuanshang','1','10.00','0.00','0.00','100.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('15','12','100.00','3','10.00','1455933384','61.156.219.212','1455933763','tuanshang','1','10.00','0.00','100.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('16','12','100.00','1','10.00','1455933420','61.156.219.212','1455933753','tuanshang','1','10.00','100.00','100.00','0.00');/* DBReback Separation */
 /* 插入数据 `shang_member_withdraw` */
 INSERT INTO `shang_member_withdraw` VALUES ('17','8','1000.00','2','10.00','1459476170','61.156.219.212','1459476278','tuanshang','  ','10.00','1000.00','1000.00','0.00');/* DBReback Separation */ 
 /* 数据表结构 `shang_members`*/ 
 DROP TABLE IF EXISTS `shang_members`;/* DBReback Separation */ 
 CREATE TABLE `shang_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_pass` char(32) NOT NULL,
  `user_type` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `pin_pass` char(32) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_phone` varchar(11) NOT NULL,
  `reg_time` int(10) unsigned NOT NULL,
  `reg_ip` varchar(15) NOT NULL,
  `user_leve` tinyint(4) NOT NULL DEFAULT '0',
  `time_limit` int(10) unsigned NOT NULL,
  `credits` int(10) NOT NULL,
  `recommend_id` int(10) unsigned NOT NULL DEFAULT '0',
  `customer_id` int(10) unsigned NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `province` int(10) unsigned NOT NULL,
  `city` int(10) unsigned NOT NULL,
  `area` int(10) unsigned NOT NULL,
  `is_ban` int(11) NOT NULL DEFAULT '0' COMMENT '是否冻结0：否； 1：是',
  `reward_money` decimal(15,2) NOT NULL COMMENT '奖金金额',
  `invest_credits` decimal(15,2) unsigned NOT NULL,
  `integral` int(15) NOT NULL COMMENT '会员总积分',
  `active_integral` int(15) NOT NULL COMMENT '会员活跃积分',
  `is_borrow` int(2) NOT NULL DEFAULT '1' COMMENT '是否允许会员发标。0：不允许；1：允许',
  `is_transfer` int(2) NOT NULL DEFAULT '0' COMMENT '是否是流转会员 0代表非流转会员，1代表是流转会员',
  `is_vip` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否开启特权发标，0：不开启；1：开启',
  `last_log_ip` char(15) NOT NULL,
  `last_log_time` int(10) NOT NULL DEFAULT '0',
  `recommend_time` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_email` (`user_email`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('1','18661395415','e10adc3949ba59abbe56e057f20f883e','1','670b14728ad9902aecba32e22fa4f6bd','','18661395415','1453730716','61.156.219.212','1','1487125515','30','6','113','tuanshang','0','0','0','0','0.00','0.00','6512','6512','1','1','0','61.156.219.212','1453730716','1453799897');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('2','17777777777','20917c851c4a54f2a054390dac9085b7','1','ecb97ffafc1798cd2f67fcbc37226761','','17777777777','1453768686','61.156.219.212','1','1485392111','20','4','126','kefuzhang','0','0','0','0','0.00','0.00','82017','82017','1','0','0','61.156.219.212','1453768686','1453776214');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('3','15849168711','e10adc3949ba59abbe56e057f20f883e','1','93b2489395dc262842c4093c3a76642b','test@qq.com','15849168711','1453768860','111.127.41.236','1','1485915332','30','0','126','kefuzhang','0','0','0','0','0.00','0.00','0','0','1','0','0','111.127.41.236','1453768860','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('4','18888888888','e10adc3949ba59abbe56e057f20f883e','1','670b14728ad9902aecba32e22fa4f6bd','505230646@qq.com','18888888888','1453769113','61.156.219.212','1','1485398655','40','2','126','kefuzhang','0','0','0','0','0.00','0.00','99121','99121','1','0','0','61.156.219.212','1455524061','1453771601');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('5','15024999392','93b2489395dc262842c4093c3a76642b','1','93b2489395dc262842c4093c3a76642b','','15024999392','1453789623','111.127.41.236','0','0','30','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','111.127.41.236','1453789623','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('6','15553833036','e10adc3949ba59abbe56e057f20f883e','1','670b14728ad9902aecba32e22fa4f6bd','1935672910@qq.com','15553833036','1453794334','61.156.219.212','1','1487125526','30','1','113','tuanshang','0','0','0','0','0.00','0.00','10442','10442','1','1','1','61.156.219.212','1453795751','1453794334');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('7','tankman','3e148d9cfecc7816e2f3892186a62805','1','d79ac2392145ba85a2890c1834f18558','','15754920602','1453856279','111.127.41.236','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','111.127.41.236','1453856279','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('8','15254618081','e38652e84c48c0d47f533c0ea35c9aea','1','3d48b3735c1f39a0dff901a22bbfea07','','15254618081','1453858283','61.156.219.212','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1453858283','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('9','15666472280','4297f44b13955235245b2497399d7a93','1','4297f44b13955235245b2497399d7a93','','15666472280','1453862536','61.156.219.212','1','1487468144','20','0','126','kefuzhang','0','0','0','0','0.00','0.00','120','120','1','0','0','61.156.219.212','1453862536','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('10','17853738964','e10adc3949ba59abbe56e057f20f883e','1','','','17853738964','1453873468','61.156.219.212','0','0','0','6','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1453873468','1453873468');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('11','15166272750','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','15166272750','1453897692','61.156.219.212','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','1','61.156.219.212','1453897692','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('12','17853738946','e10adc3949ba59abbe56e057f20f883e','1','96e79218965eb72c92a549dd5a330112','183282204@qq.com','17853738946','1454118836','61.156.219.212','1','1485747823','30','6','113','tuanshang','0','0','0','0','0.00','0.00','408','408','1','0','0','61.156.219.212','1455506883','1454118836');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('13','13333333333','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','13333333333','1455501805','61.156.219.212','0','0','10','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1455501805','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('14','18266479979','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','18266479979','1455514531','61.156.219.212','1','1487137373','20','12','113','tuanshang','0','0','0','0','0.00','0.00','479','479','1','0','0','61.156.219.212','1455514531','1455514531');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('15','13706360071','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','18765928038@163.com','13706360071','1455525297','61.156.219.212','1','1487149957','60','0','127','kefuwang','0','0','0','0','0.00','0.00','45','45','1','0','0','61.156.219.212','1455583161','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('16','18510287427','9c9ae265999c6c1cc6ba118ae8c05985','1','9c9ae265999c6c1cc6ba118ae8c05985','','18510287427','1455613101','58.132.175.221','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','58.132.175.221','1455613101','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('17','15155448989','e10adc3949ba59abbe56e057f20f883e','1','','','15155448989','1455941704','61.156.219.212','0','0','0','11','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1455941704','1455941704');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('18','13148437042','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','13148437042','1456745167','111.127.235.50','0','0','0','5','0','','0','0','0','0','0.00','0.00','146','146','1','0','0','111.127.235.50','1456745167','1456745167');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('19','15048363585','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','15048363585','1456795684','111.127.234.108','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','111.127.234.108','1456795684','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('20','15822623833','55aa89cf7ff1330f7791cf82c8dff5db','1','55aa89cf7ff1330f7791cf82c8dff5db','','15822623833','1457486540','61.156.219.212','1','1491359952','5020','0','126','kefuzhang','0','0','0','0','0.00','0.00','5006','5006','1','0','0','61.156.219.212','1457486540','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('21','15865463700','670b14728ad9902aecba32e22fa4f6bd','1','670b14728ad9902aecba32e22fa4f6bd','','15865463700','1457580502','61.156.219.212','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1457580502','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('22','13864760507','e10adc3949ba59abbe56e057f20f883e','1','670b14728ad9902aecba32e22fa4f6bd','','13864760507','1458182442','61.156.219.212','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1458182442','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('23','18654658738','e10adc3949ba59abbe56e057f20f883e','2','fcea920f7412b5da7be0cf42b8c93759','','18654658738','1458523595','61.156.219.212','1','1490170973','10','0','126','kefuzhang','0','0','0','0','0.00','0.00','0','0','0','1','0','61.156.219.212','1458523595','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('24','18366965783','97b7ed49f92a6a15a673b46c9c3ade06','1','5248e897de1359826603134a4a16ac68','','18366965783','1459473186','61.156.219.212','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','61.156.219.212','1459473186','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('25','15554686781','95d47be0d380a7cd3bb5bbe78e8bed49','1','4297f44b13955235245b2497399d7a93','','15554686781','1459836434','61.156.219.212','0','0','0','0','0','','0','0','0','0','0.00','0.00','300','300','1','0','0','61.156.219.212','1459836434','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('26','18264843589','95d47be0d380a7cd3bb5bbe78e8bed49','1','4297f44b13955235245b2497399d7a93','','18264843589','1459836695','61.156.219.212','1','1491373271','20','0','126','kefuzhang','0','0','0','0','0.00','0.00','300','300','1','0','0','61.156.219.212','1459836695','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('27','18206386604','e10adc3949ba59abbe56e057f20f883e','1','670b14728ad9902aecba32e22fa4f6bd','','18206386604','1460099092','61.156.219.212','0','0','0','6','0','','0','0','0','0','0.00','0.00','60','60','1','0','0','61.156.219.212','1460099092','1460099092');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('28','18222901119','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','18222901119','1460390057','114.255.40.17','0','0','0','0','0','','0','0','0','0','0.00','0.00','0','0','1','0','0','114.255.40.17','1460390057','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('29','13599260916','e10adc3949ba59abbe56e057f20f883e','1','e10adc3949ba59abbe56e057f20f883e','','13599260916','1460516522','61.156.219.212','1','1492053605','20','0','113','tuanshang','0','0','0','0','0.00','0.00','60','60','1','0','0','61.156.219.212','1460516522','0');/* DBReback Separation */
 /* 插入数据 `shang_members` */
 INSERT INTO `shang_members` VALUES ('30','13835715949','4297f44b13955235245b2497399d7a93','1','4297f44b13955235245b2497399d7a93','','13835715949','1460518960','61.156.219.212','1','1492055793','20','0','113','tuanshang','0','0','0','0','0.00','0.00','30','30','1','0','0','61.156.219.212','1460518960','0');/* DBReback Separation */ 
 /* 数据表结构 `shang_members_status`*/ 
 DROP TABLE IF EXISTS `shang_members_status`;/* DBReback Separation */ 
 CREATE TABLE `shang_members_status` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `phone_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `phone_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `id_status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0:未上传1:验证通过2:等待验证',
  `id_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `face_status` tinyint(4) NOT NULL DEFAULT '0',
  `face_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `email_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `email_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `account_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `account_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `credit_status` tinyint(4) NOT NULL DEFAULT '0',
  `credit_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `safequestion_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `safequestion_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `video_status` tinyint(4) NOT NULL DEFAULT '0',
  `video_credits` int(10) unsigned NOT NULL DEFAULT '0',
  `vip_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `vip_credits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('1','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('2','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('3','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('4','1','0','1','10','0','0','1','10','0','0','0','0','1','10','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('5','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('6','1','0','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('7','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('8','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('9','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('10','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('11','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('12','1','0','1','10','0','0','1','10','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('13','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('14','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('15','1','0','1','10','0','0','1','10','0','0','0','0','1','10','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('16','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('17','1','0','0','10','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('18','1','0','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('19','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('20','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('21','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('22','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('23','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('24','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('25','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('26','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('27','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('28','1','0','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('29','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */
 /* 插入数据 `shang_members_status` */
 INSERT INTO `shang_members_status` VALUES ('30','1','0','1','10','0','0','0','0','0','0','0','0','0','0','0','0','1','10');/* DBReback Separation */ 
 /* 数据表结构 `shang_name_apply`*/ 
 DROP TABLE IF EXISTS `shang_name_apply`;/* DBReback Separation */ 
 CREATE TABLE `shang_name_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `up_time` int(10) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `idcard` varchar(20) NOT NULL,
  `deal_info` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('1','1','1453730729','1','140212199102120010','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('2','2','1453768774','1','370481198406144259','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('3','3','1453768887','1','152124199504273010','ok');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('4','4','1453769165','1','370502199008206017','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('5','5','1453789641','1','150106555644871644','测试');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('6','6','1453794371','1','370323199110233020','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('7','7','1453856305','0','150124198707165251','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('8','8','1453858294','1','372922199012104434',' ');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('9','9','1453862593','1','370523198601243019','q');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('10','11','1453897707','0','370302199103232933','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('11','12','1454118864','1','370523199209251641','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('12','13','1455501984','1','370502199008206018','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('13','14','1455514593','1','370523199209251642','1');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('14','15','1455525458','1','342622198302076455','0');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('15','16','1455613122','0','141122199108160193','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('16','17','1455942352','0','370302199103232965','asd');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('17','19','1456810908','0','332521196902060091','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('18','20','1457486846','1','372325199711153637','mm');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('19','21','1457580517','0','370522198911260221','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('20','22','1458182576','0','37052119940612442X','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('21','23','1458523609','0','152122199103190927','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('22','24','1459473215','0','371525199209031714','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('23','25','1459836450','0','370784199202021310','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('24','26','1459836792','1','51170219740419175X','k');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('25','27','1460099178','0','372325199101220011','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('26','28','1460390107','0','130983199204054132','');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('27','29','1460530021','1','350583199503204312','23');/* DBReback Separation */
 /* 插入数据 `shang_name_apply` */
 INSERT INTO `shang_name_apply` VALUES ('28','30','1460518973','1','142602199803142512','12
');/* DBReback Separation */ 
 /* 数据表结构 `shang_navigation`*/ 
 DROP TABLE IF EXISTS `shang_navigation`;/* DBReback Separation */ 
 CREATE TABLE `shang_navigation` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(40) NOT NULL,
  `type_url` varchar(200) NOT NULL,
  `type_keyword` varchar(200) NOT NULL,
  `type_info` varchar(400) NOT NULL,
  `type_content` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `type_set` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` smallint(6) NOT NULL,
  `type_nid` varchar(50) NOT NULL,
  `is_hiden` int(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `is_sys` tinyint(3) unsigned NOT NULL,
  `model` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('1','网站首页','/index.html','','','','10','2','0','indexs','0','1386156845','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('2','我要投资','/invest/index.html','','','','9','2','0','invests','0','1386156886','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('3','我要借款','/borrow/index.html','','','','8','2','0','borrows','0','1386156927','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('5','积分商城','/market/index/','','','','6','2','0','market','1','1386157007','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('7','关于我们','/aboutus/intro.html','','','<div><img style=\"margin: 10px; width: 360px; height: 256px; float: right;\" alt=\"\" src=\"/UF/Uploads/Article/20131125183424.gif\" /> 　　XXX网站隶属于XXXXXX管理有限公司。XXXXXX经工商局登记注册于2013年成立，注册资本1000万。位于XXXXXXXXXXXXXXXXXXXXXXXXX。是目前XX地区最安全、最专业的网络信贷理财平台之一</div><div>XXXX顺应全球电子商务未来发展的趋势，充分挖掘互联网金融市场潜力，通过建立一个安全、高效、诚信、互惠互助的网络借贷平台，让人们有机会相互帮助实现双赢的结果，帮助投资者及创业者更好地应对目前世界金融危机影响下的经济困境。</div><div>我们深信，依赖现代网络创新技术将民间借贷引入的模式，定会在快捷、便利、透明的体系下得到更健康的发展，并实现利益最大化！</div><div>XXXXX严格遵守国家相关法律法规，并敦促其会员在信息发布和使用过程中严格遵守相关法规。同时，我们也将竭尽所能，不断完善对网站平台的管理！</div><div>让我们携起手来，愿您的财富同xxxx一起成长！</div><div>愿您的创业梦想，在盛世下飞翔！</div><div>&nbsp;</div><div><div><strong><span style=\"font-size: 24px;\">P2P平台介绍</span></strong></div><div>XXXXX采用创新的技术和理念，通过互联网建立一个安全、高效、诚信的平台，规范了个人之间的借贷行为，使之更加安全、有效。让人们有机会得到帮助，以及帮助到需要的朋友，同时得到更好的回报。</div><div>现实中朋友家人之间往往由于面子等问题不方便借款以及不好意思催款。XXXXX鼓励大家通过这一平台来帮助解决这些问题。另外，如果朋友家人正好没有钱帮您，而朋友的朋友很可能有闲钱，大家通过人人聚财这个平台就可传递这种信赖关系,扩大信赖的朋友圈子，解决自己的问题。</div><div>通过下面图片可以了解XXXXX如何工作的：需要钱的人发布信息，其他人以竞标方式参与，聚合大众的力量，以市场化的方式决定利率，以及监督借款行为。</div><div style=\"text-align: center;\">&nbsp;<img style=\"margin: 0px; float: none;\" alt=\"\" src=\"/UF/Uploads/Article/20131125182918.gif\" /></div><div><strong><span style=\"font-size: 24px;\">平成立目的台</span></strong></div><div>为有需要帮助的人伸出援手！为有能力的人实现资产增值！让我们成为成功路上最好的伙伴！&nbsp;</div><div>&nbsp;</div><div><strong><span style=\"font-size: 24px;\">愿景</span></strong></div><div>打造一个全民参与、安全、高效、诚信、互惠互利的互联网金融服务平台</div><div>&nbsp;</div></div>','4','2','0','about','0','1386157108','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('9','我的账户','/member/index.html','','','','2','2','0','members','1','1386157201','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('19','散标投资','/invest/index.html','','','','10','2','2','borrowing','0','1386212416','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('48','联系我们','/aboutus/contact.html','','','','0','2','7','','0','1399189875','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('46','最新动态','/news/index.html','','','','8','2','7','','0','1399189538','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('47','招贤纳士','/aboutus/invite.html','','','','7','2','7','','0','1399189583','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('45','运营团队','/aboutus/team.html','','','','10','2','7','','0','1399189491','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('41','债权转让','/debt/index','','','','7','2','2','debt','0','1389583429','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('42','积分抽奖','/market/lottery/','','','','1','2','5','choujiang','0','1389956064','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('43','积分兑换','/market/index/','','','','2','2','5','exchange','0','1389956169','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('51','优计划','/fund/index.html','','','','8','2','2','','0','1402711350','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('56','实时财务','/shishicaiwu/finanz.html','','','','5','2','0','','1','1413865697','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('57','特权金','/privilege/index','','','','0','2','0','','0','1435374372','0','navigation');/* DBReback Separation */
 /* 插入数据 `shang_navigation` */
 INSERT INTO `shang_navigation` VALUES ('60','新手专区','/novice/index','','','','0','2','2','','0','1445927333','0','navigation');/* DBReback Separation */ 
 /* 数据表结构 `shang_oauth`*/ 
 DROP TABLE IF EXISTS `shang_oauth`;/* DBReback Separation */ 
 CREATE TABLE `shang_oauth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_bind` tinyint(30) NOT NULL DEFAULT '0',
  `site` varchar(30) NOT NULL DEFAULT '',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `logintimes` int(10) unsigned NOT NULL DEFAULT '0',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `bind_uid` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `site` (`site`,`openid`),
  KEY `uname` (`is_bind`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_qq`*/ 
 DROP TABLE IF EXISTS `shang_qq`;/* DBReback Separation */ 
 CREATE TABLE `shang_qq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qq_num` varchar(50) NOT NULL,
  `qq_title` varchar(100) NOT NULL,
  `qq_order` int(2) NOT NULL,
  `is_show` int(1) NOT NULL DEFAULT '1',
  `type` int(1) NOT NULL COMMENT '0：qq号；1：qq群；2：客服电话',
  `tag` int(1) DEFAULT '1' COMMENT 'qq类型，1：普通qq，2：企业qq',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_smslog`*/ 
 DROP TABLE IF EXISTS `shang_smslog`;/* DBReback Separation */ 
 CREATE TABLE `shang_smslog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `admin_real_name` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_phone` varchar(50) NOT NULL,
  `title` varchar(20) NOT NULL,
  `content` varchar(500) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_sys_tip`*/ 
 DROP TABLE IF EXISTS `shang_sys_tip`;/* DBReback Separation */ 
 CREATE TABLE `shang_sys_tip` (
  `uid` int(10) unsigned NOT NULL,
  `tipset` varchar(300) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `tipset` (`tipset`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_today_reward`*/ 
 DROP TABLE IF EXISTS `shang_today_reward`;/* DBReback Separation */ 
 CREATE TABLE `shang_today_reward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `borrow_id` int(10) unsigned NOT NULL,
  `reward_uid` int(10) unsigned NOT NULL,
  `invest_money` decimal(15,2) unsigned NOT NULL,
  `reward_money` decimal(10,2) unsigned NOT NULL,
  `reward_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  `deal_time` int(10) NOT NULL,
  `add_ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('1','3','6','200.00','0.40','1','1453796807','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('2','6','6','1000.00','1.00','1','1453800460','1455503043','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('3','6','6','1000.00','1.00','1','1453801319','1455503043','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('4','9','6','1000.00','1.00','1','1453858848','1453858877','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('5','6','1','1.67','0.00','1','1453864718','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('6','17','12','100.00','0.10','1','1454123863','1454123888','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('7','18','12','100.00','0.15','1','1454125550','1454125568','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('8','19','6','800.00','0.80','1','1454126059','1454132032','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('9','20','6','2000.00','4.00','1','1454134166','1454134187','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('10','21','6','100.00','0.10','1','1454134605','1454134658','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('11','28','4','200.64','0.20','1','1455500636','1455503974','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('12','8','4','5000.00','10.00','1','1455515021','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('13','34','4','100000.00','150.00','1','1455515924','1455515940','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('14','35','14','200.00','0.20','1','1455517289','1455517315','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('15','36','4','500.00','1.00','2','1455518107','1455522993','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('16','38','4','100.00','0.10','1','1455519795','1455519896','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('17','38','14','400.00','0.40','1','1455519865','1455519896','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('18','4','4','1000.00','2.00','1','1455524342','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('19','43','14','400.00','0.60','1','1455586348','1455586364','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('20','44','14','200.00','0.20','1','1455587105','1455587123','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('21','10','14','200.00','0.40','1','1455591342','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('22','48','14','3.26','0.01','2','1455601388','1455691476','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('23','49','4','500.00','1.00','1','1455603544','1455603651','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('24','11','14','141.94','0.28','1','1455606156','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('25','11','12','141.94','0.28','1','1455606156','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('26','50','4','100.00','0.15','0','1455608446','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('27','52','12','200.00','0.20','1','1455676308','1455676327','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('28','53','14','200.00','0.20','1','1455677181','1455677336','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('29','54','14','300.00','0.30','1','1455677571','1455677610','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('30','55','14','307.56','0.62','1','1455677977','1455678017','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('31','56','14','100.00','0.10','1','1455678204','1455934092','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('32','50','14','300.00','0.45','0','1455678237','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('33','11','6','200.00','0.40','1','1455698097','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('34','11','6','200.00','0.40','1','1455698188','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('35','58','4','400.00','0.60','0','1456541485','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('36','26','4','200.00','0.40','0','1456541701','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('37','61','6','1500.00','3.00','1','1457337322','1457337411','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('38','62','14','808.81','1.62','1','1457337455','1457337471','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('39','63','14','300.00','0.30','1','1457339813','1457339833','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('40','64','14','200.00','0.30','1','1457340113','1457340150','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('41','65','14','200.00','0.20','1','1457342267','1457343050','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('42','66','6','1000.00','2.00','0','1457343001','0','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('43','67','14','200.00','0.20','1','1457343137','1457343154','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('44','69','4','500.00','1.00','1','1458723534','1458723787','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('45','69','4','2500.00','5.00','1','1458723634','1458723787','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('46','70','4','400.00','0.80','1','1464832905','1464832955','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_today_reward` */
 INSERT INTO `shang_today_reward` VALUES ('47','70','4','1600.00','3.20','1','1464832944','1464832955','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_tqj_config`*/ 
 DROP TABLE IF EXISTS `shang_tqj_config`;/* DBReback Separation */ 
 CREATE TABLE `shang_tqj_config` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '特权金ID',
  `name` varchar(200) CHARACTER SET utf8 NOT NULL,
  `begin_time` int(20) NOT NULL COMMENT '开始时间',
  `over_time` int(20) NOT NULL COMMENT '结束时间',
  `money` decimal(15,2) NOT NULL COMMENT '特权金额',
  `rate` int(10) NOT NULL COMMENT '年利率',
  `biggest` int(10) NOT NULL COMMENT '最大领取次数',
  `status_approve` varchar(100) NOT NULL COMMENT '领取条件—认证',
  `status_due_money` decimal(15,2) DEFAULT NULL COMMENT '领取条件—待收本金',
  `isopen` int(10) NOT NULL COMMENT '是否开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('1','红包','1453737600','1453996799','1000.00','10','10','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('2','大红包11','1453651200','1453910399','1000.00','10','5','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('3','新手必备','1453737600','1454255999','50000.00','8','30','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('4','发红包','1453824000','1453996799','2000.00','10','1','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('5','发放特权金','1454083200','1454255999','100.00','12','30','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('6','发放利息','1454083200','1454342399','1000.00','12','30','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('7','红包派送','1455465600','1456761599','50000.00','10','60','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('8','红包大派送','1455465600','1455724799','200.00','10','3','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('9','发奖励','1455638400','1455897599','300.00','12','3','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('10','发奖励','1457280000','1457625599','300.00','10','4','0-1','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_tqj_config` */
 INSERT INTO `shang_tqj_config` VALUES ('11','大红包','1457280000','1460735999','2000.00','10','2','0-1','0.00','0');/* DBReback Separation */ 
 /* 数据表结构 `shang_tqj_log`*/ 
 DROP TABLE IF EXISTS `shang_tqj_log`;/* DBReback Separation */ 
 CREATE TABLE `shang_tqj_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `tqj_id` int(10) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 NOT NULL,
  `earnings` decimal(15,2) NOT NULL COMMENT '收益',
  `get_time` int(10) NOT NULL COMMENT '领取时间',
  `tqj_money` decimal(15,2) NOT NULL COMMENT '特权金额',
  `tqj_rate` int(10) NOT NULL COMMENT '利率',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;/* DBReback Separation */ 
 /* 数据表结构 `shang_tqj_user`*/ 
 DROP TABLE IF EXISTS `shang_tqj_user`;/* DBReback Separation */ 
 CREATE TABLE `shang_tqj_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tqj_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `get_time` int(10) NOT NULL COMMENT '领取时间',
  `tqj_money` decimal(15,2) NOT NULL COMMENT '特权金',
  `tqj_rate` int(10) NOT NULL COMMENT '利率',
  `status` int(10) NOT NULL COMMENT '状态 2-结束 1-进行中',
  `get_the_number` int(10) NOT NULL COMMENT '领取次数',
  `actual_the_number` int(10) DEFAULT '0' COMMENT '实际领取次数',
  `affect_money` decimal(15,2) NOT NULL COMMENT '用户每天的收益',
  `title` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '特权金标题',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('1','2','6','1453795853','1000.00','10','1','5','0','0.27','大红包11');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('2','1','4','1453796810','1000.00','10','1','10','0','0.27','红包');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('3','2','4','1453796815','1000.00','10','1','5','0','0.27','大红包11');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('4','3','4','1453797489','50000.00','8','1','30','0','10.96','新手必备');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('5','1','6','1453856809','1000.00','10','1','10','0','0.27','红包');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('6','4','6','1453858284','2000.00','10','1','1','0','0.55','发红包');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('7','3','6','1453865451','50000.00','8','1','30','0','10.96','新手必备');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('8','4','4','1453882728','2000.00','10','1','1','0','0.55','发红包');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('9','5','12','1454122807','100.00','12','1','30','0','0.03','发放特权金');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('10','6','12','1454135705','1000.00','12','1','30','0','0.33','发放利息');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('11','7','4','1455505686','50000.00','10','1','60','0','13.70','红包派送');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('12','8','12','1455517989','200.00','10','1','3','0','0.05','红包大派送');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('13','7','12','1455518091','50000.00','10','1','60','0','13.70','红包派送');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('14','7','15','1455586955','50000.00','10','1','60','0','13.70','红包派送');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('15','7','14','1455608834','50000.00','10','1','60','0','13.70','红包派送');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('16','8','14','1455673243','200.00','10','1','3','0','0.05','红包大派送');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('17','9','14','1455673629','300.00','12','1','3','0','0.10','发奖励');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('18','11','6','1457337092','2000.00','10','1','2','0','0.55','大红包');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('19','10','14','1457338245','300.00','10','1','4','0','0.08','发奖励');/* DBReback Separation */
 /* 插入数据 `shang_tqj_user` */
 INSERT INTO `shang_tqj_user` VALUES ('20','11','14','1457341786','2000.00','10','1','2','0','0.55','大红包');/* DBReback Separation */ 
 /* 数据表结构 `shang_transfer_borrow_info`*/ 
 DROP TABLE IF EXISTS `shang_transfer_borrow_info`;/* DBReback Separation */ 
 CREATE TABLE `shang_transfer_borrow_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `borrow_name` varchar(50) NOT NULL,
  `borrow_uid` int(11) NOT NULL,
  `borrow_duration` tinyint(3) unsigned NOT NULL,
  `borrow_money` decimal(15,2) NOT NULL,
  `borrow_interest` decimal(15,2) NOT NULL,
  `borrow_interest_rate` decimal(5,2) NOT NULL,
  `repayment_money` decimal(15,2) NOT NULL,
  `repayment_interest` decimal(15,2) NOT NULL,
  `repayment_type` tinyint(3) unsigned NOT NULL,
  `borrow_status` tinyint(3) unsigned NOT NULL,
  `transfer_out` int(10) NOT NULL,
  `transfer_back` int(10) unsigned NOT NULL,
  `transfer_total` int(10) NOT NULL,
  `per_transfer` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(500) NOT NULL,
  `borrow_info` varchar(2000) NOT NULL,
  `ensure_department` varchar(10) NOT NULL,
  `updata` varchar(2000) NOT NULL,
  `progress` tinyint(3) unsigned NOT NULL,
  `total` tinyint(4) NOT NULL,
  `is_show` tinyint(4) NOT NULL DEFAULT '1',
  `min_month` tinyint(4) NOT NULL DEFAULT '0',
  `reward_rate` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '网站奖励(每月)',
  `increase_rate` float(5,2) NOT NULL DEFAULT '0.00' COMMENT '每月增加年利率',
  `borrow_fee` decimal(15,2) NOT NULL COMMENT '借款管理费',
  `level_can` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0:允许普通会员投标；1:只允许VIP投标',
  `borrow_min` int(11) NOT NULL COMMENT '最低投标额度',
  `borrow_max` int(11) NOT NULL COMMENT '最高投标额度',
  `danbao` decimal(15,2) NOT NULL COMMENT '担保机构',
  `is_tuijian` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否设为推荐标 0表示不推荐；1表示推荐',
  `borrow_type` int(11) NOT NULL DEFAULT '6' COMMENT '刘',
  `b_img` varchar(200) NOT NULL COMMENT '流转标展示图片',
  `collect_day` int(10) NOT NULL COMMENT '允许投标的期限',
  `is_auto` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否允许自动投标 0：否；1：是。',
  `is_jijin` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否是定投宝 0：企业直投；1：定投宝',
  `online_time` int(10) NOT NULL DEFAULT '0' COMMENT '上线时间',
  `on_off` tinyint(2) NOT NULL COMMENT '是否显示 0：显示；1：不显示',
  PRIMARY KEY (`id`),
  KEY `borrow_uid` (`borrow_uid`,`borrow_status`) USING BTREE,
  KEY `borrow_status` (`is_show`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('1','U-00000001','1','6','30000.00','0.00','12.00','0.00','0.00','0','2','0','0','300','100','1453731109','1469283109','61.156.219.212','0','0','','','','N;','0','6','1','6','0.00','0.00','0.00','0','0','0','157.00','0','6','','0','0','1','1453731098','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('2','U-00000002','1','3','20000.00','0.00','10.00','0.00','0.00','0','2','1','0','200','100','1453796473','1461572473','61.156.219.212','0','0','','','','N;','1','3','1','3','0.00','0.00','0.00','0','0','0','0.00','0','6','','0','0','1','1453796497','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('3','U-00000003','1','3','30000.00','0.00','10.00','0.00','0.00','0','2','2','0','300','100','1453796807','1461572807','61.156.219.212','0','0','','','','N;','1','3','1','3','0.00','0.00','0.00','0','0','0','0.00','0','6','','0','0','1','1453796858','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('4','U-00000004','6','3','2000.00','0.00','10.00','0.00','0.00','0','2','20','0','20','100','1453797629','1461573629','61.156.219.212','0','0','','','','N;','100','3','0','3','0.00','0.00','10.00','0','0','0','157.00','0','6','','0','0','1','1453884065','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('5','U-00000005','1','1','10000.00','0.00','10.00','0.00','0.00','0','7','10','10','10','1000','1453864138','1456456138','61.156.219.212','0','0','','','','N;','100','1','0','1','0.00','0.00','0.00','0','0','0','157.00','0','6','','0','0','1','1453864117','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('6','U-00000006','6','3','50000.00','0.00','17.00','0.00','0.00','0','2','3','0','100','500','1453864718','1461640718','61.156.219.212','0','0','','','','N;','3','3','1','3','0.00','0.00','10.00','0','0','5','157.00','0','6','','0','0','1','1453875368','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('7','U-00000007','1','6','100000.00','0.00','8.00','0.00','0.00','0','2','0','0','200','500','1454140965','1469692965','222.173.174.202','0','0','','','','N;','0','6','1','6','0.00','0.00','5000.00','0','0','0','157.00','0','6','','0','0','1','1454140623','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('8','U-00000008','1','3','10000.00','0.00','10.00','0.00','0.00','5','2','10','0','10','1000','1455514909','1463290909','61.156.219.212','0','0','','','','N;','100','3','0','3','0.00','0.00','0.00','0','0','0','157.00','0','6','','0','0','1','1455515002','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('9','U-00000009','1','1','2000.00','0.00','12.00','0.00','0.00','0','2','10','0','10','200','1455590854','1458182854','61.156.219.212','0','0','','','','N;','100','1','0','1','0.00','0.00','20.00','0','0','5','157.00','0','6','','0','0','1','1455590801','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('10','U-00000010','1','3','1000.00','0.00','12.00','0.00','0.00','0','2','2','0','5','200','1455591342','1463367342','61.156.219.212','0','0','','','','N;','40','3','1','3','0.00','0.00','25.00','0','0','5','157.00','0','6','','0','0','1','1455591294','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('11','U-00000011','1','6','4000.00','0.00','11.00','0.00','0.00','0','2','5','0','20','200','1455606156','1471158156','61.156.219.212','0','0','','','','N;','25','6','1','6','0.00','0.00','0.00','0','0','0','157.00','0','6','','0','0','1','1455606131','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('12','U-00000012','6','3','2000.00','0.00','10.00','0.00','0.00','0','2','3','0','20','100','1455760346','1463536346','61.156.219.212','0','0','','','','N;','15','3','1','3','0.00','0.00','0.00','0','0','0','0.00','0','6','','0','0','1','1455760308','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('13','U-00000013','6','6','1000.00','0.00','10.00','0.00','0.00','0','2','0','0','10','100','1456281451','1471833451','61.156.219.212','0','0','','','','N;','0','6','1','6','0.00','0.00','0.00','0','0','0','0.00','0','6','','0','0','1','1456299413','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('14','U-00000014','23','24','1000.00','0.00','10.00','0.00','0.00','0','2','2','0','10','100','1459481608','1521689608','61.156.219.212','0','0','','','','N;','20','24','1','24','0.00','0.00','0.00','0','0','0','0.00','0','6','','0','0','1','1459481603','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('15','U-00000015','23','1','2000.00','0.00','10.00','0.00','0.00','0','2','20','0','20','100','1460099266','1462691266','61.156.219.212','0','0','','','','N;','100','1','0','1','0.00','0.00','0.00','0','0','0','0.00','0','6','','0','0','1','1460099313','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info` */
 INSERT INTO `shang_transfer_borrow_info` VALUES ('16','U-00000016','1','3','15144129.00','0.00','10.00','0.00','0.00','0','2','0','0','123123','123','1460528920','1468304920','61.156.219.212','0','0','','','','N;','0','3','1','3','0.00','0.00','123123.00','0','0','0','157.00','0','6','','0','0','1','1460539676','1');/* DBReback Separation */ 
 /* 数据表结构 `shang_transfer_borrow_info_lock`*/ 
 DROP TABLE IF EXISTS `shang_transfer_borrow_info_lock`;/* DBReback Separation */ 
 CREATE TABLE `shang_transfer_borrow_info_lock` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `suo` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('1','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('2','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('3','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('4','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('5','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('6','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('7','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('8','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('9','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('10','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('11','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('12','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('13','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('14','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('15','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_info_lock` */
 INSERT INTO `shang_transfer_borrow_info_lock` VALUES ('16','0');/* DBReback Separation */ 
 /* 数据表结构 `shang_transfer_borrow_investor`*/ 
 DROP TABLE IF EXISTS `shang_transfer_borrow_investor`;/* DBReback Separation */ 
 CREATE TABLE `shang_transfer_borrow_investor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(11) NOT NULL,
  `investor_capital` decimal(15,2) NOT NULL,
  `investor_interest` decimal(15,2) NOT NULL,
  `invest_fee` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL,
  `receive_interest` decimal(15,2) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `is_auto` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reward_money` decimal(15,2) NOT NULL,
  `transfer_num` int(10) unsigned NOT NULL DEFAULT '0',
  `transfer_month` int(10) unsigned NOT NULL DEFAULT '0',
  `back_time` int(10) unsigned NOT NULL,
  `final_interest_rate` float(5,2) NOT NULL DEFAULT '0.00',
  `is_jijin` tinyint(3) NOT NULL COMMENT '是否定投保：1：定投宝；0：直投',
  PRIMARY KEY (`id`),
  KEY `investor_uid` (`investor_uid`,`status`) USING BTREE,
  KEY `borrow_id` (`borrow_id`,`investor_uid`,`status`) USING BTREE,
  KEY `deadline` (`deadline`,`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('1','1','2','6','1','100.00','2.49','1.71','0.00','0.26','1453796549','1461572549','0','0.00','1','3','1456470753','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('2','1','3','6','1','200.00','5.00','3.40','0.00','0.00','1453796807','1461572807','1','0.00','2','3','0','10.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('3','1','4','1','6','300.00','7.50','5.10','0.00','0.00','1453797629','1461573629','1','0.00','3','3','0','10.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('4','2','5','4','1','10000.00','83.33','56.66','10000.00','26.67','1453864198','1456456198','0','0.00','10','1','1456470753','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('5','1','6','1','6','1000.00','42.50','28.90','0.00','0.00','1453864718','1461640718','1','0.00','2','3','0','17.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('6','1','4','4','6','100.00','2.49','1.71','0.00','0.00','1455500673','1463276673','0','0.00','1','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('7','1','4','4','6','100.00','2.49','1.71','0.00','0.00','1455500701','1463276701','0','0.00','1','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('8','1','8','4','1','5000.00','125.01','84.99','0.00','0.00','1455515021','1463291021','0','0.00','5','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('9','1','8','2','1','5000.00','125.01','84.99','0.00','0.00','1455515231','1463291231','0','0.00','5','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('10','1','4','4','6','1000.00','24.99','17.01','0.00','0.00','1455524342','1463300342','0','0.00','10','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('11','1','4','15','6','500.00','12.60','8.57','0.00','0.00','1455527119','1463303119','0','0.00','5','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('12','1','9','12','1','200.00','2.00','1.36','0.00','0.00','1455590854','1458182854','1','0.00','1','1','0','12.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('13','1','9','14','1','400.00','4.00','2.72','0.00','0.00','1455590951','1458182951','0','0.00','2','1','0','12.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('14','1','10','12','1','200.00','6.00','4.08','0.00','0.00','1455591342','1463367342','1','0.00','1','3','0','12.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('15','1','10','14','1','200.00','6.00','4.08','0.00','0.00','1455591342','1463367342','1','0.00','1','3','0','12.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('16','1','11','14','1','400.00','22.00','14.96','0.00','0.00','1455606156','1471158156','1','0.00','2','6','0','11.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('17','1','11','12','1','200.00','11.00','7.48','0.00','0.00','1455606156','1471158156','1','0.00','1','6','0','11.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('18','1','11','6','1','200.00','11.26','7.66','0.00','0.00','1455698097','1471250097','0','0.00','1','6','0','11.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('19','1','11','6','1','200.00','11.26','7.66','0.00','0.00','1455698188','1471250188','0','0.00','1','6','0','11.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('20','1','12','12','6','200.00','5.00','3.40','0.00','0.00','1455760346','1463536346','1','0.00','2','3','0','10.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('21','1','14','18','23','200.00','40.08','27.12','0.00','0.00','1459481927','1521689927','0','0.00','2','24','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('22','1','9','20','1','200.00','2.00','1.36','0.00','0.00','1459822724','1462414724','0','0.00','1','1','0','12.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('23','1','15','27','23','2000.00','16.67','11.33','0.00','0.00','1460099337','1462691337','0','0.00','20','1','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('24','1','9','29','1','200.00','2.00','1.36','0.00','0.00','1460517750','1463109750','0','0.00','1','1','0','12.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('25','1','12','29','6','100.00','2.49','1.71','0.00','0.00','1460519267','1468295267','0','0.00','1','3','0','10.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('26','1','9','30','1','1000.00','10.00','6.80','0.00','0.00','1460528950','1463120950','0','0.00','5','1','0','12.00','1');/* DBReback Separation */
 /* 插入数据 `shang_transfer_borrow_investor` */
 INSERT INTO `shang_transfer_borrow_investor` VALUES ('27','1','6','29','6','500.00','21.24','14.46','0.00','0.00','1460530506','1468306506','0','0.00','1','3','0','17.00','1');/* DBReback Separation */ 
 /* 数据表结构 `shang_transfer_detail`*/ 
 DROP TABLE IF EXISTS `shang_transfer_detail`;/* DBReback Separation */ 
 CREATE TABLE `shang_transfer_detail` (
  `borrow_id` int(10) unsigned NOT NULL,
  `borrow_breif` varchar(2000) NOT NULL,
  `borrow_capital` varchar(2000) NOT NULL,
  `borrow_use` varchar(2000) NOT NULL,
  `borrow_risk` varchar(2000) NOT NULL,
  `borrow_guarantee` varchar(50) NOT NULL,
  `borrow_img` varchar(2000) NOT NULL,
  PRIMARY KEY (`borrow_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('1','123','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('2','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('3','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('4','生活周转','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('5','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('6','生意周转','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('7','111111111111111111','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('8','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('9','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('10','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('11','1','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('12','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('13','','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('14','','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('15','0','','','','','N;');/* DBReback Separation */
 /* 插入数据 `shang_transfer_detail` */
 INSERT INTO `shang_transfer_detail` VALUES ('16','123','','','','','N;');/* DBReback Separation */ 
 /* 数据表结构 `shang_transfer_investor_detail`*/ 
 DROP TABLE IF EXISTS `shang_transfer_investor_detail`;/* DBReback Separation */ 
 CREATE TABLE `shang_transfer_investor_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `repayment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `borrow_id` int(10) unsigned NOT NULL,
  `invest_id` int(10) unsigned NOT NULL,
  `investor_uid` int(10) unsigned NOT NULL,
  `borrow_uid` int(10) unsigned NOT NULL,
  `capital` decimal(15,2) NOT NULL,
  `interest` decimal(15,2) NOT NULL,
  `interest_fee` decimal(15,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `receive_interest` decimal(15,2) NOT NULL,
  `receive_capital` decimal(15,2) NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL,
  `total` tinyint(3) unsigned NOT NULL,
  `deadline` int(10) unsigned NOT NULL,
  `expired_money` decimal(15,2) NOT NULL,
  `expired_days` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `call_fee` decimal(5,2) NOT NULL,
  `substitute_money` decimal(15,2) NOT NULL,
  `substitute_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `invest_id` (`invest_id`,`status`,`deadline`) USING BTREE,
  KEY `borrow_id` (`borrow_id`,`sort_order`,`investor_uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('1','1456470753','2','1','6','1','0.00','0.83','0.57','1','0.26','0.00','1','3','1456388549','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('2','0','2','1','6','1','0.00','0.83','0.57','7','0.00','0.00','2','3','1458980549','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('3','0','2','1','6','1','100.00','0.83','0.57','7','0.00','0.00','3','3','1461572549','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('4','0','3','2','6','1','200.00','5.00','3.40','7','0.00','0.00','1','1','1461572807','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('5','0','4','3','1','6','300.00','7.50','5.10','7','0.00','0.00','1','1','1461573629','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('6','1456470753','5','4','4','1','10000.00','83.33','56.66','1','26.67','10000.00','1','1','1456456198','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('7','0','6','5','1','6','1000.00','42.50','28.90','7','0.00','0.00','1','1','1461640718','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('8','0','4','6','4','6','0.00','0.83','0.57','7','0.00','0.00','1','3','1458092673','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('9','0','4','6','4','6','0.00','0.83','0.57','7','0.00','0.00','2','3','1460684673','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('10','0','4','6','4','6','100.00','0.83','0.57','7','0.00','0.00','3','3','1463276673','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('11','0','4','7','4','6','0.00','0.83','0.57','7','0.00','0.00','1','3','1458092701','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('12','0','4','7','4','6','0.00','0.83','0.57','7','0.00','0.00','2','3','1460684701','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('13','0','4','7','4','6','100.00','0.83','0.57','7','0.00','0.00','3','3','1463276701','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('14','0','8','8','4','1','0.00','41.67','28.33','7','0.00','0.00','1','3','1458107021','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('15','0','8','8','4','1','0.00','41.67','28.33','7','0.00','0.00','2','3','1460699021','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('16','0','8','8','4','1','5000.00','41.67','28.33','7','0.00','0.00','3','3','1463291021','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('17','0','8','9','2','1','0.00','41.67','28.33','7','0.00','0.00','1','3','1458107231','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('18','0','8','9','2','1','0.00','41.67','28.33','7','0.00','0.00','2','3','1460699231','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('19','0','8','9','2','1','5000.00','41.67','28.33','7','0.00','0.00','3','3','1463291231','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('20','0','4','10','4','6','0.00','8.33','5.67','7','0.00','0.00','1','3','1458116342','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('21','0','4','10','4','6','0.00','8.33','5.67','7','0.00','0.00','2','3','1460708342','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('22','0','4','10','4','6','1000.00','8.33','5.67','7','0.00','0.00','3','3','1463300342','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('23','0','4','11','15','6','500.00','12.60','8.57','7','0.00','0.00','1','1','1463303119','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('24','0','9','12','12','1','200.00','2.00','1.36','7','0.00','0.00','1','1','1458182854','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('25','0','9','13','14','1','400.00','4.00','2.72','7','0.00','0.00','1','1','1458182951','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('26','0','10','14','12','1','200.00','6.00','4.08','7','0.00','0.00','1','1','1463367342','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('27','0','10','15','14','1','200.00','6.00','4.08','7','0.00','0.00','1','1','1463367342','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('28','0','11','16','14','1','400.00','22.00','14.96','7','0.00','0.00','1','1','1471158156','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('29','0','11','17','12','1','200.00','11.00','7.48','7','0.00','0.00','1','1','1471158156','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('30','0','11','18','6','1','200.00','11.26','7.66','7','0.00','0.00','1','1','1471250097','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('31','0','11','19','6','1','200.00','11.26','7.66','7','0.00','0.00','1','1','1471250188','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('32','0','12','20','12','6','200.00','5.00','3.40','7','0.00','0.00','1','1','1463536346','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('33','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','1','24','1462073927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('34','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','2','24','1464665927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('35','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','3','24','1467257927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('36','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','4','24','1469849927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('37','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','5','24','1472441927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('38','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','6','24','1475033927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('39','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','7','24','1477625927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('40','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','8','24','1480217927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('41','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','9','24','1482809927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('42','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','10','24','1485401927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('43','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','11','24','1487993927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('44','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','12','24','1490585927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('45','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','13','24','1493177927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('46','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','14','24','1495769927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('47','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','15','24','1498361927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('48','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','16','24','1500953927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('49','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','17','24','1503545927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('50','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','18','24','1506137927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('51','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','19','24','1508729927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('52','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','20','24','1511321927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('53','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','21','24','1513913927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('54','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','22','24','1516505927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('55','0','14','21','18','23','0.00','1.67','1.13','7','0.00','0.00','23','24','1519097927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('56','0','14','21','18','23','200.00','1.67','1.13','7','0.00','0.00','24','24','1521689927','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('57','0','9','22','20','1','200.00','2.00','1.36','7','0.00','0.00','1','1','1462414724','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('58','0','15','23','27','23','2000.00','16.67','11.33','7','0.00','0.00','1','1','1462691337','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('59','0','9','24','29','1','200.00','2.00','1.36','7','0.00','0.00','1','1','1463109750','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('60','0','12','25','29','6','0.00','0.83','0.57','7','0.00','0.00','1','3','1463111267','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('61','0','12','25','29','6','0.00','0.83','0.57','7','0.00','0.00','2','3','1465703267','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('62','0','12','25','29','6','100.00','0.83','0.57','7','0.00','0.00','3','3','1468295267','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('63','0','9','26','30','1','1000.00','10.00','6.80','7','0.00','0.00','1','1','1463120950','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('64','0','6','27','29','6','0.00','7.08','4.82','7','0.00','0.00','1','3','1463122506','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('65','0','6','27','29','6','0.00','7.08','4.82','7','0.00','0.00','2','3','1465714506','0.00','0','0.00','0.00','0');/* DBReback Separation */
 /* 插入数据 `shang_transfer_investor_detail` */
 INSERT INTO `shang_transfer_investor_detail` VALUES ('66','0','6','27','29','6','500.00','7.08','4.82','7','0.00','0.00','3','3','1468306506','0.00','0','0.00','0.00','0');/* DBReback Separation */ 
 /* 数据表结构 `shang_user_email_log`*/ 
 DROP TABLE IF EXISTS `shang_user_email_log`;/* DBReback Separation */ 
 CREATE TABLE `shang_user_email_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `send_email` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `email_title` varchar(250) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `msg` text,
  `addtime` varchar(32) DEFAULT NULL,
  `addip` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('1','6','86526909@qq.com','1935672910@qq.com','注册邮箱确认','1','尊敬的\'15553833036\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=jgByjjCdVMpGdttwJDJvagtCakXGsdLF\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1453795753','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('2','12','86526909@qq.com','183282204@qq.com','注册邮箱确认','1','尊敬的\'17853738946\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=mzhweGGfgFTFSlbLWVTsvkEYIpTAmGFQ\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455506859','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('3','12','86526909@qq.com','183282204@qq.com','注册邮箱确认','1','尊敬的\'17853738946\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=dCsiUtWNsTFbEiAnlqEKifJKvzvaJSrV\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455506884','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('4','4','86526909@qq.com','5@qq.com','注册邮箱确认','1','尊敬的\'13706360071\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=gyngbyHxEiMLthXkeIGePsIxRVZwAAzO\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455524031','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('5','4','86526909@qq.com','5@qq.com','注册邮箱确认','1','尊敬的\'13706360071\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=AvxSLNtWbCOZWeeVSsKgMkosGhCPZoaw\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455524042','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('6','4','86526909@qq.com','505230646@qq.com','注册邮箱确认','1','尊敬的\'13706360071\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=bZizuKmOdQmfavPPWXRCGhxecAwZyisA\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455524062','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('7','15','86526909@qq.com','555555555@qq.com','注册邮箱确认','1','尊敬的\'13706360071\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=xouGtutwSIhzOaMJaBkSYWedsgmSfVKI\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455583131','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_user_email_log` */
 INSERT INTO `shang_user_email_log` VALUES ('8','15','86526909@qq.com','18765928038@163.com','注册邮箱确认','1','尊敬的\'13706360071\'您好！<br>恭喜您注册成功,请点击下面的链接即可完成激活<a href=\"http://v5.petope.com/member/common/emailverify?vcode=gqDhmzlysrAXmxvDdRWCVpLDUHxLVhCo\">点击链接验证邮件</a><br><div style=\"text-align:right\">客服中心</div>','1455583162','61.156.219.212');/* DBReback Separation */ 
 /* 数据表结构 `shang_verify`*/ 
 DROP TABLE IF EXISTS `shang_verify`;/* DBReback Separation */ 
 CREATE TABLE `shang_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `send_time` int(10) NOT NULL,
  `ukey` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL COMMENT '1:邮件激活验证',
  PRIMARY KEY (`id`),
  KEY `code` (`ukey`,`type`,`send_time`,`code`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('1','jgByjjCdVMpGdttwJDJvagtCakXGsdLF','1453795751','6','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('2','269514','1455505264','4','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('3','076826','1455505350','4','5');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('4','606359','1455505488','4','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('5','818616','1455505514','4','5');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('6','mzhweGGfgFTFSlbLWVTsvkEYIpTAmGFQ','1455506858','12','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('7','dCsiUtWNsTFbEiAnlqEKifJKvzvaJSrV','1455506883','12','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('8','gyngbyHxEiMLthXkeIGePsIxRVZwAAzO','1455524030','4','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('9','AvxSLNtWbCOZWeeVSsKgMkosGhCPZoaw','1455524041','4','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('10','bZizuKmOdQmfavPPWXRCGhxecAwZyisA','1455524061','4','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('11','832513','1455525111','4','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('12','346759','1455525141','4','5');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('13','037427','1455525163','4','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('14','590527','1455525192','4','5');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('15','xouGtutwSIhzOaMJaBkSYWedsgmSfVKI','1455583130','15','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('16','gqDhmzlysrAXmxvDdRWCVpLDUHxLVhCo','1455583161','15','1');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('17','304196','1455673990','6','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('18','098428','1455675593','6','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('19','579795','1455675617','6','5');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('20','593986','1455675683','6','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('21','708385','1455675715','6','5');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('22','860912','1459824037','20','4');/* DBReback Separation */
 /* 插入数据 `shang_verify` */
 INSERT INTO `shang_verify` VALUES ('23','232891','1459837361','26','4');/* DBReback Separation */ 
 /* 数据表结构 `shang_video_apply`*/ 
 DROP TABLE IF EXISTS `shang_video_apply`;/* DBReback Separation */ 
 CREATE TABLE `shang_video_apply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  `add_ip` varchar(16) NOT NULL,
  `apply_status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `credits` int(11) NOT NULL DEFAULT '0',
  `deal_user` int(10) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_info` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* DBReback Separation */ 
 /* 数据表结构 `shang_vip_apply`*/ 
 DROP TABLE IF EXISTS `shang_vip_apply`;/* DBReback Separation */ 
 CREATE TABLE `shang_vip_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `kfid` int(10) unsigned NOT NULL,
  `province_now` int(10) unsigned NOT NULL,
  `city_now` int(11) NOT NULL,
  `area_now` int(11) NOT NULL,
  `des` varchar(1000) NOT NULL,
  `add_time` int(10) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `deal_time` int(10) unsigned NOT NULL,
  `deal_user` int(10) unsigned NOT NULL,
  `deal_info` varchar(200) NOT NULL COMMENT '处理意见',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('1','2','126','0','0','0','我要vip,谢谢','1453769695','1','1453769711','113','好');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('2','4','126','0','0','0','0','1453776234','1','1453776255','113','0');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('3','12','113','0','0','0','0','1454125405','1','1454125423','113','0');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('4','3','126','0','0','0','2222','1454292902','1','1454292931','113','ok');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('5','6','113','0','0','0','0','1455502703','1','1455503125','113','0');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('6','1','113','0','0','0','0','1455503070','1','1455503115','113','0');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('7','14','113','0','0','0','1','1455514952','1','1455514972','113','1');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('8','15','127','0','0','0','我要借款,需要vip,望审核通过,谢谢.','1455527318','1','1455527557','113','看你这么诚恳就给你通过了');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('9','11','113','0','0','0','0','1455672344','0','0','0','');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('10','9','126','0','0','0','1','1455845491','1','1455845744','113','1');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('11','23','126','0','0','0','1','1458634965','1','1458634972','113','1');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('12','20','126','0','0','0','mm','1459823926','1','1459823951','113','mm');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('13','26','126','0','0','0','shide','1459837247','1','1459837270','113','jj');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('14','29','113','0','0','0','123','1460517560','1','1460517605','113','123');/* DBReback Separation */
 /* 插入数据 `shang_vip_apply` */
 INSERT INTO `shang_vip_apply` VALUES ('15','30','113','0','0','0','111111','1460519769','1','1460519793','113','123');/* DBReback Separation */ 
 /* 数据表结构 `shang_wap_bank`*/ 
 DROP TABLE IF EXISTS `shang_wap_bank`;/* DBReback Separation */ 
 CREATE TABLE `shang_wap_bank` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `acc_no` varchar(20) NOT NULL,
  `id_card` varchar(30) NOT NULL,
  `id_holder` varchar(2000) CHARACTER SET utf8 NOT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `pay_code` varchar(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  `is_charge` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;/* DBReback Separation */ 
 /* 数据表结构 `shang_xbo_smslog`*/ 
 DROP TABLE IF EXISTS `shang_xbo_smslog`;/* DBReback Separation */ 
 CREATE TABLE `shang_xbo_smslog` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `to_user_id` mediumint(8) unsigned DEFAULT NULL,
  `to_user_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_phone` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `addtime` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addtime_des` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `back_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `back_status_des` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `add_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=400 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('1','','','18661395415','您的验证码为624028【尚贷系统】','1453730684','2016-01-25=22-04-44','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('2','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1453730960','2016-01-25=22-09-20','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('3','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1453731070','2016-01-25=22-11-10','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('4','','','13706360071','您的验证码为6037【尚贷系统】','1453768444','2016-01-26=08-34-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('5','','','17777777777','您的验证码为658278【尚贷系统】','1453768665','2016-01-26=08-37-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('6','','','15849168711','您的验证码为403278【尚贷系统】','1453768842','2016-01-26=08-40-42','0','漫道短信接口','111.127.41.236');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('7','','','13706360071','您的验证码为671834【尚贷系统】','1453769094','2016-01-26=08-44-54','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('8','2','17777777777','17777777777','17777777777您好，您2016-01-26 08:53:04线下充值的100000.00元已到帐【尚贷系统】','1453769655','2016-01-26=08-54-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('9','4','13706360071','13706360071','13706360071您好，您2016-01-26 08:46:46线下充值的1000000.00元已到帐【尚贷系统】','1453769660','2016-01-26=08-54-20','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('10','2','17777777777','17777777777','17777777777您好，您2016-01-26 08:42:14线下充值的10000000.00元已到帐【尚贷系统】','1453769665','2016-01-26=08-54-25','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('11','2','17777777777','17777777777','17777777777，您的VIP认证已经通过【尚贷系统】','1453769711','2016-01-26=08-55-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('12','2','17777777777','17777777777','17777777777，您发布的借款已经通过初审【尚贷系统】','1453770323','2016-01-26=09-05-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('13','4','13706360071','13706360071','13706360071，您的VIP认证已经通过【尚贷系统】','1453776255','2016-01-26=10-44-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('14','','','15024999392','您的验证码为092337【尚贷系统】','1453789581','2016-01-26=14-26-21','0','漫道短信接口','111.127.41.236');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('15','1','18661395415','18661395415','18661395415您好，您2016-01-26 15:41:10在线充值的10000.00元已到帐【尚贷系统】','1453794094','2016-01-26=15-41-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('16','','','15553833036','您的验证码为765027【尚贷系统】','1453794310','2016-01-26=15-45-10','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('17','6','15553833036','15553833036','15553833036，您投标的第3号借款已经通过复审,现在开始计息【尚贷系统】','1453794711','2016-01-26=15-51-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('18','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1453794711','2016-01-26=15-51-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('19','6','15553833036','15553833036','您2016-01-26 15:50:41投资的第3号标第1期的还款已到帐,到账金额是12392.8元【尚贷系统】','1453794890','2016-01-26=15-54-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('20','6','15553833036','15553833036','您2016-01-26 15:50:41投资的第3号标第2期的还款已到帐,到账金额是12392.81元【尚贷系统】','1453794891','2016-01-26=15-54-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('21','6','15553833036','15553833036','您2016-01-26 15:50:41投资的第3号标第3期的还款已到帐,到账金额是12392.8元【尚贷系统】','1453794892','2016-01-26=15-54-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('22','6','15553833036','15553833036','您2016-01-26 15:50:41投资的第3号标第4期的还款已到帐,到账金额是12392.8元【尚贷系统】','1453795041','2016-01-26=15-57-21','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('23','6','15553833036','15553833036','您2016-01-26 15:50:41投资的第3号标第5期的还款已到帐,到账金额是12392.8元【尚贷系统】','1453795042','2016-01-26=15-57-22','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('24','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1453796120','2016-01-26=16-15-20','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('25','4','13706360071','13706360071','13706360071，您投标的第4号借款已经通过复审,现在开始计息【尚贷系统】','1453796192','2016-01-26=16-16-32','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('26','4','13706360071','13706360071','13706360071，您投标的第4号借款已经通过复审,现在开始计息【尚贷系统】','1453796192','2016-01-26=16-16-32','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('27','2','17777777777','17777777777','17777777777，您发布的借款已经通过复审【尚贷系统】','1453796192','2016-01-26=16-16-32','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('28','1','18661395415','18661395415','18661395415，您投标的第5号借款已经通过复审,现在开始计息【尚贷系统】','1453796210','2016-01-26=16-16-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('29','1','18661395415','18661395415','18661395415，您投标的第5号借款已经通过复审,现在开始计息【尚贷系统】','1453796210','2016-01-26=16-16-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('30','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1453796210','2016-01-26=16-16-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('31','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1453796703','2016-01-26=16-25-03','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('32','4','13706360071','13706360071','13706360071，您发布的借款已经通过初审【尚贷系统】','1453797123','2016-01-26=16-32-03','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('33','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1453798688','2016-01-26=16-58-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('34','1','18661395415','18661395415','18661395415，您投标的第8号借款已经通过复审,现在开始计息【尚贷系统】','1453799042','2016-01-26=17-04-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('35','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1453799042','2016-01-26=17-04-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('36','','','15754920602','您的验证码为325481【尚贷系统】','1453856258','2016-01-27=08-57-38','0','漫道短信接口','111.127.41.236');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('37','','','15254618081','您的验证码为008226【尚贷系统】','1453858219','2016-01-27=09-30-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('38','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1453858792','2016-01-27=09-39-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('39','6','15553833036','15553833036','15553833036，您投标的第9号借款已经通过复审,现在开始计息【尚贷系统】','1453858877','2016-01-27=09-41-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('40','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1453858877','2016-01-27=09-41-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('41','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1453861124','2016-01-27=10-18-44','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('42','1','18661395415','18661395415','18661395415，您投标的第11号借款已经通过复审,现在开始计息【尚贷系统】','1453861246','2016-01-27=10-20-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('43','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1453861246','2016-01-27=10-20-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('44','1','18661395415','18661395415','您2016-01-27 10:20:14投资的第11号标第1期的还款已到帐,到账金额是100.1元【尚贷系统】','1453861536','2016-01-27=10-25-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('45','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1453862253','2016-01-27=10-37-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('46','1','18661395415','18661395415','18661395415，您投标的第12号借款已经通过复审,现在开始计息【尚贷系统】','1453862333','2016-01-27=10-38-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('47','1','18661395415','18661395415','您2016-01-27 10:38:53投资的第12号标第1期的还款已到帐,到账金额是202元【尚贷系统】','1453862337','2016-01-27=10-38-57','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('48','2','17777777777','17777777777','17777777777，您发布的借款已经通过初审【尚贷系统】','1453862474','2016-01-27=10-41-14','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('49','','','15666472280','您的验证码为938955【尚贷系统】','1453862512','2016-01-27=10-41-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('50','9','15666472280','15666472280','15666472280，您投标的第13号借款已经通过复审,现在开始计息【尚贷系统】','1453862648','2016-01-27=10-44-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('51','9','15666472280','15666472280','15666472280，您投标的第13号借款已经通过复审,现在开始计息【尚贷系统】','1453862648','2016-01-27=10-44-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('52','2','17777777777','17777777777','17777777777，您发布的借款已经通过复审【尚贷系统】','1453862648','2016-01-27=10-44-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('53','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1453863656','2016-01-27=11-00-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('54','4','13706360071','13706360071','13706360071您好，您2016-01-27 11:23:15在线充值的10000.00元已到帐【尚贷系统】','1453865117','2016-01-27=11-25-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('55','','','17853738946','您的验证码为592138【尚贷系统】','1453873437','2016-01-27=13-43-57','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('56','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1453875274','2016-01-27=14-14-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('57','','','15166272750','您的验证码为954809【尚贷系统】','1453897669','2016-01-27=20-27-49','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('58','8','15254618081','15254618081','15254618081您好，您2016-01-29 11:44:10在线充值的0.01元已到帐【尚贷系统】','1454039132','2016-01-29=11-45-32','0','漫道短信接口','211.152.0.134');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('59','','','17853738946','您的验证码为213659【尚贷系统】','1454118475','2016-01-30=09-47-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('60','','','17853738946','您的验证码为286002【尚贷系统】','1454118541','2016-01-30=09-49-01','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('61','','','17853738946','您的验证码为542186【尚贷系统】','1454118624','2016-01-30=09-50-24','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('62','','','18363754082','您的验证码为855326【尚贷系统】','1454118725','2016-01-30=09-52-05','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('63','','','17853738946','您的验证码为216939【尚贷系统】','1454118811','2016-01-30=09-53-31','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('64','12','17853738946','17853738946','17853738946您好，您2016-01-30 09:57:33在线充值的10000.00元已到帐【尚贷系统】','1454119462','2016-01-30=10-04-22','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('65','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1454120252','2016-01-30=10-17-32','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('66','12','17853738946','17853738946','17853738946，您投标的第16号借款已经通过复审,现在开始计息【尚贷系统】','1454120506','2016-01-30=10-21-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('67','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1454120506','2016-01-30=10-21-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('68','12','17853738946','17853738946','您2016-01-30 10:21:15投资的第16号标第1期的还款已到帐,到账金额是1010元【尚贷系统】','1454121603','2016-01-30=10-40-03','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('69','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1454123706','2016-01-30=11-15-06','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('70','12','17853738946','17853738946','17853738946，您投标的第17号借款已经通过复审,现在开始计息【尚贷系统】','1454123888','2016-01-30=11-18-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('71','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1454123888','2016-01-30=11-18-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('72','12','17853738946','17853738946','您2016-01-30 11:17:43投资的第17号标第1期的还款已到帐,到账金额是100.03元【尚贷系统】','1454124066','2016-01-30=11-21-06','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('73','12','17853738946','17853738946','17853738946，您的VIP认证已经通过【尚贷系统】','1454125423','2016-01-30=11-43-43','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('74','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1454125517','2016-01-30=11-45-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('75','12','17853738946','17853738946','17853738946，您投标的第18号借款已经通过复审,现在开始计息【尚贷系统】','1454125568','2016-01-30=11-46-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('76','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1454125568','2016-01-30=11-46-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('77','12','17853738946','17853738946','您2016-01-30 11:45:50投资的第18号标第1期的还款已到帐,到账金额是50.75元【尚贷系统】','1454125607','2016-01-30=11-46-47','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('78','12','17853738946','17853738946','您2016-01-30 11:45:50投资的第18号标第2期的还款已到帐,到账金额是50.75元【尚贷系统】','1454125609','2016-01-30=11-46-49','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('79','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1454125962','2016-01-30=11-52-42','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('80','4','13706360071','13706360071','13706360071，您投标的第19号借款已经通过复审,现在开始计息【尚贷系统】','1454132031','2016-01-30=13-33-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('81','6','15553833036','15553833036','15553833036，您投标的第19号借款已经通过复审,现在开始计息【尚贷系统】','1454132032','2016-01-30=13-33-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('82','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1454132032','2016-01-30=13-33-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('83','4','13706360071','13706360071','您2016-01-30 11:52:42投资的第19号标第1期的还款已到帐,到账金额是202元【尚贷系统】','1456898022','2016-03-02=13-53-42','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('84','6','15553833036','15553833036','您2016-01-30 11:54:19投资的第19号标第1期的还款已到帐,到账金额是808元【尚贷系统】','1456898022','2016-03-02=13-53-42','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('85','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1454134078','2016-01-30=14-07-58','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('86','6','15553833036','15553833036','15553833036，您投标的第20号借款已经通过复审,现在开始计息【尚贷系统】','1454134187','2016-01-30=14-09-47','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('87','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1454134187','2016-01-30=14-09-47','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('88','6','15553833036','15553833036','您2016-01-30 14:09:26投资的第20号标第1期的还款已到帐,到账金额是677.81元【尚贷系统】','1462601570','2016-05-07=14-12-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('89','6','15553833036','15553833036','您2016-01-30 14:09:26投资的第20号标第2期的还款已到帐,到账金额是677.81元【尚贷系统】','1462601571','2016-05-07=14-12-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('90','6','15553833036','15553833036','您2016-01-30 14:09:26投资的第20号标第3期的还款已到帐,到账金额是677.81元【尚贷系统】','1462601572','2016-05-07=14-12-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('91','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1454134561','2016-01-30=14-16-01','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('92','6','15553833036','15553833036','15553833036，您投标的第21号借款已经通过复审,现在开始计息【尚贷系统】','1454134658','2016-01-30=14-17-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('93','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1454134658','2016-01-30=14-17-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('94','6','15553833036','15553833036','您2016-01-30 14:16:45投资的第21号标第1期的还款已到帐,到账金额是101元【尚贷系统】','1457158800','2016-03-05=14-20-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('95','6','15553833036','15553833036','您2016-01-27 09:40:48投资的第9号标第1期的还款已到帐,到账金额是1008.33元【尚贷系统】','1454141593','2016-01-30=16-13-13','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('96','3','15849168711','15849168711','15849168711您好，您2016-02-01 10:14:22线下充值的10000.00元已到帐【尚贷系统】','1454292880','2016-02-01=10-14-40','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('97','3','15849168711','15849168711','15849168711，您的VIP认证已经通过【尚贷系统】','1454292932','2016-02-01=10-15-32','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('98','3','15849168711','15849168711','15849168711，您发布的借款已经通过初审【尚贷系统】','1454293291','2016-02-01=10-21-31','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('99','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1454294889','2016-02-01=10-48-09','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('100','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1454295506','2016-02-01=10-58-26','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('101','3','15849168711','15849168711','15849168711，您发布的借款已流标【尚贷系统】','1454295691','2016-02-01=11-01-31','0','漫道短信接口','222.173.174.202');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('102','4','13706360071','13706360071','13706360071，您发布的借款已经通过初审【尚贷系统】','1454469691','2016-02-03=11-21-31','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('103','2','17777777777','17777777777','您的验证码为6593【尚贷系统】','1454469819','2016-02-03=11-23-39','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('104','2','17777777777','17777777777','17777777777，您发布的借款已经通过初审【尚贷系统】','1455499296','2016-02-15=09-21-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('105','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1455500432','2016-02-15=09-40-32','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('106','','','13333333333','您的验证码为633792【尚贷系统】','1455501738','2016-02-15=10-02-18','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('107','6','15553833036','15553833036','15553833036，您投标的第6号借款已经通过复审,现在开始计息【尚贷系统】','1455503042','2016-02-15=10-24-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('108','6','15553833036','15553833036','15553833036，您投标的第6号借款已经通过复审,现在开始计息【尚贷系统】','1455503042','2016-02-15=10-24-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('109','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1455503043','2016-02-15=10-24-03','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('110','1','18661395415','18661395415','18661395415，您的VIP认证已经通过【尚贷系统】','1455503115','2016-02-15=10-25-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('111','6','15553833036','15553833036','15553833036，您的VIP认证已经通过【尚贷系统】','1455503126','2016-02-15=10-25-26','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('112','4','13706360071','13706360071','13706360071，您投标的第28号借款已经通过复审,现在开始计息【尚贷系统】','1455503974','2016-02-15=10-39-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('113','4','13706360071','13706360071','13706360071，您投标的第28号借款已经通过复审,现在开始计息【尚贷系统】','1455503974','2016-02-15=10-39-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('114','2','17777777777','17777777777','17777777777，您发布的借款已经通过复审【尚贷系统】','1455503974','2016-02-15=10-39-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('115','2','17777777777','17777777777','17777777777，您发布的借款已经通过初审【尚贷系统】','1455504062','2016-02-15=10-41-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('116','4','13706360071','13706360071','您的验证码为269514【尚贷系统】','1455505264','2016-02-15=11-01-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('117','','','18888888888','您的验证码为076826【尚贷系统】','1455505351','2016-02-15=11-02-31','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('118','4','18888888888','18888888888','您的验证码为606359【尚贷系统】','1455505488','2016-02-15=11-04-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('119','','','13706360071','您的验证码为818616【尚贷系统】','1455505514','2016-02-15=11-05-14','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('120','4','13706360071','13706360071','您2016-02-15 09:43:56投资的第28号标第1期的还款已到帐,到账金额是1000.82元【尚贷系统】','1455505769','2016-02-15=11-09-29','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('121','4','13706360071','13706360071','您2016-02-15 10:39:10投资的第28号标第1期的还款已到帐,到账金额是9007.4元【尚贷系统】','1455505769','2016-02-15=11-09-29','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('122','4','13706360071','13706360071','您2016-01-26 10:46:44投资的第4号标第1期的还款已到帐,到账金额是1666.67元【尚贷系统】','1455505800','2016-02-15=11-10-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('123','4','13706360071','13706360071','您2016-01-26 16:15:37投资的第4号标第1期的还款已到帐,到账金额是2500元【尚贷系统】','1455505800','2016-02-15=11-10-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('124','4','13706360071','13706360071','您2016-01-26 10:46:44投资的第4号标第2期的还款已到帐,到账金额是1666.67元【尚贷系统】','1455505802','2016-02-15=11-10-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('125','4','13706360071','13706360071','您2016-01-26 16:15:37投资的第4号标第2期的还款已到帐,到账金额是2500元【尚贷系统】','1455505802','2016-02-15=11-10-02','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('126','4','13706360071','13706360071','您2016-01-26 10:46:44投资的第4号标第3期的还款已到帐,到账金额是1666.67元【尚贷系统】','1455505806','2016-02-15=11-10-06','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('127','4','13706360071','13706360071','您2016-01-26 16:15:37投资的第4号标第3期的还款已到帐,到账金额是2500元【尚贷系统】','1455505806','2016-02-15=11-10-06','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('128','4','13706360071','13706360071','您2016-01-26 10:46:44投资的第4号标第4期的还款已到帐,到账金额是1666.67元【尚贷系统】','1455505808','2016-02-15=11-10-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('129','4','13706360071','13706360071','您2016-01-26 16:15:37投资的第4号标第4期的还款已到帐,到账金额是2500元【尚贷系统】','1455505808','2016-02-15=11-10-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('130','4','13706360071','13706360071','您2016-01-26 10:46:44投资的第4号标第5期的还款已到帐,到账金额是1666.67元【尚贷系统】','1455505811','2016-02-15=11-10-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('131','4','13706360071','13706360071','您2016-01-26 16:15:37投资的第4号标第5期的还款已到帐,到账金额是2500元【尚贷系统】','1455505811','2016-02-15=11-10-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('132','4','13706360071','13706360071','您2016-01-26 10:46:44投资的第4号标第6期的还款已到帐,到账金额是201666.67元【尚贷系统】','1455505813','2016-02-15=11-10-13','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('133','4','13706360071','13706360071','您2016-01-26 16:15:37投资的第4号标第6期的还款已到帐,到账金额是302500元【尚贷系统】','1455505813','2016-02-15=11-10-13','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('134','4','13706360071','13706360071','您的验证码为653923【尚贷系统】','1455506179','2016-02-15=11-16-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('135','4','13706360071','13706360071','您的验证码为253862【尚贷系统】','1455506246','2016-02-15=11-17-26','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('136','13','13333333333','13333333333','13333333333您好，您2016-02-15 10:22:20线下充值的100000.00元已到帐【尚贷系统】','1455507267','2016-02-15=11-34-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('137','13','13333333333','13333333333','13333333333，您2016-02-15 11:38:39的提现29950已经受理成功【尚贷系统】','1455507643','2016-02-15=11-40-43','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('138','12','17853738946','17853738946','17853738946，您2016-02-15 11:58:13的提现100.00已经受理成功【尚贷系统】','1455508740','2016-02-15=11-59-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('139','','','18266479979','您的验证码为155348【尚贷系统】','1455514505','2016-02-15=13-35-05','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('140','14','18266479979','18266479979','18266479979您好，您2016-02-15 13:37:18在线充值的10000.00元已到帐【尚贷系统】','1455514808','2016-02-15=13-40-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('141','14','18266479979','18266479979','18266479979，您的VIP认证已经通过【尚贷系统】','1455514973','2016-02-15=13-42-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('142','2','17777777777','17777777777','您的验证码为024742【尚贷系统】','1455515194','2016-02-15=13-46-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('143','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455515224','2016-02-15=13-47-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('144','1','18661395415','18661395415','18661395415，您投标的第30号借款已经通过复审,现在开始计息【尚贷系统】','1455515487','2016-02-15=13-51-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('145','2','17777777777','17777777777','17777777777，您投标的第30号借款已经通过复审,现在开始计息【尚贷系统】','1455515487','2016-02-15=13-51-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('146','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455515487','2016-02-15=13-51-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('147','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455515750','2016-02-15=13-55-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('148','2','17777777777','17777777777','17777777777，您发布的借款已流标【尚贷系统】','1455515773','2016-02-15=13-56-13','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('149','2','17777777777','17777777777','17777777777，您发布的借款已经通过初审【尚贷系统】','1455515903','2016-02-15=13-58-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('150','4','13706360071','13706360071','13706360071，您投标的第34号借款已经通过复审,现在开始计息【尚贷系统】','1455515940','2016-02-15=13-59-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('151','2','17777777777','17777777777','17777777777，您发布的借款已经通过复审【尚贷系统】','1455515940','2016-02-15=13-59-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('152','14','18266479979','18266479979','18266479979，您投标的第33号借款已经通过复审,现在开始计息【尚贷系统】','1455516012','2016-02-15=14-00-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('153','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455516012','2016-02-15=14-00-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('154','14','18266479979','18266479979','您2016-02-15 13:56:41投资的第33号标第1期的还款已到帐,到账金额是253.76元【尚贷系统】','1455516038','2016-02-15=14-00-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('155','14','18266479979','18266479979','您2016-02-15 13:56:41投资的第33号标第2期的还款已到帐,到账金额是253.75元【尚贷系统】','1455516039','2016-02-15=14-00-39','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('156','1','18661395415','18661395415','您2016-02-15 13:51:08投资的第30号标第1期的还款已到帐,到账金额是68.34元【尚贷系统】','1455516048','2016-02-15=14-00-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('157','1','18661395415','18661395415','您2016-02-15 13:51:08投资的第30号标第2期的还款已到帐,到账金额是68.34元【尚贷系统】','1455516069','2016-02-15=14-01-09','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('158','2','17777777777','17777777777','您2016-02-15 13:48:08投资的第30号标第2期的还款已到帐,到账金额是102.51元【尚贷系统】','1455516069','2016-02-15=14-01-09','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('159','1','18661395415','18661395415','您2016-02-15 13:51:08投资的第30号标第3期的还款已到帐,到账金额是68.34元【尚贷系统】','1455516075','2016-02-15=14-01-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('160','2','17777777777','17777777777','您2016-02-15 13:48:08投资的第30号标第3期的还款已到帐,到账金额是102.51元【尚贷系统】','1455516075','2016-02-15=14-01-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('161','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455517204','2016-02-15=14-20-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('162','14','18266479979','18266479979','18266479979，您投标的第35号借款已经通过复审,现在开始计息【尚贷系统】','1455517315','2016-02-15=14-21-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('163','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455517315','2016-02-15=14-21-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('164','14','18266479979','18266479979','您2016-02-15 14:21:29投资的第35号标第1期的还款已到帐,到账金额是202元【尚贷系统】','1455517370','2016-02-15=14-22-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('165','2','17777777777','17777777777','17777777777，您发布的借款已经通过初审【尚贷系统】','1455518107','2016-02-15=14-35-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('166','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455518944','2016-02-15=14-49-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('167','12','17853738946','17853738946','17853738946，您发布的借款已流标【尚贷系统】','1455519659','2016-02-15=15-00-59','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('168','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455519795','2016-02-15=15-03-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('169','4','13706360071','13706360071','13706360071，您投标的第38号借款已经通过复审,现在开始计息【尚贷系统】','1455519896','2016-02-15=15-04-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('170','14','18266479979','18266479979','18266479979，您投标的第38号借款已经通过复审,现在开始计息【尚贷系统】','1455519896','2016-02-15=15-04-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('171','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455519896','2016-02-15=15-04-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('172','4','13706360071','13706360071','您2016-02-15 15:03:15投资的第38号标第1期的还款已到帐,到账金额是100.07元【尚贷系统】','1455519915','2016-02-15=15-05-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('173','14','18266479979','18266479979','您2016-02-15 15:04:25投资的第38号标第1期的还款已到帐,到账金额是400.26元【尚贷系统】','1455519915','2016-02-15=15-05-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('174','14','18266479979','18266479979','18266479979，您发布的借款已经通过初审【尚贷系统】','1455521110','2016-02-15=15-25-10','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('175','12','17853738946','17853738946','17853738946，您投标的第40号借款已经通过复审,现在开始计息【尚贷系统】','1455521146','2016-02-15=15-25-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('176','14','18266479979','18266479979','18266479979，您发布的借款已经通过复审【尚贷系统】','1455521146','2016-02-15=15-25-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('177','4','13706360071','13706360071','13706360071您好，您2016-02-15 15:30:55线下充值的1000.00元已到帐【尚贷系统】','1455521475','2016-02-15=15-31-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('178','4','13706360071','13706360071','13706360071，您2016-01-27 11:34:16的提现10000.00已经受理成功【尚贷系统】','1455521626','2016-02-15=15-33-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('179','1','18661395415','18661395415','您2016-02-15 15:25:33投资的第40号标第1期的还款已到帐,到账金额是505元【尚贷系统】','1455522153','2016-02-15=15-42-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('180','2','17777777777','17777777777','17777777777，您发布的借款已流标【尚贷系统】','1455522993','2016-02-15=15-56-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('181','14','18266479979','18266479979','18266479979，您2016-02-15 15:57:51的提现100.00已经受理成功【尚贷系统】','1455523259','2016-02-15=16-00-59','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('182','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455523675','2016-02-15=16-07-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('183','4','13706360071','13706360071','您的验证码为832513【尚贷系统】','1455525112','2016-02-15=16-31-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('184','','','18888888888','您的验证码为346759【尚贷系统】','1455525141','2016-02-15=16-32-21','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('185','4','13706360071','13706360071','您的验证码为037427【尚贷系统】','1455525163','2016-02-15=16-32-43','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('186','','','18888888888','您的验证码为590527【尚贷系统】','1455525192','2016-02-15=16-33-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('187','','','13706360071','您的验证码为237742【尚贷系统】','1455525264','2016-02-15=16-34-24','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('188','14','18266479979','18266479979','您的验证码为421758【尚贷系统】','1455526438','2016-02-15=16-53-58','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('189','15','13706360071','13706360071','13706360071您好，您2016-02-15 16:53:50在线充值的100000.00元已到帐【尚贷系统】','1455526459','2016-02-15=16-54-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('190','15','13706360071','13706360071','13706360071，您的VIP认证已经通过【尚贷系统】','1455527557','2016-02-15=17-12-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('191','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1455584336','2016-02-16=08-58-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('192','14','18266479979','18266479979','18266479979，您投标的第42号借款已经通过复审,现在开始计息【尚贷系统】','1455584603','2016-02-16=09-03-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('193','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1455584603','2016-02-16=09-03-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('194','14','18266479979','18266479979','您2016-02-16 09:03:01投资的第42号标第1期的还款已到帐,到账金额是606元【尚贷系统】','1455584618','2016-02-16=09-03-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('195','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1455586281','2016-02-16=09-31-21','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('196','14','18266479979','18266479979','18266479979，您投标的第43号借款已经通过复审,现在开始计息【尚贷系统】','1455586364','2016-02-16=09-32-44','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('197','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1455586364','2016-02-16=09-32-44','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('198','14','18266479979','18266479979','您2016-02-16 09:32:28投资的第43号标第1期的还款已到帐,到账金额是200元【尚贷系统】','1455586394','2016-02-16=09-33-14','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('199','14','18266479979','18266479979','您2016-02-16 09:32:28投资的第43号标第2期的还款已到帐,到账金额是200元【尚贷系统】','1455586395','2016-02-16=09-33-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('200','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1455587007','2016-02-16=09-43-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('201','14','18266479979','18266479979','18266479979，您投标的第44号借款已经通过复审,现在开始计息【尚贷系统】','1455587123','2016-02-16=09-45-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('202','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1455587123','2016-02-16=09-45-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('203','14','18266479979','18266479979','您2016-02-16 09:45:05投资的第44号标第1期的还款已到帐,到账金额是204.17元【尚贷系统】','1455587139','2016-02-16=09-45-39','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('204','14','18266479979','18266479979','您的验证码为980765【尚贷系统】','1455588353','2016-02-16=10-05-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('205','14','18266479979','18266479979','您的验证码为570522【尚贷系统】','1455588774','2016-02-16=10-12-54','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('206','14','18266479979','18266479979','您的验证码为610941【尚贷系统】','1455588837','2016-02-16=10-13-57','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('207','14','18266479979','18266479979','您的验证码为942768【尚贷系统】','1455588915','2016-02-16=10-15-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('208','14','18266479979','18266479979','您的验证码为098167【尚贷系统】','1455589029','2016-02-16=10-17-09','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('209','14','18266479979','18266479979','18266479979，您发布的借款已经通过初审【尚贷系统】','1455592361','2016-02-16=11-12-41','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('210','14','18266479979','18266479979','18266479979，您发布的借款已流标【尚贷系统】','1455592481','2016-02-16=11-14-41','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('211','14','18266479979','18266479979','18266479979，您发布的借款已经通过初审【尚贷系统】','1455592620','2016-02-16=11-17-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('212','4','18888888888','18888888888','18888888888，您发布的借款已经通过初审【尚贷系统】','1455601387','2016-02-16=13-43-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('213','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1455603544','2016-02-16=14-19-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('214','1','18661395415','18661395415','18661395415，您投标的第49号借款已经通过复审,现在开始计息【尚贷系统】','1455603650','2016-02-16=14-20-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('215','4','18888888888','18888888888','18888888888，您投标的第49号借款已经通过复审,现在开始计息【尚贷系统】','1455603651','2016-02-16=14-20-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('216','12','17853738946','17853738946','17853738946，您投标的第49号借款已经通过复审,现在开始计息【尚贷系统】','1455603651','2016-02-16=14-20-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('217','14','18266479979','18266479979','18266479979，您投标的第49号借款已经通过复审,现在开始计息【尚贷系统】','1455603651','2016-02-16=14-20-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('218','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1455603651','2016-02-16=14-20-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('219','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第1期的还款已到帐,到账金额是219.74元【尚贷系统】','1455603765','2016-02-16=14-22-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('220','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第1期的还款已到帐,到账金额是52.32元【尚贷系统】','1455603765','2016-02-16=14-22-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('221','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第1期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603765','2016-02-16=14-22-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('222','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第1期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603765','2016-02-16=14-22-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('223','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第2期的还款已到帐,到账金额是219.74元【尚贷系统】','1455603766','2016-02-16=14-22-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('224','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第2期的还款已到帐,到账金额是52.32元【尚贷系统】','1455603766','2016-02-16=14-22-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('225','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第2期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603766','2016-02-16=14-22-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('226','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第2期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603766','2016-02-16=14-22-46','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('227','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第3期的还款已到帐,到账金额是219.75元【尚贷系统】','1455603767','2016-02-16=14-22-47','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('228','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第3期的还款已到帐,到账金额是52.32元【尚贷系统】','1455603768','2016-02-16=14-22-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('229','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第3期的还款已到帐,到账金额是20.92元【尚贷系统】','1455603768','2016-02-16=14-22-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('230','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第3期的还款已到帐,到账金额是20.92元【尚贷系统】','1455603768','2016-02-16=14-22-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('231','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第4期的还款已到帐,到账金额是219.74元【尚贷系统】','1455603773','2016-02-16=14-22-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('232','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第4期的还款已到帐,到账金额是52.32元【尚贷系统】','1455603773','2016-02-16=14-22-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('233','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第4期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603773','2016-02-16=14-22-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('234','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第4期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603773','2016-02-16=14-22-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('235','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第5期的还款已到帐,到账金额是219.74元【尚贷系统】','1455603775','2016-02-16=14-22-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('236','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第5期的还款已到帐,到账金额是52.32元【尚贷系统】','1455603775','2016-02-16=14-22-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('237','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第5期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603775','2016-02-16=14-22-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('238','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第5期的还款已到帐,到账金额是20.93元【尚贷系统】','1455603775','2016-02-16=14-22-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('239','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第6期的还款已到帐,到账金额是219.74元【尚贷系统】','1483338270','2017-01-02=14-24-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('240','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第6期的还款已到帐,到账金额是52.32元【尚贷系统】','1483338270','2017-01-02=14-24-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('241','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第6期的还款已到帐,到账金额是20.93元【尚贷系统】','1483338270','2017-01-02=14-24-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('242','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第6期的还款已到帐,到账金额是20.93元【尚贷系统】','1483338270','2017-01-02=14-24-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('243','1','18661395415','18661395415','您2016-02-16 14:20:23投资的第49号标第7期的还款已到帐,到账金额是219.74元【尚贷系统】','1483338277','2017-01-02=14-24-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('244','4','18888888888','18888888888','您2016-02-16 14:19:04投资的第49号标第7期的还款已到帐,到账金额是52.32元【尚贷系统】','1483338277','2017-01-02=14-24-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('245','12','17853738946','17853738946','您2016-02-16 14:19:04投资的第49号标第7期的还款已到帐,到账金额是20.92元【尚贷系统】','1483338277','2017-01-02=14-24-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('246','14','18266479979','18266479979','您2016-02-16 14:19:04投资的第49号标第7期的还款已到帐,到账金额是20.92元【尚贷系统】','1483338277','2017-01-02=14-24-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('247','12','17853738946','17853738946','17853738946，您投标的第47号借款已经通过复审,现在开始计息【尚贷系统】','1455606765','2016-02-16=15-12-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('248','14','18266479979','18266479979','18266479979，您发布的借款已经通过复审【尚贷系统】','1455606765','2016-02-16=15-12-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('249','15','13706360071','13706360071','13706360071，您发布的借款已经通过初审【尚贷系统】','1455608019','2016-02-16=15-33-39','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('250','12','17853738946','17853738946','您2016-02-16 15:12:14投资的第47号标第1期的还款已到帐,到账金额是202元【尚贷系统】','1455610314','2016-02-16=16-11-54','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('251','12','17853738946','17853738946','17853738946，您发布的借款已流标【尚贷系统】','1455610412','2016-02-16=16-13-32','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('252','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455610507','2016-02-16=16-15-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('253','','','18510287427','您的验证码为670455【尚贷系统】','1455613084','2016-02-16=16-58-04','0','漫道短信接口','58.132.175.221');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('254','6','15553833036','15553833036','您的验证码为304196【尚贷系统】','1455673990','2016-02-17=09-53-10','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('255','6','15553833036','15553833036','您的验证码为098428【尚贷系统】','1455675593','2016-02-17=10-19-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('256','','','13311172420','您的验证码为579795【尚贷系统】','1455675617','2016-02-17=10-20-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('257','6','15553833036','15553833036','您的验证码为593986【尚贷系统】','1455675683','2016-02-17=10-21-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('258','','','13311172420','您的验证码为708385【尚贷系统】','1455675715','2016-02-17=10-21-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('259','14','18266479979','18266479979','18266479979，您发布的借款已经通过初审【尚贷系统】','1455676249','2016-02-17=10-30-49','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('260','12','17853738946','17853738946','17853738946，您投标的第52号借款已经通过复审,现在开始计息【尚贷系统】','1455676327','2016-02-17=10-32-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('261','14','18266479979','18266479979','18266479979，您发布的借款已经通过复审【尚贷系统】','1455676327','2016-02-17=10-32-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('262','12','17853738946','17853738946','您2016-02-17 10:31:48投资的第52号标第1期的还款已到帐,到账金额是204元【尚贷系统】','1455676367','2016-02-17=10-32-47','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('263','14','18266479979','18266479979','18266479979，您投标的第51号借款已经通过复审,现在开始计息【尚贷系统】','1455676893','2016-02-17=10-41-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('264','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455676893','2016-02-17=10-41-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('265','14','18266479979','18266479979','您2016-02-17 10:38:54投资的第51号标第1期的还款已到帐,到账金额是303元【尚贷系统】','1455676912','2016-02-17=10-41-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('266','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455677161','2016-02-17=10-46-01','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('267','14','18266479979','18266479979','18266479979，您投标的第53号借款已经通过复审,现在开始计息【尚贷系统】','1455677336','2016-02-17=10-48-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('268','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455677337','2016-02-17=10-48-57','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('269','14','18266479979','18266479979','您2016-02-17 10:46:21投资的第53号标第1期的还款已到帐,到账金额是202元【尚贷系统】','1455677392','2016-02-17=10-49-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('270','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455677532','2016-02-17=10-52-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('271','14','18266479979','18266479979','18266479979，您投标的第54号借款已经通过复审,现在开始计息【尚贷系统】','1455677610','2016-02-17=10-53-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('272','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455677611','2016-02-17=10-53-31','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('273','14','18266479979','18266479979','您2016-02-17 10:52:51投资的第54号标第1期的还款已到帐,到账金额是303元【尚贷系统】','1455677654','2016-02-17=10-54-14','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('274','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455677928','2016-02-17=10-58-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('275','14','18266479979','18266479979','18266479979，您投标的第55号借款已经通过复审,现在开始计息【尚贷系统】','1455678017','2016-02-17=11-00-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('276','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455678017','2016-02-17=11-00-17','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('277','14','18266479979','18266479979','您2016-02-17 10:59:37投资的第55号标第1期的还款已到帐,到账金额是102.51元【尚贷系统】','1455678050','2016-02-17=11-00-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('278','14','18266479979','18266479979','您2016-02-17 10:59:37投资的第55号标第2期的还款已到帐,到账金额是102.51元【尚贷系统】','1455678060','2016-02-17=11-01-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('279','14','18266479979','18266479979','您2016-02-17 10:59:37投资的第55号标第3期的还款已到帐,到账金额是102.51元【尚贷系统】','1455678065','2016-02-17=11-01-05','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('280','14','18266479979','18266479979','您2016-02-17 10:59:37投资的第55号标第4期的还款已到帐,到账金额是102.52元【尚贷系统】','1455678072','2016-02-17=11-01-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('281','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455678147','2016-02-17=11-02-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('282','4','18888888888','18888888888','18888888888，您发布的借款已流标【尚贷系统】','1455691476','2016-02-17=14-44-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('283','14','18266479979','18266479979','18266479979，您发布的借款已经通过初审【尚贷系统】','1455698718','2016-02-17=16-45-18','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('284','9','15666472280','15666472280','15666472280，您的VIP认证已经通过【尚贷系统】','1455845744','2016-02-19=09-35-44','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('285','14','18266479979','18266479979','您的验证码为238735【尚贷系统】','1455933651','2016-02-20=10-00-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('286','14','18266479979','18266479979','18266479979，您投标的第56号借款已经通过复审,现在开始计息【尚贷系统】','1455934091','2016-02-20=10-08-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('287','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1455934092','2016-02-20=10-08-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('288','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1455935272','2016-02-20=10-27-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('289','','','15155448989','您的验证码为324608【尚贷系统】','1455941689','2016-02-20=12-14-49','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('290','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1456541485','2016-02-27=10-51-25','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('291','11','15166272750','15166272750','15166272750，您发布的借款已经通过初审【尚贷系统】','1456541701','2016-02-27=10-55-01','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('292','','','15147110127','您的验证码为210543【尚贷系统】','1456745082','2016-02-29=19-24-42','0','漫道短信接口','111.127.235.50');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('293','','','13148437042','您的验证码为763730【尚贷系统】','1456745144','2016-02-29=19-25-44','0','漫道短信接口','111.127.235.50');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('294','','','15048363585','您的验证码为034956【尚贷系统】','1456795663','2016-03-01=09-27-43','0','漫道短信接口','111.127.234.108');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('295','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1457336919','2016-03-07=15-48-39','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('296','14','18266479979','18266479979','18266479979，您投标的第60号借款已经通过复审,现在开始计息【尚贷系统】','1457337247','2016-03-07=15-54-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('297','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1457337248','2016-03-07=15-54-08','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('298','14','18266479979','18266479979','您2016-03-07 15:53:42投资的第60号标第1期的还款已到帐,到账金额是806.67元【尚贷系统】','1457337259','2016-03-07=15-54-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('299','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1457337289','2016-03-07=15-54-49','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('300','6','15553833036','15553833036','15553833036，您投标的第61号借款已经通过复审,现在开始计息【尚贷系统】','1457337411','2016-03-07=15-56-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('301','1','18661395415','18661395415','18661395415，您发布的借款已经通过复审【尚贷系统】','1457337411','2016-03-07=15-56-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('302','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1457337413','2016-03-07=15-56-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('303','14','18266479979','18266479979','18266479979，您投标的第62号借款已经通过复审,现在开始计息【尚贷系统】','1457337471','2016-03-07=15-57-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('304','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1457337471','2016-03-07=15-57-51','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('305','6','15553833036','15553833036','您2016-03-07 15:55:22投资的第61号标第1期的还款已到帐,到账金额是508.36元【尚贷系统】','1457337491','2016-03-07=15-58-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('306','6','15553833036','15553833036','您2016-03-07 15:55:22投资的第61号标第2期的还款已到帐,到账金额是508.36元【尚贷系统】','1457337492','2016-03-07=15-58-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('307','6','15553833036','15553833036','您2016-03-07 15:55:22投资的第61号标第3期的还款已到帐,到账金额是508.36元【尚贷系统】','1457337494','2016-03-07=15-58-14','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('308','14','18266479979','18266479979','您2016-03-07 15:57:35投资的第62号标第1期的还款已到帐,到账金额是305.01元【尚贷系统】','1457337547','2016-03-07=15-59-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('309','14','18266479979','18266479979','您2016-03-07 15:57:35投资的第62号标第2期的还款已到帐,到账金额是305.01元【尚贷系统】','1457337551','2016-03-07=15-59-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('310','14','18266479979','18266479979','您2016-03-07 15:57:35投资的第62号标第3期的还款已到帐,到账金额是305.01元【尚贷系统】','1457337556','2016-03-07=15-59-16','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('311','14','18266479979','18266479979','18266479979您好，您2016-03-07 16:14:06在线充值的100.00元已到帐【尚贷系统】','1457338484','2016-03-07=16-14-44','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('312','14','18266479979','18266479979','18266479979您好，您2016-03-07 16:15:25在线充值的50.00元已到帐【尚贷系统】','1457338556','2016-03-07=16-15-56','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('313','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1457339786','2016-03-07=16-36-26','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('314','14','18266479979','18266479979','18266479979，您投标的第63号借款已经通过复审,现在开始计息【尚贷系统】','1457339833','2016-03-07=16-37-13','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('315','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1457339833','2016-03-07=16-37-13','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('316','14','18266479979','18266479979','您2016-03-07 16:36:53投资的第63号标第1期的还款已到帐,到账金额是303元【尚贷系统】','1457339853','2016-03-07=16-37-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('317','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1457340038','2016-03-07=16-40-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('318','14','18266479979','18266479979','18266479979，您投标的第64号借款已经通过复审,现在开始计息【尚贷系统】','1457340150','2016-03-07=16-42-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('319','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1457340150','2016-03-07=16-42-30','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('320','14','18266479979','18266479979','您2016-03-07 16:41:53投资的第64号标第1期的还款已到帐,到账金额是101.5元【尚贷系统】','1457340169','2016-03-07=16-42-49','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('321','14','18266479979','18266479979','您2016-03-07 16:41:53投资的第64号标第2期的还款已到帐,到账金额是101.51元【尚贷系统】','1457340170','2016-03-07=16-42-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('322','1','18661395415','18661395415','18661395415，您发布的借款已经通过初审【尚贷系统】','1457342239','2016-03-07=17-17-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('323','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1457342239','2016-03-07=17-17-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('324','14','18266479979','18266479979','18266479979，您投标的第65号借款已经通过复审,现在开始计息【尚贷系统】','1457343050','2016-03-07=17-30-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('325','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1457343050','2016-03-07=17-30-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('326','12','17853738946','17853738946','17853738946，您发布的借款已经通过初审【尚贷系统】','1457343112','2016-03-07=17-31-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('327','14','18266479979','18266479979','18266479979，您投标的第67号借款已经通过复审,现在开始计息【尚贷系统】','1457343153','2016-03-07=17-32-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('328','12','17853738946','17853738946','17853738946，您发布的借款已经通过复审【尚贷系统】','1457343154','2016-03-07=17-32-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('329','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1457343374','2016-03-07=17-36-14','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('330','','','15822623833','您的验证码为575817【尚贷系统】','1457486517','2016-03-09=09-21-57','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('331','','','15865463700','您的验证码为768890【尚贷系统】','1457580483','2016-03-10=11-28-03','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('332','','','13864760507','您的验证码为618913【尚贷系统】','1458182415','2016-03-17=10-40-15','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('333','','','18654658738','您的验证码为472480【尚贷系统】','1458523559','2016-03-21=09-25-59','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('334','23','18654658738','18654658738','18654658738，您的VIP认证已经通过【尚贷系统】','1458634973','2016-03-22=16-22-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('335','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1458723533','2016-03-23=16-58-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('336','4','18888888888','18888888888','18888888888，您投标的第69号借款已经通过复审,现在开始计息【尚贷系统】','1458723787','2016-03-23=17-03-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('337','4','18888888888','18888888888','18888888888，您投标的第69号借款已经通过复审,现在开始计息【尚贷系统】','1458723787','2016-03-23=17-03-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('338','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1458723787','2016-03-23=17-03-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('339','4','18888888888','18888888888','您2016-03-23 16:58:54投资的第69号标第1期的还款已到帐,到账金额是102.52元【尚贷系统】','1458723807','2016-03-23=17-03-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('340','4','18888888888','18888888888','您2016-03-23 17:00:33投资的第69号标第1期的还款已到帐,到账金额是512.57元【尚贷系统】','1458723807','2016-03-23=17-03-27','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('341','4','18888888888','18888888888','您2016-03-23 16:58:54投资的第69号标第2期的还款已到帐,到账金额是102.52元【尚贷系统】','1458723813','2016-03-23=17-03-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('342','4','18888888888','18888888888','您2016-03-23 17:00:33投资的第69号标第2期的还款已到帐,到账金额是512.57元【尚贷系统】','1458723813','2016-03-23=17-03-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('343','4','18888888888','18888888888','您2016-03-23 16:58:54投资的第69号标第3期的还款已到帐,到账金额是102.51元【尚贷系统】','1458723815','2016-03-23=17-03-35','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('344','4','18888888888','18888888888','您2016-03-23 17:00:33投资的第69号标第3期的还款已到帐,到账金额是512.57元【尚贷系统】','1458723815','2016-03-23=17-03-35','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('345','4','18888888888','18888888888','您2016-03-23 16:58:54投资的第69号标第4期的还款已到帐,到账金额是102.52元【尚贷系统】','1458723816','2016-03-23=17-03-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('346','4','18888888888','18888888888','您2016-03-23 17:00:33投资的第69号标第4期的还款已到帐,到账金额是512.57元【尚贷系统】','1458723816','2016-03-23=17-03-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('347','4','18888888888','18888888888','您2016-03-23 16:58:54投资的第69号标第5期的还款已到帐,到账金额是102.52元【尚贷系统】','1458723818','2016-03-23=17-03-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('348','4','18888888888','18888888888','您2016-03-23 17:00:33投资的第69号标第5期的还款已到帐,到账金额是512.57元【尚贷系统】','1458723818','2016-03-23=17-03-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('349','6','15553833036','15553833036','15553833036，您发布的借款已经通过初审【尚贷系统】','1464832905','2016-06-02=10-01-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('350','4','18888888888','18888888888','18888888888，您投标的第70号借款已经通过复审,现在开始计息【尚贷系统】','1464832954','2016-06-02=10-02-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('351','4','18888888888','18888888888','18888888888，您投标的第70号借款已经通过复审,现在开始计息【尚贷系统】','1464832954','2016-06-02=10-02-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('352','6','15553833036','15553833036','15553833036，您发布的借款已经通过复审【尚贷系统】','1464832955','2016-06-02=10-02-35','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('353','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第1期的还款已到帐,到账金额是41.85元【尚贷系统】','1464832973','2016-06-02=10-02-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('354','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第1期的还款已到帐,到账金额是167.42元【尚贷系统】','1464832973','2016-06-02=10-02-53','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('355','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第2期的还款已到帐,到账金额是41.85元【尚贷系统】','1464832974','2016-06-02=10-02-54','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('356','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第2期的还款已到帐,到账金额是167.43元【尚贷系统】','1464832974','2016-06-02=10-02-54','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('357','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第3期的还款已到帐,到账金额是41.86元【尚贷系统】','1464832975','2016-06-02=10-02-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('358','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第3期的还款已到帐,到账金额是167.42元【尚贷系统】','1464832975','2016-06-02=10-02-55','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('359','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第4期的还款已到帐,到账金额是41.85元【尚贷系统】','1464832978','2016-06-02=10-02-58','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('360','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第4期的还款已到帐,到账金额是167.43元【尚贷系统】','1464832978','2016-06-02=10-02-58','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('361','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第5期的还款已到帐,到账金额是41.85元【尚贷系统】','1464832979','2016-06-02=10-02-59','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('362','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第5期的还款已到帐,到账金额是167.42元【尚贷系统】','1464832979','2016-06-02=10-02-59','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('363','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第6期的还款已到帐,到账金额是41.86元【尚贷系统】','1464832980','2016-06-02=10-03-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('364','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第6期的还款已到帐,到账金额是167.43元【尚贷系统】','1464832980','2016-06-02=10-03-00','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('365','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第7期的还款已到帐,到账金额是41.86元【尚贷系统】','1464832984','2016-06-02=10-03-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('366','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第7期的还款已到帐,到账金额是167.43元【尚贷系统】','1464832984','2016-06-02=10-03-04','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('367','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第8期的还款已到帐,到账金额是41.86元【尚贷系统】','1464832985','2016-06-02=10-03-05','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('368','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第8期的还款已到帐,到账金额是167.43元【尚贷系统】','1464832986','2016-06-02=10-03-06','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('369','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第9期的还款已到帐,到账金额是41.86元【尚贷系统】','1464832987','2016-06-02=10-03-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('370','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第9期的还款已到帐,到账金额是167.43元【尚贷系统】','1464832987','2016-06-02=10-03-07','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('371','4','18888888888','18888888888','您2016-06-02 10:01:45投资的第70号标第10期的还款已到帐,到账金额是41.86元【尚贷系统】','1464833003','2016-06-02=10-03-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('372','4','18888888888','18888888888','您2016-06-02 10:02:24投资的第70号标第10期的还款已到帐,到账金额是167.42元【尚贷系统】','1464833003','2016-06-02=10-03-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('373','1','18661395415','18661395415','您2016-01-26 16:16:28投资的第5号标第1期的还款已到帐,到账金额是1002.74元【尚贷系统】','1459386341','2016-03-31=09-05-41','0','漫道短信接口','124.236.30.191');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('374','1','18661395415','18661395415','您2016-01-26 16:16:39投资的第5号标第1期的还款已到帐,到账金额是1002.74元【尚贷系统】','1459386341','2016-03-31=09-05-41','0','漫道短信接口','124.236.30.191');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('375','','','18366965783','您的验证码为549170【尚贷系统】','1459473151','2016-04-01=09-12-31','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('376','8','15254618081','15254618081','15254618081，您2016-04-01 10:02:50的提现1000.00已经受理成功【尚贷系统】','1459476278','2016-04-01=10-04-38','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('377','9','15666472280','15666472280','您2016-01-27 10:43:48投资的第13号标第1期的还款已到帐,到账金额是253.76元【尚贷系统】','1459784511','2016-04-04=23-41-51','0','漫道短信接口','114.255.40.24');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('378','9','15666472280','15666472280','您2016-01-27 10:43:55投资的第13号标第1期的还款已到帐,到账金额是761.27元【尚贷系统】','1459784512','2016-04-04=23-41-52','0','漫道短信接口','114.255.40.24');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('379','20','15822623833','15822623833','15822623833，您的VIP认证已经通过【尚贷系统】','1459823952','2016-04-05=10-39-12','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('380','20','15822623833','15822623833','您的验证码为860912【尚贷系统】','1459824037','2016-04-05=10-40-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('381','','','15554686781','您的验证码为717988【尚贷系统】','1459836405','2016-04-05=14-06-45','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('382','','','18264843589','您的验证码为296832【尚贷系统】','1459836514','2016-04-05=14-08-34','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('383','26','18264843589','18264843589','18264843589，您的VIP认证已经通过【尚贷系统】','1459837271','2016-04-05=14-21-11','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('384','26','18264843589','18264843589','您的验证码为232891【尚贷系统】','1459837361','2016-04-05=14-22-41','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('385','26','18264843589','18264843589','18264843589，您发布的借款已经通过初审【尚贷系统】','1459837908','2016-04-05=14-31-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('386','25','15554686781','15554686781','15554686781您好，您2016-04-05 14:51:23线下充值的10000000.00元已到帐【尚贷系统】','1459839108','2016-04-05=14-51-48','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('387','25','15554686781','15554686781','15554686781，您投标的第71号借款已经通过复审,现在开始计息【尚贷系统】','1459839756','2016-04-05=15-02-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('388','26','18264843589','18264843589','18264843589，您发布的借款已经通过复审【尚贷系统】','1459839756','2016-04-05=15-02-36','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('389','25','15554686781','15554686781','您2016-04-05 14:58:06投资的第71号标第1期的还款已到帐,到账金额是10031.25元【尚贷系统】','1459926803','2016-04-06=15-13-23','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('390','','','13111111111','您的验证码为128264【尚贷系统】','1460011108','2016-04-07=14-38-28','0','漫道短信接口','61.156.219.211');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('391','','','18206386604','您的验证码为958345【尚贷系统】','1460099077','2016-04-08=15-04-37','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('392','27','18206386604','18206386604','18206386604您好，您2016-04-08 15:06:42线下充值的10000.00元已到帐【尚贷系统】','1460099212','2016-04-08=15-06-52','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('393','','','18222901119','您的验证码为778543【尚贷系统】','1460390036','2016-04-11=23-53-56','0','漫道短信接口','114.255.40.17');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('394','','','13599260916','您的验证码为535395【尚贷系统】','1460516500','2016-04-13=11-01-40','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('395','29','13599260916','13599260916','13599260916，您的VIP认证已经通过【尚贷系统】','1460517605','2016-04-13=11-20-05','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('396','','','13835715949','您的验证码为362489【尚贷系统】','1460518782','2016-04-13=11-39-42','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('397','','','13835715949','您的验证码为185279【尚贷系统】','1460518939','2016-04-13=11-42-19','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('398','30','13835715949','13835715949','13835715949，您的VIP认证已经通过【尚贷系统】','1460519793','2016-04-13=11-56-33','0','漫道短信接口','61.156.219.212');/* DBReback Separation */
 /* 插入数据 `shang_xbo_smslog` */
 INSERT INTO `shang_xbo_smslog` VALUES ('399','30','13835715949','13835715949','13835715949，您发布的借款已经通过初审【尚贷系统】','1460520050','2016-04-13=12-00-50','0','漫道短信接口','61.156.219.212');/* DBReback Separation */